# Axiom Runtime P1 完成计划 — Verification 三联收尾（任务 3-5）

## Summary

继续并完成已批准的 P1 Verification 三联计划（`.trae/documents/axiom-runtime-p1-verification.md`）。任务 1（semantic → field_match 改名）和任务 2（verifyResult 改 async + refine 循环）已在前一会话完成。本计划聚焦剩余的任务 3-5：消费 needsLLM 信号、补齐测试覆盖、跑全量验证。

**关键发现（紧急）**：任务 2 把 `verifyResult` 改为 async 后，`reasoning-runtime.ts:506` 和 `tests/dre-core-modules.test.ts` 的 9 处调用方**尚未加 `await`**，当前代码处于编译失败 + 运行时错误状态（访问 Promise 对象的属性）。任务 3 和 4 不只是"新增功能"，还包含**修复 Task 2 引入的 breaking change**。这是本计划最高优先级。

## Current State Analysis

### 已完成（Task 1-2）

| 文件 | 状态 |
|------|------|
| `src/dre/constraint/solver.ts` | ✅ `field_match` 改名到位（L11/L21/L266/L380/L500） |
| `src/mcp/server.ts` | ✅ `z.enum` + 类型断言改名到位（L2689/L2694） |
| `src/dre/runtime/verification-engine.ts` | ✅ `async verifyResult` + `verifyOnce` 抽出 + `RefineCallback` 类型 + `finalResult`/`refineIterations` 字段 + 三重死循环防护 |

### 未完成且导致代码 broken（Task 3-4）

| 文件 | 问题 | 行号 |
|------|------|------|
| `src/dre/runtime/reasoner/reasoning-runtime.ts` | 调用 async `verifyResult` 未 `await`，未传 `refineCallback`，未消费 `finalResult`，仍保留旧 `needsLLM` 标志位逻辑，缺 `registerRefineCallback` 方法 | L506-533 |
| `tests/dre-core-modules.test.ts` | 9 处 `verifyResult` 调用未 `await` | L901/909/917/931/932/1279/1305/1330/1351 |
| `tests/cognitive-modules.test.ts` | 缺 `field_match` 维度用例 | L411 `});` 前 |
| `tests/dre-core-modules.test.ts` | 缺 refine 循环 4 用例 + needsLLM 消费 1 用例 | P0-4 块后 |

### 未执行（Task 5）

`bun run lint` + `bun test` 全量验证。

## Proposed Changes

### Task 3: 消费 needsLLM 信号 + 修复 broken 调用

**文件**：`src/dre/runtime/reasoner/reasoning-runtime.ts`

#### 3.1 新增 import（L20 后）

在 `import { ConstraintSolver, createDefaultConstraintSolver } from "../../constraint/solver.js";` 后新增：

```ts
import type { RefineCallback } from "../verification-engine.js";
```

用 `import type` 避免运行时循环依赖（verification-engine 不 import reasoning-runtime，但保持 type-only 更安全）。

#### 3.2 新增字段（L61 `private constraintSolver` 后）

```ts
/**
 * Optional refine callback invoked by verification stage when verifyResult
 * returns non-pass. Injected via registerRefineCallback to break the
 * ReasoningRuntime → DREngine circular dependency (same pattern as fillGap).
 */
private refineCallback: RefineCallback | null = null;
```

#### 3.3 新增方法（`fillGap` 方法后，约 L229）

```ts
/**
 * Register a refine callback for the verification stage.
 *
 * When set, the verification stage passes this callback to verifyResult.
 * On non-pass verdicts, verifyResult invokes the callback to let an LLM
 * (typically DREngine.consciousnessStep) refine the result, then re-verifies.
 *
 * Follows the same dependency-injection pattern as fillGap's llmCaller:
 * ReasoningRuntime deliberately does not hold a DREngine reference.
 */
registerRefineCallback(cb: RefineCallback): void {
  this.refineCallback = cb;
}
```

#### 3.4 改造 verification stage（L506-533）

**替换前**（当前 broken 代码）：

```ts
const report = verificationEngine.verifyResult(
  `pipeline_${Date.now()}`,
  JSON.stringify(ctx.result),
  {
    constraintSolver: this.constraintSolver,
    constraintContext,
  },
);

const verified = report.overallVerdict === "pass";
const confidence = report.overallConfidence;

eventBus.publish({
  type: "pipeline.verification",
  source: "reasoning-runtime",
  data: {
    result: ctx.result,
    verified,
    confidence,
    issues: report.issues.map((i) => i.description),
  },
  priority: "normal",
});

// If verification fails, mark as needing LLM
if (!verified && confidence < 0.5) {
  ctx.needsLLM = true;
}
```

**替换后**（修复 + 消费 refine）：

```ts
const report = await verificationEngine.verifyResult(
  `pipeline_${Date.now()}`,
  JSON.stringify(ctx.result),
  {
    constraintSolver: this.constraintSolver,
    constraintContext,
    refineCallback: this.refineCallback ?? undefined,
    maxRefine: 2,
  },
);

// Consume refined result if the callback produced one
if (typeof report.finalResult === "string" && report.finalResult !== JSON.stringify(ctx.result)) {
  try {
    ctx.result = JSON.parse(report.finalResult);
  } catch {
    ctx.result = report.finalResult; // non-JSON string; use as-is
  }
}

// needsLLM signal from verification drives downstream LLM routing
ctx.needsLLM = report.needsLLM;

eventBus.publish({
  type: "pipeline.verification",
  source: "reasoning-runtime",
  data: {
    result: ctx.result,
    verified: report.overallVerdict === "pass",
    confidence: report.overallConfidence,
    issues: report.issues.map((i) => i.description),
    refineIterations: report.refineIterations ?? 0,
  },
  priority: "normal",
});
```

**改动要点**：
1. `await` 修复 async 调用（解决 broken state）
2. 传入 `refineCallback` 和 `maxRefine: 2`
3. 消费 `report.finalResult`（refine 后的结果回写 `ctx.result`）
4. `ctx.needsLLM = report.needsLLM` 取代旧的 `confidence < 0.5` 启发式
5. 删除 `verified` / `confidence` 局部变量（直接读 report 字段）
6. 事件新增 `refineIterations` 字段供下游观测

---

### Task 4: 测试覆盖

#### 4.1 修复 9 处 broken 调用

**文件**：`tests/dre-core-modules.test.ts`

| 行号 | 改动 |
|------|------|
| L901 | `const report = verificationEngine.verifyResult(...)` → `const report = await verificationEngine.verifyResult(...)` |
| L909 | 同上 |
| L917 | 同上 |
| L931 | `verificationEngine.verifyResult("stats-1", "valid");` → `await verificationEngine.verifyResult("stats-1", "valid");` |
| L932 | 同上 |
| L1279 | 同上 |
| L1305 | 同上 |
| L1330 | 同上 |
| L1351 | 同上 |

所有 9 处的包裹函数都已是 `async`（test callback 是 `async () => {...}`），所以加 `await` 不需改函数签名。TypeScript 编译器会强制提示，无静默回归。

#### 4.2 新增 field_match 维度用例

**文件**：`tests/cognitive-modules.test.ts`

在 `describe("ConstraintSolver", ...)` 块末尾（L411 `});` 前）新增：

```ts
test("should support field_match dimension after rename", () => {
  solver.register({
    id: "test-field-match-1",
    dimension: "field_match",
    type: "equals",
    name: "测试字段匹配",
    description: "验证改名后 field_match 维度可用",
    subject: "test_field",
    target: "expected_value",
    priority: 1,
    enabled: true,
    createdAt: Date.now(),
  });
  const fm = solver.listByDimension("field_match");
  expect(fm.length).toBeGreaterThan(0);
  expect(fm.every((c) => c.dimension === "field_match")).toBe(true);

  // field_match 约束在 context 匹配时应通过
  solver.updateContext("test_field", "expected_value");
  const ok = solver.check("any_action", { test_field: "expected_value" });
  expect(ok.satisfied).toBe(true);
});
```

#### 4.3 新增 refine 循环测试（4 用例）

**文件**：`tests/dre-core-modules.test.ts`

在 P0-4 块后（L1359 `});` 后）新增：

```ts
// ========== P1: Verification Refine Loop ==========

describe("VerificationEngine refine loop (P1)", () => {
  test("refine loop converges when callback fixes issues", async () => {
    const { verificationEngine } = await import("../src/dre/runtime/verification-engine.js");
    let callCount = 0;
    const refineCb = async (_result: unknown, report: VerificationReport) => {
      callCount++;
      return `refined result with evidence and source references (fixed ${report.issues.length} issues)`;
    };
    const report = await verificationEngine.verifyResult(
      "refine-test-1",
      "bad", // 初始 result 缺证据 → uncertain/fail
      { refineCallback: refineCb, maxRefine: 2 },
    );
    expect(callCount).toBeGreaterThan(0);
    expect(report.refineIterations).toBeGreaterThan(0);
    expect(typeof report.finalResult).toBe("string");
    expect((report.finalResult as string).includes("refined result")).toBe(true);
  });

  test("refine loop stops when no progress", async () => {
    const { verificationEngine } = await import("../src/dre/runtime/verification-engine.js");
    let callCount = 0;
    const refineCb = async () => {
      callCount++;
      return "same short"; // 始终返回短结果，置信度不提升
    };
    const report = await verificationEngine.verifyResult(
      "refine-test-2",
      "same short",
      { refineCallback: refineCb, maxRefine: 3 },
    );
    // 无进展应早停（首次 refine 后置信度未提升 → 不再迭代）
    expect(callCount).toBeLessThanOrEqual(2);
    expect(report.refineIterations ?? 0).toBeLessThanOrEqual(2);
  });

  test("refine loop respects maxRefine limit", async () => {
    const { verificationEngine } = await import("../src/dre/runtime/verification-engine.js");
    let callCount = 0;
    const refineCb = async (_r: unknown, report: VerificationReport) => {
      callCount++;
      // 每次返回不同但有证据的长结果，使置信度持续提升但 verdict 可能仍非 pass
      return `attempt-${callCount} refined result with evidence and source references (issues: ${report.issues.length})`;
    };
    const report = await verificationEngine.verifyResult(
      "refine-test-3",
      "initial short",
      { refineCallback: refineCb, maxRefine: 2 },
    );
    expect(callCount).toBeLessThanOrEqual(2);
    expect(report.refineIterations ?? 0).toBeLessThanOrEqual(2);
  });

  test("verifyResult without refineCallback is backward compatible", async () => {
    const { verificationEngine } = await import("../src/dre/runtime/verification-engine.js");
    const report = await verificationEngine.verifyResult(
      "refine-test-4",
      "valid result with evidence and source references",
    );
    expect(report.refineIterations).toBe(0);
    expect(report.finalResult).toBe("valid result with evidence and source references");
    expect(report.overallVerdict).toBe("pass");
  });
});
```

#### 4.4 新增 needsLLM 消费测试

**文件**：`tests/dre-core-modules.test.ts`

在 refine loop 块后新增：

```ts
// ========== P1: ReasoningRuntime Refine Callback Wiring ==========

describe("ReasoningRuntime refine callback (P1)", () => {
  test("registerRefineCallback wires into verification stage without throwing", async () => {
    const { ReasoningRuntime } = await import("../src/dre/runtime/reasoner/reasoning-runtime.js");
    const runtime = new ReasoningRuntime();

    let refineInvoked = false;
    runtime.registerRefineCallback(async () => {
      refineInvoked = true;
      return "refined result with evidence and source references from mock LLM";
    });

    // run() 触发 verification stage；refineCallback 是否被调用取决于
    // graph-reasoning/planning 阶段是否产出 ctx.result。这里只验证：
    // 1. 注册后不抛错
    // 2. run() 完整执行无异常
    // 3. 若 refine 被触发，不抛错
    await runtime.run("test-input-for-refine-wiring");
    expect(typeof refineInvoked).toBe("boolean");
  });

  test("registerRefineCallback accepts null-safe default (no callback registered)", async () => {
    const { ReasoningRuntime } = await import("../src/dre/runtime/reasoner/reasoning-runtime.js");
    const runtime = new ReasoningRuntime();
    // 不注册 refineCallback，验证 verification stage 用 undefined 也不抛错
    const ctx = await runtime.run("test-input-no-refine");
    expect(ctx).toBeDefined();
    expect(typeof ctx.needsLLM).toBe("boolean");
  });
});
```

---

### Task 5: 验证步骤

```bash
# 1. 类型检查（必须先过——Task 2 引入的 breaking change 在 Task 3-4 修复后应无错误）
bun run lint

# 2. 单元测试（按依赖顺序）
bun test tests/cognitive-modules.test.ts   # 含新 field_match 用例
bun test tests/dre-core-modules.test.ts    # 含 9 处 await 修复 + refine 循环 + needsLLM 消费
bun test tests/context-engine.test.ts      # 无回归
bun test tests/cognitive-pipeline.test.ts  # 无回归

# 3. 全量测试
bun test
```

**预期结果**：
- `bun run lint`：0 类型错误（Task 2 的 breaking change 在 Task 3-4 修复后闭合）
- `tests/cognitive-modules.test.ts`：全部通过（含新 field_match 用例）
- `tests/dre-core-modules.test.ts`：全部通过（含 9 处 await 修复 + 5 个新用例）
- 全量测试：失败数 ≤ 34（P0 收尾后的基线，全部为预先存在的超时/单例污染，无新增回归）

## Assumptions & Decisions

1. **复用已批准的 P1 设计**：API 形状（`registerRefineCallback` + `refineCallback` 字段 + 回调式签名）来自已批准的 `.trae/documents/axiom-runtime-p1-verification.md`，不再重新决策。
2. **`import type` for RefineCallback**：避免运行时循环依赖。verification-engine.ts 不 import reasoning-runtime.ts，但 type-only 更安全且零运行时成本。
3. **`finalResult` 比较用 `JSON.stringify(ctx.result)`**：判断 refine 是否真的改变了 result，避免无谓的 JSON.parse。若 refine 返回的字符串等于原序列化结果，跳过回写。
4. **`ctx.needsLLM = report.needsLLM`** 直接赋值而非与现有标志位 OR：verification 是 needsLLM 的最终仲裁者（planning stage 设置的 needsLLM 会在 verification 之前被 early-exit 跳过——见 reasoning-runtime.ts L147 `if (ctx.result && !ctx.needsLLM)`）。若 verification 通过且 refine 收敛，needsLLM 应为 false。
5. **测试用 mock refineCallback**：不接真实 LLM，用闭包计数 + 固定返回值验证循环逻辑。这与 fillGap 的测试策略一致（P0-3 的 `fillGap invokes supplied llmCaller` 也是 mock）。
6. **不触碰 prod 单例的 refineCallback 注册**：`getReasoningRuntime()` 单例当前在 prod 无调用方（grep 确认）。refineCallback 的 prod 注入点留给未来 bootstrap 处理，本计划只保证 API 可用 + 测试覆盖。

## Verification Checklist

- [ ] `reasoning-runtime.ts` 新增 `import type { RefineCallback }`
- [ ] `reasoning-runtime.ts` 新增 `private refineCallback` 字段
- [ ] `reasoning-runtime.ts` 新增 `registerRefineCallback` 方法
- [ ] `reasoning-runtime.ts` verification stage 加 `await` + 传 `refineCallback` + `maxRefine: 2`
- [ ] `reasoning-runtime.ts` verification stage 消费 `finalResult`（带 JSON.parse try/catch）
- [ ] `reasoning-runtime.ts` verification stage 用 `ctx.needsLLM = report.needsLLM` 取代旧启发式
- [ ] `reasoning-runtime.ts` 删除 `if (!verified && confidence < 0.5) { ctx.needsLLM = true; }`
- [ ] `dre-core-modules.test.ts` 9 处 `verifyResult` 调用加 `await`
- [ ] `cognitive-modules.test.ts` 新增 field_match 维度用例
- [ ] `dre-core-modules.test.ts` 新增 refine 循环 4 用例（收敛/无进展/maxRefine/向后兼容）
- [ ] `dre-core-modules.test.ts` 新增 needsLLM 消费 2 用例
- [ ] `bun run lint` 0 错误
- [ ] `bun test tests/cognitive-modules.test.ts` 通过
- [ ] `bun test tests/dre-core-modules.test.ts` 通过
- [ ] `bun test` 全量失败数 ≤ 34（无新增回归）

## Remaining Tasks (out of scope, deferred to P2)

- **prod 接入 refineCallback**：`getReasoningRuntime()` 单例当前在 prod 无调用方。未来接入时由持有 `DREngine` 的 bootstrap 处注册真实 LLM 回调（参考 P1 计划文件中的注入点示例）。
- **EpisodicMemory 多因子检索**：search 当前是 dead code，需先接入调用点（P2 范围）。
- **WorldState LRU**：改动面广、回归风险高（P2 范围）。
- **真正的 LLM 语义判断**：refine 循环已提供框架，LLM 兜底实现留待 P2。
