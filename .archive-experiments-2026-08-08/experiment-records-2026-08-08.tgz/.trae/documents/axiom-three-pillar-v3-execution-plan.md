# Axiom Runtime v4.0 — 三支柱系统化优化执行计划（v3，校准落地版）

> 本计划在 v2（`axiom-three-pillar-optimization-execution-plan.md`）基础上，经 Phase 1 全量直接读码校准后产出。
> **v3 相对 v2 的关键修正**：
> 1. **Task 1.1 已完成**：P0 认证绕过漏洞已被 prior commits `b26821b`（`feat(security): 认证逻辑抽取 auth-check.ts + P0 回归测试`）+ `ad17ea6`（`fix(security): P0 认证绕过改用 socket 地址判定`）修复。`src/utils/auth-check.ts` 已存在（60 行，含 `isLocalAddress()` + `checkApiKey()`），`tests/auth-check.test.ts` 已存在（9 项回归测试，3821 bytes）。**Task 1.1 跳过执行**，仅需清理遗留备份 `.tmp/backups/src/main.ts.bak`（24412 bytes，因未修改 main.ts）。
> 2. **process.env 迁移已完成**：`rg "process\.env" src/knowledge/ src/routes/models.ts` 返回 0 匹配。`knowledge/pipeline.ts:40` 已用 `readString("ZHIPU_API_KEY")`。Task 3.4 的 process.env 子任务**取消**，仅保留 preprocessor/quality-assessor 集成。
> 3. **`ConformalHallucinationDetector.verify(statement, context?)`** 确认为公开方法（[hallucination-detector.ts:344](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L344)），Phase 2.2 直接调用。
> 4. **plugin 路由经 `plugin-adapter.ts` 包装**，敏感操作在 `handlePluginRoutes`（[plugin-adapter.ts:26](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts#L26)）内的 install/uninstall/enable/disable/configure 5 个分支加守卫。
> 5. **vault.ts 有 5 个 POST 写入端点**需加守卫（handleVaultWrite / handleVaultAtomic / handleVaultDistill / handleVaultCodeIndex / handleVaultReload）。

## 摘要（Summary）

用户要求对项目进行系统性优化，聚焦三大支柱：(1) 网络检索优化（过滤/评分/抽取），(2) 知识整理准备（格式/预处理/质量评估），(3) 安全措施完善（审计/加密/访问控制/监控/策略）。

本计划将三大支柱映射为 **4 个串行阶段**（Phase 1+4 = 安全，Phase 2 = 检索，Phase 3 = 知识），每阶段独立可发布，全程遵守 `AGENTS.md` 五条强约束。

**约束**（[AGENTS.md](file:///d:/openclaw-fusion/AGENTS.md)）:
1. 最小化施工，禁止过度施工
2. 改代码前：备份到 `.tmp/backups/` → 读全文 → 修改 → 验证 → 删备份
3. 提交到 `internal211` 远端（`ssh://data@192.168.2.11/home/data/openclaw-fusion.git`）
4. 删除 = 归档到 `archive/` + 写 `archive/ARCHIVE-LOG.md`
5. 操作留痕 `docs/operations-log.md`（提交一次记录一次）

---

## 现状分析（Current State Analysis — 全部经直接读码确认）

### 安全现状
| 项 | 现状 | 文件:行 | 风险 |
|----|------|---------|------|
| 本地认证 | ✅ **已修复**：`server.requestIP(req)?.address` + `isLocalAddress()` | [main.ts:429-430](file:///d:/openclaw-fusion/src/main.ts#L429), [auth-check.ts:15](file:///d:/openclaw-fusion/src/utils/auth-check.ts#L15) | 无 |
| 审计日志 | 无 | — | 敏感操作无留痕 |
| Logger 脱敏 | 无（`serialize()` 原样输出 context） | [logger.ts:212-227](file:///d:/openclaw-fusion/src/utils/logger.ts#L212) | 日志可能泄漏 token |
| 敏感端点二次认证 | 仅 `/api-keys` 有 `requireAuth` | [api-keys.ts:36-55](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L36) | vault/sandbox/plugin 裸奔 |
| API Key 存储 | **明文** `api_key TEXT NOT NULL` | [api-key-persistence.ts:22](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts#L22) | DB 泄漏即 key 泄漏 |
| 限流 | 单维（全局 100/min + 3 路径规则），已用 socket IP | [rate-limiter.ts:101-122](file:///d:/openclaw-fusion/src/utils/rate-limiter.ts#L101) | 无 per-user 维度 |
| 沙箱 Windows | **无资源限制**（仅 timeout） | [process-sandbox.ts:28-30](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L28) | 内存/CPU/输出无界 |
| 沙箱 Linux | `ulimit -v` + `ulimit -t`，无网络/文件大小限制 | [process-sandbox.ts:33-47](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L33) | 无文件大小/网络限制 |
| WebSocket 上限 | 硬编码 `MAX_WS_CLIENTS = 100` | [websocket.ts:29](file:///d:/openclaw-fusion/src/utils/websocket.ts#L29) | 不可配置 |
| 健康检查 | 8 项，无 security 项 | [health-checker.ts:58-67](file:///d:/openclaw-fusion/src/core/health-checker.ts#L58) | 安全事件不可观测 |

### 检索现状
| 项 | 现状 | 文件:行 |
|----|------|---------|
| 结果过滤 | 无（直接抓取） | [data-pipeline.ts:853](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L853) `crawlSearchResults` |
| 质量评分 | 单一 0-100 分（private `calculateQualityScore`） | [data-pipeline.ts:814](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L814) |
| 多维打分 | 无 | — |
| 结构化抽取 | 无统一 zod schema | — |
| HTML 噪声清理 | `DEFAULT_NOISE_RE`（9 个 pattern） | [data-pipeline.ts:24-35](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L24) |
| 内容分块 | `chunkByHeadings`（private 方法） | [data-pipeline.ts:717](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L717) |
| 幻觉检测 | ✅ `ConformalHallucinationDetector.verify()` 已存在可复用 | [hallucination-detector.ts:344](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L344) |
| 搜索结果类型 | `SearchEngineResult` interface 已导出 | [search-engines.ts:12](file:///d:/openclaw-fusion/src/crawl/search-engines.ts#L12) |

### 知识现状
| 项 | 现状 | 文件:行 |
|----|------|---------|
| 类型定义 | 4 个接口（无 zod schema） | [types.ts:3-41](file:///d:/openclaw-fusion/src/knowledge/types.ts#L3) |
| 预处理 | 无独立模块（GLM 直接吃 rawMarkdown） | [pipeline.ts:53](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L53) |
| 质量评估 | 无（GLM 返回 `quality_score` 单值） | [pipeline.ts:34](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L34) |
| process.env 违规 | ✅ **已迁移**（0 处 `process.env`） | [pipeline.ts:40](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L40) 已用 `readString` |
| GLM 集成点 | `structureWithGLM()` 返回后写 JSONL 前 | [pipeline.ts:165-172](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L165) |

---

## Phase 1（Week 1）— 安全基础（P0 已修复，本阶段为补全）

### 目标
1. ~~修复 isLocal Host-header 认证绕过~~（✅ 已完成，跳过）
2. 新增审计日志
3. Logger 密钥脱敏
4. 敏感端点 per-route 二次认证
5. 清理遗留备份

### Task 1.0 — 清理遗留备份（前置）

**操作**: 删除 `.tmp/backups/src/main.ts.bak`（24412 bytes，前序会话创建但未修改 main.ts）。
- 因 Task 1.1 跳过，该备份无用途，按 AGENTS Rule 2 删除。
- 删除非源码文件，无需归档（Rule 4 仅适用于源码/文档删除）。

### Task 1.1 — 跳过（P0 已修复）

**状态**: ✅ 已完成 by commits `b26821b` + `ad17ea6`。
- [src/utils/auth-check.ts](file:///d:/openclaw-fusion/src/utils/auth-check.ts) 已存在（60 行），含 `isLocalAddress(address)` + `checkApiKey(req, isLocal, apiKey)`。
- [tests/auth-check.test.ts](file:///d:/openclaw-fusion/tests/auth-check.test.ts) 已存在（9 项回归测试，3821 bytes）。
- [src/main.ts:429-430](file:///d:/openclaw-fusion/src/main.ts#L429) 已用 `server.requestIP(req)?.address` + `isLocalAddress(remoteAddress)`。

### Task 1.2 — 审计日志模块

**新建**: `src/utils/audit-logger.ts`

**设计要点**:
- 模块加载时**立即注册** metrics（避免 `increment` 被 warn 丢弃，见 [metrics.ts:31-35](file:///d:/openclaw-fusion/src/utils/metrics.ts#L31)）。
- 注册两个 counter：`audit_event_total`（本任务用）+ `security_alert_total`（Phase 4.4 用，提前注册避免后续重复注册逻辑）。
- 写 JSON Lines 到 `data/logs/audit.log`，同步追加（`fs.appendFileSync`）。
- 文件轮转：超 `maxSize` rename 加时间戳，保留 `maxFiles` 个。复用 [logger.ts:89-106](file:///d:/openclaw-fusion/src/utils/logger.ts#L89) `rotateIfNeeded()` 模式的简化版。

**API 设计**:
```typescript
export type AuditEvent =
  | "auth.success" | "auth.failure"
  | "vault.write" | "sandbox.execute" | "plugin.install" | "plugin.uninstall"
  | "plugin.enable" | "plugin.disable" | "plugin.configure"
  | "apikey.set" | "apikey.delete" | "apikey.test"
  | "rate_limit.exceeded" | "config.change" | "ws_flood" | "security.alert";

export type AuditOutcome = "success" | "failure" | "denied";

export interface AuditEntry {
  timestamp: string;            // ISO 8601
  event: AuditEvent;
  actor: string;                // IP 或 "unknown"
  resource?: string;            // 受影响的资源路径/ID
  outcome: AuditOutcome;
  reason?: string;
  metadata?: Record<string, unknown>;
}

export class AuditLogger {
  constructor(opts?: { filePath?: string; maxSize?: number; maxFiles?: number });
  log(entry: Omit<AuditEntry, "timestamp">): void;  // 同步追加 JSON Lines + metrics.increment
}

export const auditLogger: AuditLogger;  // 默认单例，写 data/logs/audit.log
```

**模块初始化段**（文件顶部 import 后）:
```typescript
import { metrics } from "./metrics.js";
metrics.register({ name: "audit_event_total", help: "Audit events by type and outcome", type: "counter" });
metrics.register({ name: "security_alert_total", help: "Security alerts by severity", type: "counter" });
```

**`log()` 内部**:
```typescript
log(entry: Omit<AuditEntry, "timestamp">): void {
  const full: AuditEntry = { timestamp: new Date().toISOString(), ...entry };
  this.rotateIfNeeded();
  fs.appendFileSync(this.filePath, JSON.stringify(full) + "\n");
  metrics.increment("audit_event_total", 1, { event: entry.event, outcome: entry.outcome });
  if (entry.event === "security.alert") {
    metrics.increment("security_alert_total", 1, { severity: String(entry.metadata?.severity ?? "medium") });
  }
}
```

**新增测试**: `tests/audit-logger.test.ts`
- 写入格式：JSON Lines 可 parse，字段完整（timestamp/event/actor/outcome 必填）。
- metrics 计数器递增：连续 log 3 次 → `audit_event_total` 对应 labels +3。
- 轮转触发：设 `maxSize=1024` 写 2KB → 触发 rename，原文件清空，旧文件保留 `.iso`。
- 单例导出：`auditLogger` 是 AuditLogger 实例。

### Task 1.3 — Logger 密钥脱敏

**修改**: [src/utils/logger.ts](file:///d:/openclaw-fusion/src/utils/logger.ts)（251 行）

**AGENTS Rule 2 流程**: 备份 → 读全文（已读 251 行）→ 修改 `serialize()` → 验证 → 删备份。

**改动点 1**（顶部 import，[line 5-6](file:///d:/openclaw-fusion/src/utils/logger.ts#L5) 后新增）:
```typescript
import { sanitizeRequestBody } from "./security.js";
```

**改动点 2**（class Logger 内，新增私有方法 `redactContext`，紧邻 `serialize` 之前）:
```typescript
/** 敏感值正则：捕获常见密钥格式（key-based 脱敏由 sanitizeRequestBody 处理，此处补 value-based） */
private static readonly SECRET_VALUE_RE =
  /(sk-[A-Za-z0-9]{8,}|Bearer\s+[A-Za-z0-9._-]+|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{36}|glpat-[A-Za-z0-9_-]{20}|xoxb-[0-9A-Za-z-]+)/g;

private redactContext(ctx: Record<string, unknown>): Record<string, unknown> {
  // 1. key-based 脱敏（递归，复用 security.ts）
  const cleaned = sanitizeRequestBody(ctx) as Record<string, unknown>;
  // 2. value-based 脱敏（扫描字符串值中的密钥模式）
  for (const [k, v] of Object.entries(cleaned)) {
    if (typeof v === "string") {
      cleaned[k] = v.replace(Logger.SECRET_VALUE_RE, "[REDACTED]");
    }
  }
  return cleaned;
}
```

**改动点 3**（`serialize()` 方法，[line 212-227](file:///d:/openclaw-fusion/src/utils/logger.ts#L212)）:
```typescript
private serialize(entry: LogEntry): Record<string, unknown> {
  const obj: Record<string, unknown> = {
    timestamp: entry.timestamp,
    level: entry.level,
    message: entry.message,
  };
  if (entry.context && Object.keys(entry.context).length) {
    obj.context = this.redactContext(entry.context);  // ← 改动：原为 obj.context = entry.context
  }
  if (entry.error) {
    const msg = entry.error.message?.replace(Logger.SECRET_VALUE_RE, "[REDACTED]") ?? "";
    const stack = entry.error.stack?.replace(Logger.SECRET_VALUE_RE, "[REDACTED]");
    obj.error = { name: entry.error.name, message: msg, stack };
  }
  return obj;
}
```

**新增测试**: `tests/logger-redact.test.ts`
- `logger.info("x", { api_key: "sk-abcd1234efgh5678" })` → 文件输出含 `[REDACTED]`，不含原始 key。
- `logger.info("x", { token: "Bearer abc123" })` → `[REDACTED]`。
- `logger.info("x", { normal: "hello", nested: { password: "pw" } })` → `hello` 保留，`nested.password` 为 `[REDACTED]`。
- `logger.info("x", { url: "https://api.com?token=sk-abcd1234efgh5678" })` → URL 中密钥被替换为 `[REDACTED]`。
- `logger.info("x", { count: 42, list: [1, 2] })` → 非字符串值不受影响。
- 测试策略：构造临时 Logger 实例 `new Logger({ outputs: [{type:"file", path: tmpPath}], format: "json" })`，写后读文件验证。

### Task 1.4 — 敏感端点 per-route 二次认证

**新建**: `src/utils/route-auth.ts`
```typescript
import type { RouteContext } from "../routes/types.js";
import { readString } from "./env.js";
import { auditLogger } from "./audit-logger.js";

/**
 * 敏感端点二次认证守卫。
 * - 未配置 AXIOM_AUTH_TOKEN → 503（fail-closed，与 api-keys.ts:38 一致）
 * - token 不匹配 → 401 + 审计日志
 * - 通过 → 返回 null，调用方继续
 */
export function requireAuthToken(ctx: RouteContext): Response | null {
  const token = readString("AXIOM_AUTH_TOKEN");
  const actor = ctx.req.headers.get("x-real-ip") || "unknown";
  if (!token) {
    auditLogger.log({
      event: "auth.failure", actor, outcome: "denied",
      reason: "AXIOM_AUTH_TOKEN not configured", resource: ctx.url.pathname,
    });
    return ctx.jsonResponse({ error: "Server auth not configured (AXIOM_AUTH_TOKEN missing)" }, 503, ctx.baseHeaders);
  }
  const provided = ctx.req.headers.get("x-api-key") ||
    ctx.req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (provided !== token) {
    auditLogger.log({
      event: "auth.failure", actor, outcome: "denied",
      reason: "invalid or missing token", resource: ctx.url.pathname,
    });
    return ctx.jsonResponse({ error: "Unauthorized" }, 401, ctx.baseHeaders);
  }
  return null;
}

/** 成功审计辅助：敏感操作完成后调用 */
export function auditSuccess(
  ctx: RouteContext,
  event: "vault.write" | "sandbox.execute" | "plugin.install" | "plugin.uninstall" |
        "plugin.enable" | "plugin.disable" | "plugin.configure" | "apikey.set" | "apikey.delete" | "apikey.test",
  resource?: string,
  metadata?: Record<string, unknown>,
): void {
  auditLogger.log({
    event, actor: ctx.req.headers.get("x-real-ip") || "unknown",
    outcome: "success", resource: resource ?? ctx.url.pathname, metadata,
  });
}
```

**修改 1**: [src/routes/api-keys.ts](file:///d:/openclaw-fusion/src/routes/api-keys.ts)
- 删除本地 `requireAuth`（[line 36-55](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L36)）。
- 顶部新增 import: `import { requireAuthToken, auditSuccess } from "../utils/route-auth.js";`
- `handleApiKeys` 中 `requireAuth(ctx)` → `requireAuthToken(ctx)`（[line 72](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L72)）。
- POST 成功后加 `auditSuccess(ctx, "apikey.set", provider)`（[line 122](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L122) 后）。
- DELETE 成功后加 `auditSuccess(ctx, "apikey.delete", provider)`（[line 159](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L159) 后）。
- test 成功后加 `auditSuccess(ctx, "apikey.test", provider, { ok: result.ok })`（[line 195](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L195) 后）。

**修改 2**: [src/routes/vault.ts](file:///d:/openclaw-fusion/src/routes/vault.ts) — 5 个 POST handler 加守卫
每个 handler 在路径匹配后、业务逻辑前加：
```typescript
const authErr = requireAuthToken(ctx);
if (authErr) return authErr;
```
位置（精确行号）:
- `handleVaultWrite`（[line 91](file:///d:/openclaw-fusion/src/routes/vault.ts#L91) 后）
- `handleVaultAtomic`（[line 103](file:///d:/openclaw-fusion/src/routes/vault.ts#L103) 后）
- `handleVaultDistill`（[line 143](file:///d:/openclaw-fusion/src/routes/vault.ts#L143) 后）
- `handleVaultCodeIndex`（[line 115](file:///d:/openclaw-fusion/src/routes/vault.ts#L115) 后）
- `handleVaultReload`（[line 124](file:///d:/openclaw-fusion/src/routes/vault.ts#L124) 后）
- 写入成功后调用 `auditSuccess(ctx, "vault.write", notePath)`（仅在 handleVaultWrite 和 handleVaultAtomic 成功路径）。
- 顶部 import: `import { requireAuthToken, auditSuccess } from "../utils/route-auth.js";`

**修改 3**: [src/routes/sandbox.ts](file:///d:/openclaw-fusion/src/routes/sandbox.ts) — 1 个 handler 加守卫
- `handleSandboxExecute`（[line 5](file:///d:/openclaw-fusion/src/routes/sandbox.ts#L5) 后，路径匹配通过后立即加）:
```typescript
const authErr = requireAuthToken(ctx);
if (authErr) return authErr;
```
- 执行成功后（[line 65](file:///d:/openclaw-fusion/src/routes/sandbox.ts#L65) 前）：`auditSuccess(ctx, "sandbox.execute", body.command, { exitCode: result.exitCode });`
- 顶部 import: `import { requireAuthToken, auditSuccess } from "../utils/route-auth.js";`

**修改 4**: [src/routes/plugin-adapter.ts](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts) — 5 个分支加守卫
在 `handlePluginRoutes` 内，5 个写操作的 `return pluginRoutes.X(...)` 前各加守卫：
- install（[line 48-50](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts#L48)）→ `requireAuthToken(ctx)` + 成功后 `auditSuccess(ctx, "plugin.install")`
- uninstall（[line 69-73](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts#L69)）→ `requireAuthToken(ctx)` + `auditSuccess(ctx, "plugin.uninstall", id)`
- enable（[line 74-78](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts#L74)）→ `requireAuthToken(ctx)` + `auditSuccess(ctx, "plugin.enable", id)`
- disable（[line 79-83](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts#L79)）→ `requireAuthToken(ctx)` + `auditSuccess(ctx, "plugin.disable", id)`
- configure（[line 84-88](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts#L84)）→ `requireAuthToken(ctx)` + `auditSuccess(ctx, "plugin.configure", id)`

注意：`pluginRoutes.install(req)` 返回 Response，守卫需在调用前。模式：
```typescript
if (path === "/plugins/install" && req.method === "POST") {
  const authErr = requireAuthToken(ctx);
  if (authErr) return authErr;
  const resp = await pluginRoutes.install(req);
  if (resp.ok) auditSuccess(ctx, "plugin.install");
  return resp;
}
```
- 顶部 import: `import { requireAuthToken, auditSuccess } from "../utils/route-auth.js";`

**新增测试**: `tests/route-auth.test.ts`
- 无 token 配置（`AXIOM_AUTH_TOKEN` 未设）→ `requireAuthToken(ctx)` 返回 503 + audit log 含 `auth.failure`/`denied`。
- 错误 token → 401 + audit log。
- 正确 token → 返回 null（放行）。
- `auditSuccess` 写入 audit log 含 `outcome: "success"`。
- 测试策略：mock `readString` 返回值（用 `Bun.env` 或临时 set/unset），构造 mock RouteContext。

### Phase 1 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | Task 1.0（清理备份）+ Task 1.2（audit-logger.ts + 测试） |
| Day 2 | Task 1.3（logger.ts 脱敏 + 测试） |
| Day 3 | Task 1.4（route-auth.ts + 4 路由接入 + 测试） |
| Day 4 | 全量回归 + commit + push internal211 + operations-log |

### Phase 1 评估 Gate
- `tests/audit-logger.test.ts` 通过
- `tests/logger-redact.test.ts` 通过
- `tests/route-auth.test.ts` 通过
- `tests/auth-check.test.ts` 仍通过（9 项，回归）
- `tests/architecture-integrity.test.ts` 不退化
- `bunx tsc --noEmit` 0 错误
- 手工冒烟：无 token 调 `POST /vault/write` → 401 + `data/logs/audit.log` 含 `auth.failure` 条目

---

## Phase 2（Week 2）— Web 检索优化

### 目标
1. 结果过滤器：剔除低质/重复/标题党
2. 多维度打分器：来源可信度 / 内容相关度 / 时效性 / 事实准确度（复用 ConformalHallucinationDetector）
3. LLM 结构化抽取器：zod schema 强制
4. 手术式接入 `data-pipeline.ts`，**扩展** `calculateQualityScore`，不破坏 `searchMulti`/`crawlStructured` 现有契约

### Task 2.1 — 结果过滤器

**新建**: `src/crawl/result-filter.ts`

**依赖类型**（已确认 [search-engines.ts:12](file:///d:/openclaw-fusion/src/crawl/search-engines.ts#L12)）:
```typescript
import type { SearchEngineResult } from "./search-engines.js";

export interface FilterOptions {
  minContentLength?: number;      // 默认 50（snippet 长度下限）
  maxDuplicateRatio?: number;     // 默认 0.8（Jaccard > 此值判重复）
  blockListDomains?: string[];    // 默认空
  blockClickbait?: boolean;       // 默认 true
  languageWhitelist?: string[];   // 默认空（不限制）
}

export interface FilterDecision {
  result: SearchEngineResult;
  kept: boolean;
  reasons: string[];              // 被剔除的原因列表（kept=false 时非空）
}

// 标题党启发式模式（中英文）
const CLICKBAIT_PATTERNS = [
  /^(震惊|吓呆|惊呆|不可思议|竟然|居然|万万没想到)/,
  /\d+\s*(个|条|件).+(理由|原因|秘密|真相)/,
  /^(you\s*won'?t\s*believe|amazing|incredible|shocking)/i,
  /\bclick\s*here\b/i,
];

export function filterResults(
  results: SearchEngineResult[],
  options?: FilterOptions,
): FilterDecision[];

// 内部工具（导出供测试）
export function jaccardSimilarity(a: string, b: string): number;
export function isClickbait(title: string): boolean;
export function isBlockedDomain(url: string, blocklist: string[]): boolean;
```

**过滤逻辑**（按顺序短路）:
1. 域名黑名单匹配 → 剔除（reason: "blocked_domain"）
2. 标题党检测（`blockClickbait=true` 时）→ 剔除（reason: "clickbait_title"）
3. snippet 长度 < `minContentLength` → 剔除（reason: "content_too_short"）
4. 语言白名单不匹配 → 剔除（reason: "language_filtered"）
5. 与已保留结果 Jaccard > `maxDuplicateRatio` → 剔除（reason: "duplicate"）
6. 否则保留（kept=true, reasons=[]）

**Jaccard 实现**（复制等价逻辑，避免依赖 hallucination-detector 的非导出函数）:
```typescript
export function jaccardSimilarity(a: string, b: string): number {
  const ta = new Set(a.toLowerCase().split(/\s+|[^\w\u4e00-\u9fff]/).filter(s => s.length > 1));
  const tb = new Set(b.toLowerCase().split(/\s+|[^\w\u4e00-\u9fff]/).filter(s => s.length > 1));
  if (ta.size === 0 && tb.size === 0) return 1.0;
  if (ta.size === 0 || tb.size === 0) return 0.0;
  let inter = 0;
  for (const t of ta) if (tb.has(t)) inter++;
  return inter / (ta.size + tb.size - inter);
}
```

**新增测试**: `tests/crawl-filter.test.ts`（含在 `tests/crawl-filter-score-extract.test.ts` 聚合文件中）
- 空结果数组 → 返回空数组
- 全部保留：3 个不同域名、不同标题的结果 → 全部 kept=true
- 标题党剔除：title="震惊！10 个理由..." → kept=false, reasons 含 "clickbait_title"
- 重复剔除：两个结果 snippet 几乎相同 → 第二个 kept=false, reasons 含 "duplicate"
- 黑名单：blockListDomains=["spam.com"] → 该域名结果剔除
- 内容过短：snippet="" → 剔除

### Task 2.2 — 多维度打分器

**新建**: `src/crawl/result-scorer.ts`

**复用**（已确认 [hallucination-detector.ts:344](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L344) `verify(statement, context?)` 是公开方法）:
```typescript
import { ConformalHallucinationDetector, type FactEntry } from "../memory/hallucination-detector.js";

export interface ScoreDimensions {
  credibility: number;   // 来源可信度 0-1
  relevance: number;     // 内容相关度 0-1
  timeliness: number;    // 时效性 0-1
  factualAccuracy: number; // 事实准确度 0-1（基于幻觉检测）
}

export interface ScoredResult {
  result: SearchEngineResult;
  dimensions: ScoreDimensions;
  totalScore: number;    // 加权总分 0-100
  evidence: EvidenceItem[]; // 来自 hallucination-detector
}

export interface ScorerOptions {
  query?: string;                              // 用于 relevance 计算
  factBase?: FactEntry[];                       // 用于 factualAccuracy
  credibilityDomains?: Record<string, number>;  // 域名 → 可信度映射
  weights?: Partial<{ credibility: number; relevance: number; timeliness: number; factualAccuracy: number }>;
  // 默认权重：credibility 0.25, relevance 0.35, timeliness 0.15, factualAccuracy 0.25
}

export class ResultScorer {
  private detector: ConformalHallucinationDetector | null = null;
  constructor(opts?: ScorerOptions) {
    if (opts?.factBase && opts.factBase.length > 0) {
      this.detector = new ConformalHallucinationDetector({ alpha: 0.05, factBase: opts.factBase });
    }
  }
  score(results: SearchEngineResult[], opts?: ScorerOptions): ScoredResult[];
}

// 独立导出各维度计算函数（便于单测）
export function scoreCredibility(url: string, domainMap?: Record<string, number>): number;
export function scoreRelevance(query: string, text: string): number;
export function scoreTimeliness(dateStr?: string): number;
export function scoreFactualAccuracy(text: string, detector: ConformalHallucinationDetector | null): { score: number; evidence: EvidenceItem[] };
```

**各维度算法**:

1. **credibility（来源可信度）**:
   - 域名映射表优先：`credibilityDomains[domain]`（如 `{"github.com": 0.95, "arxiv.org": 0.9, "wikipedia.org": 0.85}`）
   - 未匹配：HTTPS=0.5 基础分 + 域名年龄启发式（.edu/.gov=+0.3, .org=+0.15, 其他=0）
   - 截断到 [0, 1]

2. **relevance（内容相关度）**:
   - `jaccardSimilarity(query, title + " " + snippet)`（复用 result-filter.ts 的 jaccard）
   - 标题命中加权 ×1.5（标题更相关则内容更可能相关）
   - 截断到 [0, 1]

3. **timeliness（时效性）**:
   - 无日期 → 0.5（中性）
   - 有日期：`max(0, 1 - ageDays / 365)`（一年内得高分，超过一年线性衰减到 0）
   - 解析 `result.date`（[SearchEngineResult.date?](file:///d:/openclaw-fusion/src/crawl/search-engines.ts#L12)）和 `displayedUrl` 中的日期模式

4. **factualAccuracy（事实准确度）**:
   - 无 detector（factBase 为空）→ 0.5（中性，不惩罚）
   - 有 detector：调 `detector.verify(text)` → 返回 `{ score: verdict.confidence, evidence: verdict.evidence }`
   - `verdict.isHallucination === true` → score 直接为 0

**totalScore 加权**:
```typescript
const w = { credibility: 0.25, relevance: 0.35, timeliness: 0.15, factualAccuracy: 0.25, ...opts?.weights };
const total = (d.credibility * w.credibility + d.relevance * w.relevance +
               d.timeliness * w.timeliness + d.factualAccuracy * w.factualAccuracy) * 100;
```

**新增测试**: `tests/crawl-score.test.ts`（聚合在 `tests/crawl-filter-score-extract.test.ts`）
- credibility：github.com → 0.95；未知 https 域名 → 0.5；.edu 域名 → 0.8
- relevance：query="rust async" snippet="rust async runtime tokio" → 高分；不相关 snippet → 低分
- timeliness：无日期 → 0.5；今天日期 → ~1.0；2 年前 → ~0.0
- factualAccuracy：空 factBase → 0.5；factBase 含匹配事实 → 高分；factBase 与陈述矛盾 → 低分
- totalScore：4 维各 0.5 → 50；各 1.0 → 100

### Task 2.3 — LLM 结构化抽取器

**新建**: `src/crawl/data-extractor.ts`

**zod schema 定义**（用于强校验 LLM 输出）:
```typescript
import { z } from "zod";

export const ExtractedFactSchema = z.object({
  claim: z.string().min(1),
  subject: z.string().optional(),
  predicate: z.string().optional(),
  object: z.string().optional(),
  source: z.string().optional(),
  confidence: z.number().min(0).max(1).default(0.5),
  verified: z.boolean().default(false),
});
export type ExtractedFact = z.infer<typeof ExtractedFactSchema>;

export const StructuredExtractionSchema = z.object({
  title: z.string(),
  summary: z.string().max(500),
  facts: z.array(ExtractedFactSchema).default([]),
  entities: z.array(z.object({
    name: z.string(),
    type: z.enum(["concept", "person", "technology", "algorithm", "framework", "organization", "location"]),
  })).default([]),
  keywords: z.array(z.string()).default([]),
  qualityIndicators: z.object({
    hasCitations: z.boolean().default(false),
    hasCodeExamples: z.boolean().default(false),
    hasData: z.boolean().default(false),
    language: z.string().default("unknown"),
  }).default({}),
});
export type StructuredExtraction = z.infer<typeof StructuredExtractionSchema>;

export interface ExtractOptions {
  llmEndpoint?: string;      // 默认用 ZHIPU_API_BASE（复用 knowledge/pipeline.ts:8）
  apiKey?: string;           // 默认 readString("ZHIPU_API_KEY")
  maxContentLength?: number; // 默认 16000
  timeoutMs?: number;        // 默认 30000
  fallbackToHeuristic?: boolean; // 默认 true（LLM 失败时用启发式抽取）
}

export class DataExtractor {
  extract(markdown: string, opts?: ExtractOptions): Promise<StructuredExtraction>;
}

// 启发式降级抽取（无 LLM 时）
export function heuristicExtract(markdown: string): StructuredExtraction;
```

**LLM 调用**（复用 [knowledge/pipeline.ts:46-67](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L46) 的 GLM 调用模式）:
- POST `{llmEndpoint}/chat/completions`，model `glm-4-flash`
- system prompt 要求输出符合 `StructuredExtractionSchema` 的 JSON
- 解析后 `StructuredExtractionSchema.parse(JSON.parse(content))` 强校验
- 校验失败 → 抛错或降级到 `heuristicExtract`

**启发式降级**（无 LLM 或 LLM 失败时）:
- title：第一个 `# ` 标题或 `<title>`
- summary：前 500 字符（去 markdown 语法）
- facts：抽取陈述句（句号结尾的句子，含数字/专有名词）
- entities：大写词组、代码标识符
- keywords：词频 top-10（去停用词）
- qualityIndicators：检测 `[1]` 引用、`` `代码` `` 块、表格数据

**新增测试**: `tests/crawl-extract.test.ts`（聚合在 `tests/crawl-filter-score-extract.test.ts`）
- `heuristicExtract`：纯 markdown 输入 → 返回符合 schema 的对象
- zod 校验：缺字段时 default 生效；多余字段被 strip
- LLM 成功路径：mock fetch 返回合法 JSON → 解析成功
- LLM 失败降级：mock fetch 抛错 + `fallbackToHeuristic=true` → 返回启发式结果

### Task 2.4 — 接入 data-pipeline.ts

**修改**: [src/crawl/data-pipeline.ts](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts)（手术式扩展，不破坏现有契约）

**AGENTS Rule 2 流程**: 备份 → 读全文 → 修改 → 验证 → 删备份。

**改动点 1**（顶部 import）:
```typescript
import { filterResults, type FilterOptions } from "./result-filter.js";
import { ResultScorer, type ScorerOptions } from "./result-scorer.js";
import { DataExtractor } from "./data-extractor.js";
```

**改动点 2**（`crawlSearchResults` 方法，[line 853-866](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L853)）:
在 `searchMulti` 返回后、`crawlStructured` 循环前插入过滤+打分:
```typescript
async crawlSearchResults(query: string, opts?: { maxResults?: number; engines?: string[] }) {
  const results = await this.searchMulti(query, { /* 原参数 */ });
  // ↓ 新增：过滤 + 打分
  const filterOpts: FilterOptions = {
    blockClickbait: true,
    maxDuplicateRatio: 0.8,
    minContentLength: 50,
  };
  const decisions = filterResults(results, filterOpts);
  const kept = decisions.filter(d => d.kept).map(d => d.result);

  const scorer = new ResultScorer({ query });
  const scored = scorer.score(kept, { query });
  const top = scored.sort((a, b) => b.totalScore - a.totalScore).slice(0, opts?.maxResults ?? 10);

  // ↑ 新增结束
  const crawled = [];
  for (const item of top) {  // ← 改：原为 for (const item of results)
    const data = await this.crawlStructured(item.result.link);  // ← 改：原为 item.link
    if (data) {
      // ↓ 新增：结构化抽取（在 crawlStructured 返回的 markdown 上）
      const extractor = new DataExtractor();
      const extracted = await extractor.extract(data.markdown ?? "").catch(() => null);
      data.extracted = extracted;  // 挂到结果上（StructuredCrawlResult 类型需扩展可选字段）
      // ↑ 新增结束
      crawled.push(data);
    }
  }
  return crawled;
}
```

**改动点 3**（`calculateQualityScore` 扩展，[line 814](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L814)）:
增加可选 `scoreHook` 回调参数，不破坏现有调用:
```typescript
private calculateQualityScore(
  result: StructuredCrawlResult,
  wordCount: number,
  scoreHook?: (result: StructuredCrawlResult) => Partial<ScoreDimensions>,
): number {
  // ... 原有 0-100 评分逻辑保持不变 ...
  const baseScore = /* 原计算 */;
  if (scoreHook) {
    const extra = scoreHook(result);
    // 加权融合：base 70% + extra 30%
    const extraTotal = ((extra.credibility ?? 0.5) + (extra.relevance ?? 0.5) +
                        (extra.timeliness ?? 0.5) + (extra.factualAccuracy ?? 0.5)) / 4 * 100;
    return Math.round(baseScore * 0.7 + extraTotal * 0.3);
  }
  return baseScore;
}
```
`saveCrawlResult`（[line 757](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L757)）调用处不变（不传 scoreHook 时行为零变化）。

**改动点 4**（`StructuredCrawlResult` 类型扩展）:
在定义 `StructuredCrawlResult` 的位置（需读全文确认，预估在 data-pipeline.ts 顶部或 types 文件）加可选字段:
```typescript
interface StructuredCrawlResult {
  // ... 原字段 ...
  extracted?: StructuredExtraction;  // 新增可选字段
  scoreDimensions?: ScoreDimensions; // 新增可选字段
}
```

**新增测试**: `tests/crawl-pipeline-integration.test.ts`
- mock `searchMulti` 返回 5 个结果（含 1 标题党 + 1 重复）→ `crawlSearchResults` 只对 3 个有效结果调 `crawlStructured`
- `calculateQualityScore` 不传 scoreHook → 返回原 0-100 分（回归）
- `calculateQualityScore` 传 scoreHook → 返回融合分

### Phase 2 评估 Gate
- `tests/crawl-filter-score-extract.test.ts` 通过（含 filter/scorer/extractor 3 组测试）
- `tests/crawl-pipeline-integration.test.ts` 通过
- `tests/architecture-integrity.test.ts` 不退化
- `bunx tsc --noEmit` 0 错误
- 手工冒烟：调 `/web-search?q=rust+async` → 返回结果数 ≤ 搜索结果数，结果含 `scoreDimensions`

---

## Phase 3（Week 3）— 知识整理准备

### 目标
1. zod schema 定义（强校验 GLM 输出）
2. 数据预处理模块（清洗/标准化/特征提取）
3. 三维质量评估器（准确性/完整性/一致性）
4. 接入 `knowledge/pipeline.ts`（process.env 迁移已完成，仅加 hook）

### Task 3.1 — zod schema 定义

**修改**: [src/knowledge/types.ts](file:///d:/openclaw-fusion/src/knowledge/types.ts)（41 行，追加 schema）

**保留**现有 4 个 interface（向后兼容），**追加** 3 个 zod schema:
```typescript
import { z } from "zod";

// === 原有 interface 保留不变 ===

// === 新增 zod schema ===

export const KnowledgeSourceSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  domain: z.enum(["philosophy", "mathematics", "computer-science", "dictionary", "physics", "books", "github", "general"]),
  subdomain: z.string(),
  url: z.string().url(),
  quality: z.number().min(0).max(1),
  storedAt: z.number().int().nonnegative(),
});

export const DictionaryEntrySchema = z.object({
  word: z.string().min(1),
  pronunciation: z.string().optional(),
  partOfSpeech: z.string().min(1),
  definitions: z.array(z.string().min(1)).min(1),
  examples: z.array(z.string()).default([]),
  synonyms: z.array(z.string()).default([]),
  antonyms: z.array(z.string()).default([]),
  etymology: z.string().optional(),
});

export const StructuredFactSchema = z.object({
  title: z.string(),
  summary: z.string().max(500),
  keywords: z.array(z.string()).default([]),
  quality_score: z.number().min(0).max(1),
  sections: z.array(z.object({
    heading: z.string(),
    content: z.string(),
  })).default([]),
  entities: z.array(z.object({
    name: z.string(),
    type: z.string(),
  })).default([]),
  structured_data: z.unknown().nullable().default(null),
});

export type StructuredFact = z.infer<typeof StructuredFactSchema>;
```

**新增测试**: `tests/knowledge-types.test.ts`（聚合在 `tests/knowledge-preprocess-quality.test.ts`）
- `KnowledgeSourceSchema.parse(validObj)` → 成功
- `KnowledgeSourceSchema.parse({domain: "invalid"})` → 抛错
- `StructuredFactSchema.parse({title: "x", summary: "y", quality_score: 0.5})` → default 字段填充（keywords=[], sections=[]）
- `StructuredFactSchema.parse({quality_score: 1.5})` → 抛错（超范围）

### Task 3.2 — 数据预处理模块

**新建**: `src/knowledge/preprocessor.ts`

**职责**: 接收 raw markdown（来自 [pipeline.ts:53](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L53) `structureWithGLM` 的输入），输出清洗后的标准化文本 + 特征。

```typescript
export interface PreprocessOptions {
  removeHtmlTags?: boolean;       // 默认 true
  removeBoilerplate?: boolean;    // 默认 true（去导航/页脚/cookie 提示等）
  normalizeWhitespace?: boolean;  // 默认 true
  removeStopwords?: boolean;      // 默认 false（保留语义，仅特征提取时去停用词）
  maxContentLength?: number;      // 默认 16000（GLM 上下文限制）
  extractFeatures?: boolean;      // 默认 true
}

export interface PreprocessResult {
  cleanedText: string;            // 清洗后的 markdown
  features: {
    wordCount: number;
    charCount: number;
    language: "zh" | "en" | "mixed" | "unknown";
    headings: string[];           // 所有标题文本
    codeBlocks: string[];         // 代码块内容
    links: { url: string; text: string }[];
    estimatedReadingTimeMin: number;
    detectedTopics: string[];     // 基于词频的 top-5 主题词
  };
  stats: {
    originalLength: number;
    cleanedLength: number;
    reductionRatio: number;       // 清洗压缩比 0-1
  };
}

export function preprocess(rawMarkdown: string, opts?: PreprocessOptions): PreprocessResult;

// 独立导出各步骤（便于单测）
export function stripHtml(md: string): string;
export function stripBoilerplate(md: string): string;
export function normalizeWhitespace(md: string): string;
export function detectLanguage(text: string): "zh" | "en" | "mixed" | "unknown";
export function extractFeatures(text: string): PreprocessResult["features"];
```

**清洗逻辑**:
- `stripHtml`: 去除 `<script>`/`<style>`/`<nav>`/`<footer>`/`<header>` 标签及内容；保留 `<code>`/`<pre>` 内容
- `stripBoilerplate`: 去除 cookie 提示、"Share this"、"Related posts"、"Comments" 等模板段落（正则模式集）
- `normalizeWhitespace`: 多个空行合并为 1 个；行尾空格去除；tab → 4 空格
- `detectLanguage`: 中文字符占比 > 30% → "zh"；< 10% → "en"；中间 → "mixed"；空 → "unknown"
- `extractFeatures`: 用正则抽 `^#+\s+(.+)$`（headings）、`` `{3}[\s\S]+?`{3} ``（code blocks）、`[label](url)`（links）；词频统计去停用词后 top-5

**新增测试**: `tests/knowledge-preprocess.test.ts`（聚合在 `tests/knowledge-preprocess-quality.test.ts`）
- `stripHtml`：含 `<script>alert(1)</script>` 的 markdown → script 内容被去除
- `stripBoilerplate`：含 "Cookie Policy" 段落 → 被去除
- `normalizeWhitespace`：3 个空行 → 1 个空行
- `detectLanguage`：纯中文 → "zh"；纯英文 → "en"；中英混合 → "mixed"
- `extractFeatures`：含 3 个 `##` 标题 → headings.length === 3
- `preprocess` 端到端：原始 markdown → cleanedText + features + stats 字段完整

### Task 3.3 — 质量评估器

**新建**: `src/knowledge/quality-assessor.ts`

**三维评分**:
```typescript
export interface QualityDimensions {
  accuracy: number;       // 准确性 0-1（事实可验证性）
  completeness: number;   // 完整性 0-1（信息覆盖度）
  consistency: number;    // 一致性 0-1（内部逻辑自洽）
}

export interface QualityAssessment {
  dimensions: QualityDimensions;
  totalScore: number;     // 加权 0-1
  passed: boolean;        // totalScore >= threshold
  issues: string[];       // 发现的问题列表
  recommendations: string[]; // 改进建议
}

export interface AssessorOptions {
  threshold?: number;              // 默认 0.6
  weights?: Partial<{ accuracy: number; completeness: number; consistency: number }>;
  // 默认：accuracy 0.4, completeness 0.3, consistency 0.3
  factBase?: FactEntry[];           // 用于 accuracy（复用 hallucination-detector）
}

export class QualityAssessor {
  private detector: ConformalHallucinationDetector | null = null;
  constructor(opts?: AssessorOptions) {
    if (opts?.factBase && opts.factBase.length > 0) {
      this.detector = new ConformalHallucinationDetector({ alpha: 0.05, factBase: opts.factBase });
    }
  }
  assess(extraction: StructuredExtraction | StructuredFact, preprocessed?: PreprocessResult): QualityAssessment;
}

// 独立维度计算（便于单测）
export function assessAccuracy(extraction: StructuredExtraction, detector: ConformalHallucinationDetector | null): { score: number; issues: string[] };
export function assessCompleteness(extraction: StructuredExtraction, preprocessed?: PreprocessResult): { score: number; issues: string[] };
export function assessConsistency(extraction: StructuredExtraction): { score: number; issues: string[] };
```

**各维度算法**:

1. **accuracy（准确性）**:
   - 无 detector → 0.5（中性）
   - 有 detector：对每个 fact 调 `detector.verify(fact.claim)`
     - `isHallucination=false` → 加 `verdict.confidence`
     - `isHallucination=true` → 加 0 + 记录 issue `"claim flagged as hallucination: {claim}"`
   - 平均所有 fact 的得分
   - 无 facts → 0.5（无可验证内容）

2. **completeness（完整性）**:
   - 基础分 0.3
   - 有 title → +0.1
   - 有 summary（长度 > 50）→ +0.1
   - 有 keywords（≥ 3 个）→ +0.1
   - 有 sections（≥ 1 个）→ +0.1
   - 有 entities（≥ 1 个）→ +0.1
   - 有 facts（≥ 1 个）→ +0.1
   - 有 structured_data → +0.1
   - preprocessed.wordCount > 200 → +0.1（截断到 1.0）
   - 缺关键字段 → 记录 issue

3. **consistency（一致性）**:
   - 检查 title 与 summary 的 jaccard 相似度（> 0.1 → +0.3）
   - 检查 keywords 是否出现在 summary/sections（命中率 > 50% → +0.3）
   - 检查 entities.name 是否在 sections 内容中出现（> 50% → +0.2）
   - 检查 facts 的 confidence 分布（标准差 < 0.3 → +0.2，分布均匀更可信）
   - 不一致 → 记录 issue

**新增测试**: `tests/knowledge-quality.test.ts`（聚合在 `tests/knowledge-preprocess-quality.test.ts`）
- `assessAccuracy`：无 detector → 0.5；有 detector + 匹配事实 → 高分；有 detector + 矛盾 → 低分 + issues
- `assessCompleteness`：空对象 → 0.3 + issues；完整对象 → ~1.0
- `assessConsistency`：title/summary 不相关 → 低分；高度相关 → 高分
- `QualityAssessor.assess` 端到端：返回 dimensions + totalScore + passed + issues + recommendations

### Task 3.4 — 接入 knowledge/pipeline.ts

**修改**: [src/knowledge/pipeline.ts](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts)（194 行，手术式扩展）

**AGENTS Rule 2 流程**: 备份 → 读全文 → 修改 → 验证 → 删备份。

**集成点**: [line 165-172](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L165)，`structureWithGLM()` 返回后、写 JSONL 前。

**改动点 1**（顶部 import）:
```typescript
import { StructuredFactSchema } from "./types.js";
import { preprocess } from "./preprocessor.js";
import { QualityAssessor } from "./quality-assessor.js";
```

**改动点 2**（`structureWithGLM` 返回处，[line 67](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L67)）:
将 `return JSON.parse(content) as StructureResult;` 改为 zod 强校验:
```typescript
const parsed = JSON.parse(content);
const result = StructuredFactSchema.safeParse(parsed);
if (!result.success) {
  logger.warn("[Pipeline] GLM output failed schema validation", { errors: result.error.issues });
  return null;
}
return result.data as StructureResult;
```

**改动点 3**（[line 165-172](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L165)，`structureWithGLM` 调用后）:
```typescript
const structured = await structureWithGLM(final.result.markdown);
if (structured) {
  // ↓ 新增：预处理 + 质量评估
  const preprocessed = preprocess(final.result.markdown);
  const assessor = new QualityAssessor({ threshold: 0.6 });
  const quality = assessor.assess(structured, preprocessed);

  if (!quality.passed) {
    logger.warn(`[Pipeline] Quality assessment failed for ${book.title}`, {
      totalScore: quality.totalScore, issues: quality.issues,
    });
    // 不写 JSONL，跳过该条（符合"数据质量评估机制"要求）
  } else {
    const { join } = await import("path");
    const { mkdirSync, appendFileSync } = await import("fs");
    const datasetDir = join("data", "dataset");
    mkdirSync(datasetDir, { recursive: true });
    const jsonlPath = join(datasetDir, `${safeTopic}.jsonl`);
    appendFileSync(jsonlPath, JSON.stringify({
      ...structured,
      _quality: quality,           // 附带质量评估结果
      _preprocessed: preprocessed.stats,  // 附带预处理统计
    }) + "\n");
  }
  // ↑ 新增结束
}
```

**注意**：`StructuredFactSchema` 与 `StructureResult` interface（[line 29-37](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L29)）字段一致，但 schema 的 `sections`/`entities`/`keywords` 有 `.default([])`，parse 后保证非 undefined。`StructureResult` interface 保持不变（向后兼容），运行时由 zod 保证。

**新增测试**: `tests/knowledge-pipeline-integration.test.ts`
- mock `structureWithGLM` 返回合法 JSON → 预处理 + 质量评估 + JSONL 写入
- mock `structureWithGLM` 返回非法 JSON（缺字段）→ schema 校验失败 → 不写 JSONL
- 质量评估未过阈值 → 不写 JSONL + warn 日志

### Phase 3 评估 Gate
- `tests/knowledge-preprocess-quality.test.ts` 通过（含 types/preprocess/quality 3 组）
- `tests/knowledge-pipeline-integration.test.ts` 通过
- `tests/architecture-integrity.test.ts` 不退化
- `bunx tsc --noEmit` 0 错误
- 手工冒烟：跑 `runPipeline({ bookTopics: ["rust"] })` → `data/dataset/rust.jsonl` 含 `_quality` 字段

---

## Phase 4（Week 4）— 安全加固完成

### 目标
1. API Key 静态加密（AES-256-GCM）
2. 多维度限流（per-user + per-path + global）
3. 沙箱 Windows 加固
4. 安全监控 + health-checker 加 checkSecurity
5. WebSocket maxClients 配置化

### Task 4.1 — API Key 静态加密

**修改**: [src/utils/api-key-persistence.ts](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts)（83 行）

**AGENTS Rule 2 流程**: 备份 → 读全文 → 修改 → 验证 → 删备份。

**加密方案**: AES-256-GCM（Bun 内置 `node:crypto`，无新依赖）。
- 密钥来源：`readString("AXIOM_ENCRYPTION_KEY")`（32 字节 base64 或 hex）
- 未配置密钥时：
  - **写**：fail-closed，抛错（拒绝明文写入，强制运维配置密钥）
  - **读**：容错，若 DB 中是明文（历史数据）则原样返回 + warn 日志（向后兼容）

**改动**:
```typescript
import crypto from "node:crypto";
import { readString } from "./env.js";

const ENCRYPTION_ALGO = "aes-256-gcm";
const IV_LENGTH = 12;  // GCM 推荐 12 字节
const TAG_LENGTH = 16;

function getEncryptionKey(): Buffer | null {
  const raw = readString("AXIOM_ENCRYPTION_KEY");
  if (!raw) return null;
  // 支持 base64 或 hex
  let key: Buffer;
  try {
    key = Buffer.from(raw, "base64");
    if (key.length === 32) return key;
  } catch {}
  try {
    key = Buffer.from(raw, "hex");
    if (key.length === 32) return key;
  } catch {}
  logger.warn("[ApiKeyPersistence] AXIOM_ENCRYPTION_KEY invalid (must be 32 bytes base64 or hex), falling back to plaintext-tolerant read");
  return null;
}

function encrypt(plaintext: string): string {
  const key = getEncryptionKey();
  if (!key) throw new Error("AXIOM_ENCRYPTION_KEY not configured; refusing to persist plaintext API key");
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ENCRYPTION_ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  // 格式：v1:base64(iv|tag|ciphertext)
  return "v1:" + Buffer.concat([iv, tag, encrypted]).toString("base64");
}

function decrypt(stored: string): string {
  // 历史明文数据（无 "v1:" 前缀）→ 原样返回 + warn
  if (!stored.startsWith("v1:")) {
    logger.warn("[ApiKeyPersistence] Found plaintext API key in DB (legacy); recommend re-saving to encrypt");
    return stored;
  }
  const key = getEncryptionKey();
  if (!key) {
    logger.warn("[ApiKeyPersistence] Encrypted key found but AXIOM_ENCRYPTION_KEY missing; cannot decrypt");
    return "";  // 返回空，调用方视为未配置
  }
  try {
    const buf = Buffer.from(stored.slice(3), "base64");
    const iv = buf.subarray(0, IV_LENGTH);
    const tag = buf.subarray(IV_LENGTH, IV_LENGTH + TAG_LENGTH);
    const ciphertext = buf.subarray(IV_LENGTH + TAG_LENGTH);
    const decipher = crypto.createDecipheriv(ENCRYPTION_ALGO, key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
  } catch (err) {
    logger.error("[ApiKeyPersistence] Decryption failed", err instanceof Error ? err : new Error(String(err)));
    return "";
  }
}
```

**修改 `saveApiKeyOverride`**（[line 58](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts#L58)）:
```typescript
export function saveApiKeyOverride(db, provider, apiKey, baseURL?): void {
  const encrypted = encrypt(apiKey);  // ← 新增：加密
  db.run(`INSERT ...`, [provider, encrypted, baseURL || null, Date.now()]);  // ← 改：存加密值
}
```

**修改 `loadApiKeyOverrides`**（[line 37](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts#L37)）:
```typescript
return rows.map((r) => ({
  provider: r.provider,
  apiKey: decrypt(r.api_key),  // ← 新增：解密
  baseURL: r.base_url || undefined,
  setAt: r.set_at,
}));
```

**`.env.example` 补充**:
```
# API Key 静态加密密钥（AES-256-GCM，32 字节 base64 或 hex）
# 生成命令：openssl rand -base64 32  或  node -e "console.log(crypto.randomBytes(32).toString('base64'))"
# 未配置时：saveApiKeyOverride 抛错（fail-closed），loadApiKeyOverrides 容错读取历史明文
AXIOM_ENCRYPTION_KEY=
```

**新增测试**: `tests/api-key-encryption.test.ts`
- 配置密钥 → `saveApiKeyOverride` 写入 → DB 中 `api_key` 字段以 `v1:` 开头（非明文）
- `loadApiKeyOverrides` 读取 → 返回原始 apiKey
- 未配置密钥 → `saveApiKeyOverride` 抛错
- 未配置密钥 + DB 有历史明文 → `loadApiKeyOverrides` 返回明文 + warn（不抛错）
- 错误密钥 → `loadApiKeyOverrides` 解密失败 → 返回空串
- 篡改密文（去掉 1 字节）→ GCM authTag 校验失败 → 返回空串

### Task 4.2 — 多维度限流

**修改**: [src/utils/rate-limiter.ts](file:///d:/openclaw-fusion/src/utils/rate-limiter.ts)（122 行，新增 MultiDimensionLimiter，不改现有 RateLimiter）

**新增 class**（文件末尾追加）:
```typescript
export interface MultiDimensionOptions {
  globalMaxPerMin: number;        // 全局上限
  perUserMaxPerMin?: number;      // 单用户上限（通过 x-user-id header 识别）
  perPathMaxPerMin?: Record<string, number>;  // 特定路径上限
  exemptLocalIps?: boolean;       // 默认 true（回环地址不限流）
}

export class MultiDimensionLimiter {
  private globalLimiter: RateLimiter;
  private userLimiter: RateLimiter;
  private pathLimiter: RateLimiter;

  constructor(opts: MultiDimensionOptions) {
    this.globalLimiter = new RateLimiter({ windowMs: 60_000, maxRequests: opts.globalMaxPerMin });
    this.userLimiter = new RateLimiter({ windowMs: 60_000, maxRequests: opts.perUserMaxPerMin ?? 1000 });
    this.pathLimiter = new RateLimiter({ windowMs: 60_000, maxRequests: 1000 });
    if (opts.perPathMaxPerMin) {
      for (const [path, max] of Object.entries(opts.perPathMaxPerMin)) {
        this.pathLimiter.setRule(path, { windowMs: 60_000, maxRequests: max });
      }
    }
  }

  check(req: Request, ip: string): { allowed: boolean; reason?: string; headers: Record<string, string> } {
    if (this.opts?.exemptLocalIps && isLocalAddress(ip)) {
      return { allowed: true, headers: {} };
    }
    const url = new URL(req.url);
    const userId = req.headers.get("x-user-id") || ip;  // 无 x-user-id 时退化为 IP 维度

    const g = this.globalLimiter.check("global", undefined);
    if (!g.allowed) return { allowed: false, reason: "global_limit", headers: this.globalLimiter.getHeaders(g) };

    const u = this.userLimiter.check(userId, undefined);
    if (!u.allowed) return { allowed: false, reason: "user_limit", headers: this.userLimiter.getHeaders(u) };

    const p = this.pathLimiter.check(userId, url.pathname);
    if (!p.allowed) return { allowed: false, reason: "path_limit", headers: this.pathLimiter.getHeaders(p) };

    return { allowed: true, headers: this.globalLimiter.getHeaders(g) };
  }
}

export const multiLimiter = new MultiDimensionLimiter({
  globalMaxPerMin: readInt("RATE_LIMIT_GLOBAL", 1000),
  perUserMaxPerMin: readInt("RATE_LIMIT_PER_USER", 100),
  perPathMaxPerMin: {
    "/chat": 10,
    "/web-search": 30,
    "/sandbox/execute": 20,
    "/vault/write": 30,
  },
});
```

**接入 main.ts**（[main.ts:450](file:///d:/openclaw-fusion/src/main.ts#L450) 附近）:
- `rateLimitCheck` 调用处可选叠加 `multiLimiter.check(req, remoteAddress)`，被拒绝时返回 429 + 审计 `rate_limit.exceeded`。
- 最小改动：仅当 `multiLimiter.check` 拒绝时短路返回 429，不影响现有 `apiLimiter` 逻辑。

**新增测试**: `tests/rate-limiter-multi.test.ts`
- 全局上限：1000 req/min，发 1001 个 → 第 1001 被拒（reason: "global_limit"）
- per-user 上限：100 req/min，单 IP 发 101 个 → 第 101 被拒（reason: "user_limit"）
- per-path 上限：`/chat` 10/min，发 11 个 → 第 11 被拒（reason: "path_limit"）
- 回环地址豁免：`isLocalAddress("127.0.0.1")` → 全部放行
- 不同 user-id 独立计数：user-a 用满不影响 user-b

### Task 4.3 — 沙箱 Windows 加固

**修改**: [src/sandbox/process-sandbox.ts](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts)（82 行）

**AGENTS Rule 2 流程**: 备份 → 读全文 → 修改 → 验证 → 删备份。

**Windows 加固方案**（不引入原生模块依赖，用 stdout 大小上限 + CPU 时间监视）:
```typescript
if (isWindows) {
  cmd = "cmd.exe";
  args = ["/c", opts.command, ...(opts.args ?? [])];

  // Windows 加固：用 PowerShell 包装实现内存估计 + 输出大小上限
  // 注意：Windows 无 ulimit 等价物，真正内存限制需 Job Object（需 native addon）
  // 此处用输出大小上限 + 进程级 CPU 超时作为最小加固
  spawnOpts.env = {
    ...spawnOpts.env as Record<string, string>,
    // 限制环境变量继承（防泄漏敏感 env）
    AXIOM_AUTH_TOKEN: undefined,
    AXIOM_ENCRYPTION_KEY: undefined,
    ZHIPU_API_KEY: undefined,
  };
}

// 进程启动后：输出大小监视（防内存耗尽）
const MAX_STDOUT_BYTES = opts.maxOutputBytes ?? 10 * 1024 * 1024;  // 10MB
const MAX_STDERR_BYTES = opts.maxStderrBytes ?? 1 * 1024 * 1024;   // 1MB
let stdoutLen = 0, stderrLen = 0;
proc.stdout.on("data", (chunk: Buffer) => {
  stdoutLen += chunk.length;
  if (stdoutLen > MAX_STDOUT_BYTES) {
    try { proc.kill(9) } catch {}
  }
});
proc.stderr.on("data", (chunk: Buffer) => {
  stderrLen += chunk.length;
  if (stderrLen > MAX_STDERR_BYTES) {
    try { proc.kill(9) } catch {}
  }
});
```

**Linux 加固补充**（[line 33-47](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L33)）:
```typescript
const limits: string[] = [];
if (opts.maxMemoryMb) limits.push(`ulimit -v ${opts.maxMemoryMb * 1024}`);
if (opts.maxCpu) limits.push(`ulimit -t ${opts.maxCpu}`);
// 新增：文件大小限制（防日志/输出撑爆磁盘）
limits.push(`ulimit -f ${opts.maxOutputBytes ? Math.ceil(opts.maxOutputBytes / 512) : 20480}`);  // 默认 10MB
// 新增：core dump 限制
limits.push(`ulimit -c 0`);
// 新增：进程数限制（防 fork 炸弹）
limits.push(`ulimit -u 64`);

if (!opts.networkAccess) {
  logger.warn("[Sandbox] Network isolation requires Docker sandbox; current process sandbox cannot enforce");
}
```

**新增测试**: `tests/sandbox-hardening.test.ts`
- stdout 超 10MB → 进程被 kill（mock proc.kill）
- 敏感 env 被清除：`spawnOpts.env.AXIOM_AUTH_TOKEN === undefined`
- Linux 命令含 `ulimit -f` 和 `ulimit -c 0`

### Task 4.4 — 安全监控 + health-checker

**新建**: `src/utils/security-monitor.ts`
```typescript
import { auditLogger } from "./audit-logger.js";
import { metrics } from "./metrics.js";

export type SecuritySeverity = "low" | "medium" | "high" | "critical";

export interface SecurityAlert {
  timestamp: string;
  severity: SecuritySeverity;
  category: "auth" | "rate_limit" | "sandbox" | "config" | "data_integrity" | "intrusion";
  title: string;
  description: string;
  actor?: string;
  resource?: string;
  indicators?: Record<string, unknown>;
}

export class SecurityMonitor {
  private recentAlerts: SecurityAlert[] = [];
  private maxRecent = 100;

  alert(alert: Omit<SecurityAlert, "timestamp">): void {
    const full: SecurityAlert = { timestamp: new Date().toISOString(), ...alert };
    this.recentAlerts.push(full);
    if (this.recentAlerts.length > this.maxRecent) this.recentAlerts.shift();

    // 写审计日志（复用 auditLogger，event="security.alert"）
    auditLogger.log({
      event: "security.alert",
      actor: alert.actor ?? "system",
      outcome: alert.severity === "critical" || alert.severity === "high" ? "failure" : "success",
      resource: alert.resource,
      reason: alert.title,
      metadata: { severity: alert.severity, category: alert.category, description: alert.description },
    });

    // metrics（已在 audit-logger.ts 注册 security_alert_total）
    metrics.increment("security_alert_total", 1, { severity: alert.severity, category: alert.category });
  }

  getRecentAlerts(limit?: number): SecurityAlert[] {
    return this.recentAlerts.slice(-(limit ?? 20));
  }

  getStats(): { totalRecent: number; bySeverity: Record<SecuritySeverity, number>; byCategory: Record<string, number> } {
    const bySeverity: Record<SecuritySeverity, number> = { low: 0, medium: 0, high: 0, critical: 0 };
    const byCategory: Record<string, number> = {};
    for (const a of this.recentAlerts) {
      bySeverity[a.severity]++;
      byCategory[a.category] = (byCategory[a.category] || 0) + 1;
    }
    return { totalRecent: this.recentAlerts.length, bySeverity, byCategory };
  }
}

export const securityMonitor = new SecurityMonitor();
```

**修改**: [src/core/health-checker.ts](file:///d:/openclaw-fusion/src/core/health-checker.ts)（368 行，加 `checkSecurity`）

**AGENTS Rule 2 流程**: 备份 → 读全文 → 修改 → 验证 → 删备份。

**改动点 1**（顶部 import）:
```typescript
import { securityMonitor } from "../utils/security-monitor.js";
import { readString } from "../utils/env.js";
```

**改动点 2**（`runFullCheck` 的 `Promise.all` 数组，[line 58-67](file:///d:/openclaw-fusion/src/core/health-checker.ts#L58)）:
```typescript
await Promise.all([
  this.checkApiKeys(),
  this.checkDatabase(),
  this.checkVault(),
  this.checkCodeGraph(),
  this.checkRedis(),
  this.checkDiskSpace(),
  this.checkNetwork(),
  this.checkConfig(),
  this.checkSecurity(),   // ← 新增
]);
```

**改动点 3**（新增 `checkSecurity` 方法，紧邻 `checkConfig` 后）:
```typescript
private async checkSecurity(): Promise<void> {
  const issues: string[] = [];

  // 1. AXIOM_AUTH_TOKEN 配置检查
  const authToken = readString("AXIOM_AUTH_TOKEN");
  if (!authToken) {
    issues.push("AXIOM_AUTH_TOKEN not configured");
  } else if (authToken.length < 16) {
    issues.push(`AXIOM_AUTH_TOKEN too short (${authToken.length} < 16)`);
  }

  // 2. AXIOM_ENCRYPTION_KEY 配置检查
  const encKey = readString("AXIOM_ENCRYPTION_KEY");
  if (!encKey) {
    issues.push("AXIOM_ENCRYPTION_KEY not configured (API keys persisted as plaintext)");
  }

  // 3. CORS_ORIGINS 检查（生产环境不应为 *）
  const cors = readString("CORS_ORIGINS");
  if (readString("NODE_ENV") === "production" && (!cors || cors === "*")) {
    issues.push("CORS_ORIGINS not restricted in production");
  }

  // 4. 近期安全告警统计
  const stats = securityMonitor.getStats();
  if (stats.bySeverity.critical > 0) {
    issues.push(`${stats.bySeverity.critical} critical security alerts in recent window`);
  }

  if (issues.length > 0) {
    this.results.push({
      component: "安全", status: issues.length > 2 ? "error" : "warning",
      message: `${issues.length} security issue(s): ${issues.join("; ")}`,
      fix: "Review security configuration and recent alerts",
    });
  } else {
    this.results.push({
      component: "安全", status: "ok",
      message: "All security checks passed",
    });
  }
}
```

**改动点 4**（`generateRecommendations`，[line 309-311](file:///d:/openclaw-fusion/src/core/health-checker.ts#L309) 已有 "安全" stub，替换为真实逻辑）:
```typescript
if (this.results.some((r) => r.component === "安全" && r.status === "error")) {
  recommendations.push("🔒 安全配置不完整，请检查 AXIOM_AUTH_TOKEN / AXIOM_ENCRYPTION_KEY / CORS_ORIGINS");
}
```

**新增测试**: `tests/security-monitor.test.ts`
- `securityMonitor.alert({severity: "high", ...})` → `getRecentAlerts()` 含该条
- `getStats()` 计数正确
- `audit.log` 被调用（通过检查 `data/logs/audit.log` 含 `security.alert` 事件）
- `metrics.security_alert_total` 递增

**新增测试**: `tests/health-checker-security.test.ts`
- 无 `AXIOM_AUTH_TOKEN` → `checkSecurity` 返回 status="error" 或 "warning"
- 短 token（<16）→ issue 含 "too short"
- 全部配置正确 → status="ok"

### Task 4.5 — WebSocket 配置化

**修改**: [src/utils/websocket.ts](file:///d:/openclaw-fusion/src/utils/websocket.ts)（123 行）

**AGENTS Rule 2 流程**: 备份 → 读全文 → 修改 → 验证 → 删备份。

**改动点 1**（[line 29](file:///d:/openclaw-fusion/src/utils/websocket.ts#L29)）:
```typescript
import { readInt } from "./env.js";
// 删除：const MAX_WS_CLIENTS = 100;
// 改为：
const MAX_WS_CLIENTS = readInt("MAX_WS_CLIENTS", 100);
const MAX_MSGS_PER_MIN_PER_CLIENT = readInt("WS_MAX_MSGS_PER_MIN", 60);  // 新增：单客户端消息速率
```

**改动点 2**（新增 per-client 速率限制，`WsClient` interface 扩展）:
```typescript
interface WsClient {
  ws: ServerWebSocket<unknown>;
  subscriptions: Set<WsEventType>;
  connectedAt: number;
  msgTimestamps: number[];  // 新增
}
```

**改动点 3**（`onMessage` 加速率检查，[line 64-83](file:///d:/openclaw-fusion/src/utils/websocket.ts#L64)）:
```typescript
onMessage(ws, message): void {
  try {
    const client = this.clients.get(ws.data.clientId);
    if (!client) return;

    // 新增：per-client 速率限制
    const now = Date.now();
    client.msgTimestamps = client.msgTimestamps.filter(t => t > now - 60_000);
    if (client.msgTimestamps.length >= MAX_MSGS_PER_MIN_PER_CLIENT) {
      // 触发 ws_flood 审计
      auditLogger.log({
        event: "ws_flood",
        actor: ws.data.clientId,
        outcome: "denied",
        reason: `exceeded ${MAX_MSGS_PER_MIN_PER_CLIENT} msgs/min`,
      });
      ws.close(1008, "Message rate limit exceeded");
      return;
    }
    client.msgTimestamps.push(now);
    // ↑ 新增结束

    // ... 原有 subscribe/unsubscribe/ping 处理 ...
  } catch {}
}
```

**改动点 4**（顶部 import）:
```typescript
import { auditLogger } from "./audit-logger.js";
```

**新增测试**: `tests/websocket-config.test.ts`
- `MAX_WS_CLIENTS` 从 env 读取：set `process.env.MAX_WS_CLIENTS = "5"` → 第 6 个连接被拒
- per-client 速率：发 61 条消息 → 第 61 条触发 close + audit log `ws_flood`

### Phase 4 评估 Gate
- `tests/api-key-encryption.test.ts` 通过
- `tests/rate-limiter-multi.test.ts` 通过
- `tests/sandbox-hardening.test.ts` 通过
- `tests/security-monitor.test.ts` + `tests/health-checker-security.test.ts` 通过
- `tests/websocket-config.test.ts` 通过
- `tests/architecture-integrity.test.ts` 不退化
- `bunx tsc --noEmit` 0 错误
- 手工冒烟：未配 `AXIOM_ENCRYPTION_KEY` 时 `POST /api-keys` → 500（fail-closed）；`runHealthCheck()` 输出含"安全"行

---

## Assumptions & Decisions（假设与决策）

### 假设
1. `zod ^3.22.0` 已在 [package.json:75](file:///d:/openclaw-fusion/package.json#L75)，可直接 `import { z } from "zod"`（无需新增依赖）。
2. Bun 内置 `node:crypto`，AES-256-GCM 可直接用（无需 `npm install`）。
3. `data/logs/` 目录已存在（[main.ts:136](file:///d:/openclaw-fusion/src/main.ts#L136) 启动时 `Bun.write("./data/logs/.gitkeep", "")` 确保创建）。
4. 测试框架为 Bun test（`bun test`），mock 用 `Bun.mock.module()` 或构造临时实例。
5. 现有 `tests/architecture-integrity.test.ts` 有 22 项测试（4 个 pre-existing fail），本计划不得引入新失败。

### 决策
1. **Task 1.1 跳过**：P0 已修复，不重复工作。仅清理遗留备份。
2. **复用 `auth-check.ts`**：不新建 `is-local.ts`（v2 计划的方案），直接用现有 `isLocalAddress()`。
3. **`process.env` 迁移取消**：已全部完成，Task 3.4 仅做 zod + preprocessor + quality-assessor 集成。
4. **`calculateQualityScore` 扩展不重建**：加可选 `scoreHook` 参数，不传时行为零变化（向后兼容）。
5. **API Key 加密 fail-closed（写）+ tolerant（读）**：强制新写入必须加密，但容忍历史明文数据（避免迁移脚本）。
6. **Windows 沙箱不引入 native addon**：用输出大小上限 + env 清理 + CPU 超时作为最小加固；真正内存限制需 Job Object，留待后续（在测试中记录此限制）。
7. **`security_alert_total` 在 audit-logger.ts 提前注册**：避免 security-monitor.ts 重复注册逻辑（metrics.register 是幂等的，但集中注册更清晰）。
8. **测试聚合文件**：Phase 2 用 `tests/crawl-filter-score-extract.test.ts`，Phase 3 用 `tests/knowledge-preprocess-quality.test.ts`，减少测试文件数量（符合最小化原则）。

---

## 验证机制（Verification）

### 每阶段通用验证
```powershell
# 1. 类型检查
bunx tsc --noEmit

# 2. 全量测试
bun test tests/

# 3. 架构完整性（不退化）
bun test tests/architecture-integrity.test.ts

# 4. 启动冒烟
$env:AXIOM_AUTH_TOKEN="test-token-12345"; $env:AXIOM_ENCRYPTION_KEY=$(node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"); bun run src/main.ts
```

### 阶段性提交（每阶段独立 commit + push）
```powershell
git add <具体文件>; git commit -m "$(cat <<'EOF'
feat(security|crawl|knowledge): Phase X — <简述>

- Task X.1: ...
- Task X.2: ...
- 验证: tsc 0 错误 + N 测试通过
EOF
)"
git push internal211 main
```

### 操作留痕（AGENTS Rule 5）
每阶段 commit 后，在 `docs/operations-log.md` 追加一条记录，格式参照已有条目（时间/任务/工具/操作/验证/Commit）。

---

## 时间节点汇总

| Week | Phase | 交付物 | 测试数（预估） |
|------|-------|--------|----------------|
| Week 1 | Phase 1 | audit-logger + logger redact + route-auth（4 路由） | +12 |
| Week 2 | Phase 2 | result-filter + result-scorer + data-extractor + pipeline 集成 | +18 |
| Week 3 | Phase 3 | zod schema + preprocessor + quality-assessor + pipeline 集成 | +15 |
| Week 4 | Phase 4 | API Key 加密 + 多维限流 + 沙箱加固 + 安全监控 + WS 配置化 | +20 |

**总测试新增**：~65 项（不退化为底线）