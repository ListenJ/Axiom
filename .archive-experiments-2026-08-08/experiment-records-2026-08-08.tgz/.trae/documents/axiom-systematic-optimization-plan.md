# Axiom Runtime v4.0 三支柱系统化优化实施计划

## Context（背景）

**问题来源**: 2026-07-17 综合审查报告 `docs/REVIEW-2026-07-17.md` 评级 B+，识别出多项改进点。用户进一步要求对项目进行系统性优化，聚焦三个核心方向：(1) 网络检索优化（过滤/评分/抽取），(2) 知识整理准备（格式/预处理/质量评估），(3) 安全措施完善（审计/加密/访问控制/监控/策略）。

**关键发现（直接读码验证）**:
- 🔴 **P0 认证绕过漏洞**: `src/main.ts:414` 和 `:460` 使用 `url.hostname`（即 HTTP `Host` header）判断 `isLocal`，攻击者发送 `Host: localhost` header 即可绕过所有认证。Bun 提供 `server.requestIP(req)` 返回真实 socket 远端地址，是修复方案的核心。
- ✅ 现有 `calculateQualityScore`（`data-pipeline.ts:814`）已有基础质量评分，应**扩展**而非重建。
- ✅ 现有 `ConformalHallucinationDetector`、`ConformalRetriever`、`sanitizeRequestBody`、`createSecurityHeaders` 等可复用。
- ✅ zod ^3.22.0 已在 `package.json`，可直接用 zod schema。

**预期结果**: 4 周内完成 4 阶段交付，P0 漏洞修复，新增过滤/评分/抽取/预处理/质量评估/加密/监控能力，全部测试通过，每阶段独立可发布，全程遵守 `AGENTS.md` 五条强约束。

**约束**（`AGENTS.md`）:
1. 最小化施工，禁止过度施工
2. 备份→读全文→修改→验证→删备份
3. 提交到 `internal211` 远端（`ssh://data@192.168.2.11/home/data/openclaw-fusion.git`）
4. 删除 = 归档到 `archive/` + 写 `archive/ARCHIVE-LOG.md`
5. 操作留痕 `docs/operations-log.md`

---

## Phase 1（Week 1）— 安全 P0 修复 + 安全基础

### 目标
1. 修复 `isLocal` Host-header 认证绕过漏洞（P0，紧急）
2. 新增审计日志（auth 成功/失败、敏感操作）
3. Logger 密钥脱敏（防日志泄漏 token）
4. 敏感端点 per-route 二次认证（vault 写、sandbox 执行、plugin 安装）

### 技术方案

#### Task 1.1 — 修复 isLocal 漏洞（P0）

**修改文件**: `src/main.ts`（2 处手术式编辑）

新增辅助函数（紧邻 `checkApiKey` 之前）:
```typescript
function isLocalRequest(server: Server, req: Request): boolean {
  const ip = server.requestIP(req);  // Bun 原生 API，不可伪造
  if (ip) {
    return ip.address === "127.0.0.1" || ip.address === "::1" || ip.address === "::ffff:127.0.0.1";
  }
  if (readString("AXIOM_TRUST_PROXY") === "true") {
    const real = req.headers.get("x-real-ip");
    if (real) return real === "127.0.0.1" || real === "::1";
  }
  return false; // fail-closed
}
```

- **编辑点 1**（line 414）: `checkApiKey(req)` 改为 `checkApiKey(server, req)`，把 `if (url.hostname === "localhost" ...)` 替换为 `if (isLocalRequest(server, req)) return true;`
- **编辑点 2**（line 460）: `const isLocal = url.hostname === ...` 替换为 `const isLocal = isLocalRequest(server, req);`
- `fetch(req, server)` 签名已包含 `server`，无需改签名。

#### Task 1.2 — 审计日志模块

**新建**: `src/utils/audit-logger.ts`

```typescript
export type AuditEvent =
  | "auth.success" | "auth.failure"
  | "vault.write" | "sandbox.execute" | "plugin.install" | "plugin.uninstall"
  | "apikey.set" | "apikey.delete" | "rate_limit.exceeded" | "config.change";

export interface AuditEntry {
  timestamp: string; event: AuditEvent; actor: string;
  resource?: string; outcome: "success" | "failure" | "denied";
  reason?: string; metadata?: Record<string, unknown>;
}

export class AuditLogger { /* 写 data/logs/audit.log，JSON Lines 格式 */ }
export const auditLogger: AuditLogger;  // 默认单例
```

复用 `src/utils/logger.ts` 的文件轮转模式；同步 `metrics.increment("audit_event_total", 1, { event, outcome })` 接入现有 metrics（`src/utils/metrics.ts`）。

#### Task 1.3 — Logger 密钥脱敏

**修改**: `src/utils/logger.ts`

在 `log()` 方法（约 line 167）序列化前调用脱敏。新增辅助 `redactContext(ctx)`:
- 复用 `src/utils/security.ts:49` 的 `sanitizeRequestBody`（已支持 password/token/secret/api_key/apikey/authorization/cookie/credit_card/ssn）
- 额外匹配字符串值中的 key 前缀 `/(sk-|Bearer\s+\S|AKIA|ghp_)/` → `[REDACTED]`

#### Task 1.4 — 敏感端点 per-route 二次认证

**新建**: `src/utils/route-auth.ts`
```typescript
export function requireAuthToken(ctx: RouteContext): Response | null {
  const token = readString("AXIOM_AUTH_TOKEN");
  if (!token) return ctx.jsonResponse({ error: "Server auth not configured" }, 503, ctx.baseHeaders);
  const provided = ctx.req.headers.get("x-api-key") ||
    ctx.req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (provided !== token) {
    auditLogger.log({ event: "auth.failure", actor: ctx.req.headers.get("x-real-ip") || "unknown",
      outcome: "denied", reason: "invalid token", resource: ctx.url.pathname });
    return ctx.jsonResponse({ error: "Unauthorized" }, 401, ctx.baseHeaders);
  }
  return null;
}
```

**修改**（每个仅加 2-3 行守卫）:
- `src/routes/vault.ts`: `handleVaultWrite`, `handleVaultAtomic`, `handleVaultDistill` 函数体首行
- `src/routes/sandbox.ts`: `handleSandboxExecute` 函数体首行
- `src/routes/plugin-routes.ts`: `install`/`uninstall` 方法首行
- `src/routes/api-keys.ts`: 把本地 `requireAuth` 改为复用 `requireAuthToken`（去重）

### 资源依赖
| 依赖 | 路径 | 用途 |
|------|------|------|
| `server.requestIP` | Bun 内置 API | P0 修复核心 |
| `sanitizeRequestBody` | `src/utils/security.ts:49` | logger 脱敏复用 |
| `requireAuth` 模式 | `src/routes/api-keys.ts:36` | 抽取为通用 helper |
| `metrics` | `src/utils/metrics.ts` | 审计事件计数 |
| `readString` | `src/utils/env.ts` | 环境变量读取（不绕过 env.ts） |

### 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | 备份 `main.ts` → P0 修复 + `tests/security-islocal.test.ts` |
| Day 2 | `audit-logger.ts` + 单测 |
| Day 3 | `logger.ts` 脱敏 + 单测 |
| Day 4 | `route-auth.ts` + vault/sandbox/plugin 接入（4 文件） |
| Day 5 | 全量回归 + commit + push internal211 + operations-log |

### 评估机制
**新增测试**:
- `tests/security-islocal.test.ts`: 构造 `Host: localhost` 头 + 非 127.0.0.1 远端 → 期望 401；`AXIOM_TRUST_PROXY` 未设时 `x-real-ip` 攻击失败；真实本地请求通过
- `tests/audit-logger.test.ts`: 写入格式、字段完整、轮转触发
- `tests/logger-redact.test.ts`: `logger.info("x", { api_key: "sk-xxx" })` 输出含 `[REDACTED]`
- `tests/route-auth.test.ts`: 401 / 503 / 200 三路径

**Gate**: `tests/security-islocal.test.ts` 通过 + 手工 `curl -H "Host: localhost" http://<lan-ip>:3000/chat` 返回 401

---

## Phase 2（Week 2）— Web 检索优化

### 目标
1. 结果过滤器：剔除低质/重复/误导/标题党
2. 多维度打分器：来源可信度 / 内容相关度 / 时效性 / 事实准确度
3. LLM 结构化抽取器：zod schema 强制的统一抽取
4. 手术式接入 `data-pipeline.ts`，**扩展**现有 `calculateQualityScore`，不破坏 `searchMulti` 接口

### 技术方案

#### Task 2.1 — 结果过滤器

**新建**: `src/crawl/result-filter.ts`

```typescript
export interface FilterOptions {
  minContentLength?: number;      // 默认 50
  maxDuplicateRatio?: number;     // 默认 0.8
  blockListDomains?: string[];
  blockClickbait?: boolean;
}
export interface FilterDecision { result: SearchEngineResult; kept: boolean; reasons: string[]; }
export function filterResults(query: string, results: SearchEngineResult[], opts?: FilterOptions)
  : { kept: SearchEngineResult[]; dropped: FilterDecision[] };
```

启发式规则（< 5ms/100 条）:
- 长度/标题党（全大写、`!!!`、"震惊|不转不是人"）
- URL SimHash + Jaccard 去重
- 域名黑名单（SEO 农场硬编码常量）
- snippet 与 query 字符重合度 < 0.1

#### Task 2.2 — 多维度打分器

**新建**: `src/crawl/result-scorer.ts`

```typescript
export interface ScoreDimensions {
  sourceCredibility: number;  // 0-1，域名 TLD + known-good 列表
  contentRelevance: number;   // 0-1，BM25/TF-IDF
  timeliness: number;         // 0-1，exp(-Δdays/365)
  factualAccuracy: number;    // 0-1，ConformalHallucinationDetector
}
export interface ScoredResult<T> { result: T; dimensions: ScoreDimensions; overall: number; conformalPValue?: number; }
export class ResultScorer {
  constructor(opts: { factBase?: FactEntry[]; weights?: Partial<ScoreDimensions> }) {}
  async score(query: string, results: SearchEngineResult[]): Promise<ScoredResult<SearchEngineResult>[]>;
}
```

**复用**（最小改动，不破坏现有模块）:
- `src/memory/hallucination-detector.ts:290` `ConformalHallucinationDetector` → `factualAccuracy`
- `src/memory/conformal-retriever.ts` `ConformalRetriever` → `conformalPValue`
- `src/memory/hallucination-detector.ts:149` `IDFCache`（私有类）→ 复制接口到 `result-scorer.ts`（不导出原私有类，符合 Rule 1）

**域名可信度表**（硬编码 + env 扩展）: `.edu/.gov/.mil → 0.9`、`github.com/arxiv.org/ieee.org → 0.85`、`wikipedia.org → 0.75`、其他 → 0.5

**加权**: `overall = 0.3*credibility + 0.35*relevance + 0.15*timeliness + 0.2*factualAccuracy`

#### Task 2.3 — LLM 结构化抽取器

**新建**: `src/crawl/data-extractor.ts`

```typescript
import { z } from "zod";
import { LLMClient } from "../dre/llm/client.js";

export const StructuredExtraction = z.object({
  summary: z.string().max(500),
  facts: z.array(z.object({
    subject: z.string(), predicate: z.string(), object: z.string(),
    confidence: z.number().min(0).max(1), source_span: z.string().optional(),
  })),
  entities: z.array(z.object({ name: z.string(), type: z.string() })),
  claims: z.array(z.object({ text: z.string(), verifiable: z.boolean() })),
  keywords: z.array(z.string()),
});

export class DataExtractor {
  constructor(private llm: LLMClient) {}
  async extract(result: SearchEngineResult | StructuredCrawlResult): Promise<StructuredExtraction>;
}
```

**降级策略**: LLM 不可用时返回 `{ summary: result.snippet, facts: [], entities: [], claims: [], keywords: [] }`，不抛异常、不阻塞 pipeline。

#### Task 2.4 — 接入 data-pipeline.ts

**修改**: `src/crawl/data-pipeline.ts`（手术式，仅新增 1 方法 + 1 调用点）

```typescript
async searchScored(query: string, opts?: SearchOpts & { score?: boolean; extract?: boolean })
  : Promise<{ results: SearchEngineResult[]; scored?: ScoredResult[]; extracted?: StructuredExtraction[] }>
```

在 `crawlSearchResults`（约 line 853）中插入 filter/score/extract 三阶段，**默认关闭**（`opts.score`/`opts.extract` 显式开启），保持 `searchMulti` 向后兼容。

**扩展** `calculateQualityScore`（line 814）而非重建 — 复用其 wordCount/result 结构，增加多维评分回调钩子。

### 资源依赖
| 依赖 | 路径 | 用途 |
|------|------|------|
| `ConformalHallucinationDetector` | `src/memory/hallucination-detector.ts:290` | factualAccuracy |
| `ConformalRetriever` | `src/memory/conformal-retriever.ts` | 预测集 |
| `IDFCache` 接口 | `src/memory/hallucination-detector.ts:149` | BM25（复制接口） |
| `LLMClient` | `src/dre/llm/client.ts` | 结构化抽取 |
| `SearchEngineResult` | `src/crawl/search-engines.ts` | 输入类型 |
| `calculateQualityScore` | `src/crawl/data-pipeline.ts:814` | 扩展（不重建） |
| zod | `package.json` ^3.22.0 | schema |

### 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | `result-filter.ts` + 单测 |
| Day 2 | `result-scorer.ts` 三维（credibility/relevance/timeliness）+ 单测 |
| Day 3 | 集成 `ConformalHallucinationDetector` 到 factualAccuracy 维度 |
| Day 4 | `data-extractor.ts` + zod schema + LLM 降级 + 单测 |
| Day 5 | 接入 `data-pipeline.ts` + 集成测试 + commit（分 2 次：新文件 / 接入） |

### 评估机制
**新增**: `tests/crawl-filter-score-extract.test.ts`

| Case | 期望 |
|------|------|
| 5 条含 1 标题党 + 1 重复 URL | filter 返回 3 条，dropped reasons 正确 |
| `github.com` 结果 | `sourceCredibility ≥ 0.85` |
| 1 年前 date 的结果 | `timeliness ≤ 0.4` |
| snippet 与 vault 事实冲突 | `factualAccuracy ≤ 0.4` |
| LLM 不可用 | `extract()` 返回降级结构，不抛异常 |
| 端到端 `pipeline.searchScored("rust async", { score: true, extract: true })` | `scored.length > 0`，`extracted.length ≤ 5` |

**Gate**: 100 条 filter < 10ms；100 条 score < 500ms（LLM 除外）；旧 `searchMulti` 行为不变

---

## Phase 3（Week 3）— 知识组织

### 目标
1. 定义模型就绪输入 schema（`KnowledgeInput` / `ProcessedKnowledge` / `QualityReport`）
2. 预处理器：清洗 / 标准化 / 实体抽取 / 分词 / chunk
3. 质量评估器：accuracy / completeness / consistency 三维
4. 手术式接入 `knowledge/pipeline.ts`，**顺手解决 7 处 process.env 违规**

### 技术方案

#### Task 3.1 — Schema 定义

**修改**: `src/knowledge/types.ts`（追加，不动现有类型）

新增 3 个 zod schema:
- `KnowledgeInput`: source（url/domain/fetchedAt/rawFormat）+ content（title/rawText/markdown/language）+ metadata（author/publishDate/tags）
- `ProcessedKnowledge`: input + cleanedText + normalizedMarkdown + entities[] + tokens[] + chunks[] + processedAt
- `QualityReport`: overall + dimensions（accuracy/completeness/consistency）+ issues[] + verificationVerdict + conformalPValue + assessedAt

#### Task 3.2 — 预处理器

**新建**: `src/knowledge/preprocessor.ts`

```typescript
export class KnowledgePreprocessor {
  constructor(opts: { extractEntities?: boolean; chunkSize?: number; language?: string }) {}
  async process(input: KnowledgeInput): Promise<ProcessedKnowledge>;
}
```

功能:
- `cleanText`: 去 HTML 残留、零宽字符、控制字符
- `htmlToMarkdown`: 复用 `src/crawl/data-pipeline.ts:35` 的 `DEFAULT_NOISE_RE` 模式（import 或复制接口）
- `normalizeMarkdown`: 标题层级归一化、列表符号统一
- `extractEntities`: 规则 + 词表（人名/组织/技术名），不引入 NLP 库
- `tokenize`: 中英文混合分词（自行实现，不依赖 hallucination-detector 私有函数）
- `chunk`: 复用 `src/crawl/data-pipeline.ts:717` `chunkByHeadings` 逻辑（复制为独立工具，因为原方法是 private）

#### Task 3.3 — 质量评估器

**新建**: `src/knowledge/quality-assessor.ts`

```typescript
export class QualityAssessor {
  constructor(opts: { factBase?: FactEntry[]; calibrationSet?: CalibrationPair[]; strictMode?: boolean }) {}
  async assess(processed: ProcessedKnowledge): Promise<QualityReport>;
}
```

| 维度 | 计算 |
|------|------|
| `accuracy` | 每个 chunk 调 `ConformalHallucinationDetector.verify()`，取最小 confidence；isHallucination 记 issue(high) |
| `completeness` | 字段填充率：`(有 author + publishDate + tags.length>0 + chunks.length>=3) / 4` |
| `consistency` | chunks 两两 Jaccard 相似度，> 0.7 但语义矛盾（规则检测 negation）则降分 |

**复用**:
- `src/memory/hallucination-detector.ts:65` `FactEntry` 类型
- `src/memory/hallucination-detector.ts:290` `ConformalHallucinationDetector`
- `src/dre/runtime/verification-engine.ts` 的 `Verdict` 类型（"pass"|"fail"|"uncertain"）作为设计参考（不直接依赖，避免循环依赖）

#### Task 3.4 — 接入 knowledge/pipeline.ts

**修改**: `src/knowledge/pipeline.ts`（手术式）

在 `runPipeline`（line 96）内部，每个数据源采集完成后插入预处理 + 质量评估：
- `verificationVerdict === "fail"` 的内容跳过（不写入 vault）
- 写入 `processed` + `report` 到 dataset JSONL
- **顺手**把 7 处 `process.env` 直接读取改为 `readString`（在同一文件、同一任务范围内，符合 Rule 1）

### 资源依赖
| 依赖 | 路径 | 用途 |
|------|------|------|
| `ConformalHallucinationDetector` | `src/memory/hallucination-detector.ts:290` | accuracy |
| `FactEntry` | `src/memory/hallucination-detector.ts:65` | factBase 类型 |
| `DEFAULT_NOISE_RE` | `src/crawl/data-pipeline.ts:35` | HTML 清洗 |
| `chunkByHeadings` 逻辑 | `src/crawl/data-pipeline.ts:717` | chunk（复制为独立工具） |
| `Verdict` 类型 | `src/dre/runtime/verification-engine.ts` | 设计参考 |
| `readString` | `src/utils/env.ts` | 替换 process.env |
| zod | `package.json` | schema |

### 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | `types.ts` 追加 3 个 schema + 单测 |
| Day 2 | `preprocessor.ts` cleanText + normalizeMarkdown + 单测 |
| Day 3 | `preprocessor.ts` entity/tokens/chunks + 单测 |
| Day 4 | `quality-assessor.ts` 三维评分 + 集成 |
| Day 5 | 接入 `knowledge/pipeline.ts` + process.env 迁移 + 集成测试 + commit |

### 评估机制
**新增**: `tests/knowledge-preprocess-quality.test.ts`

| Case | 期望 |
|------|------|
| 输入含 `<script>` 的 rawText | `cleanedText` 不含 `<script>` |
| 中英文混合 | `tokens.length > 0`，含中文词与英文词 |
| chunk 与 factBase 矛盾 | `accuracy < 0.4`，issues 含 high |
| 缺 author/publishDate/tags | `completeness < 0.5` |
| 两 chunk 互相矛盾 | `consistency < 0.6` |
| 端到端 pipeline 跑 `bookTopics: ["rust"]` | JSONL 每行含 `processed` 与 `report` |
| `verificationVerdict === "fail"` 不写入 vault | vault 文件数 ≤ 输入数 |

**Gate**: 10KB markdown 处理 < 200ms；`knowledge/pipeline.ts` 的 7 处 process.env 违规降为 0；`architecture-integrity.test.ts` 不退化

---

## Phase 4（Week 4）— 安全加固完成

### 目标
1. API Key 静态加密（AES-256-GCM）
2. per-user / per-IP 限流细化
3. 沙箱加固（Windows 资源限制 + 资源使用实测）
4. 安全监控（接 HealthChecker + metrics）
5. WebSocket `maxClients` 配置化（已存在 `MAX_WS_CLIENTS=100`，仅需 env 化）

### 技术方案

#### Task 4.1 — API Key 静态加密

**修改**: `src/utils/api-key-persistence.ts`

```typescript
import { createCipheriv, createDecipheriv, randomBytes, createHash } from "crypto";

function getMasterKey(): Buffer {
  const raw = readString("AXIOM_ENCRYPTION_KEY");
  if (!raw) throw new Error("AXIOM_ENCRYPTION_KEY not set; refusing to persist plaintext keys");
  return createHash("sha256").update(raw).digest();  // 派生 32 字节
}

function encrypt(plaintext: string): string {
  const key = getMasterKey();
  const iv = randomBytes(12);  // GCM 推荐 12 字节
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

function decrypt(payload: string): string {
  if (!payload.startsWith("enc:v1:")) return payload;  // 向后兼容旧明文
  // ... 解密
}
```

- `saveApiKeyOverride`（line 58）: 写 DB 前 `encrypt(apiKey)`
- `loadApiKeyOverrides`（line 37）: 读后 `decrypt(r.api_key)`
- `initApiKeyOverridesTable`: 若 DB 有旧明文 + `AXIOM_ENCRYPTION_KEY` 已配，自动迁移（事务中执行）
- **降级**: 未配 `AXIOM_ENCRYPTION_KEY` 时 `saveApiKeyOverride` 抛错（fail-closed），`loadApiKeyOverrides` 仍能读旧明文保运行

#### Task 4.2 — 多维度限流

**修改**: `src/utils/rate-limiter.ts`

```typescript
export interface RateLimitConfig {
  global?: RateLimitRule;
  perIp?: RateLimitRule;
  perUser?: RateLimitRule;  // 基于 x-api-key 哈希
  perPath?: Map<string, RateLimitRule>;
}

export class MultiDimensionLimiter {
  check(req: Request): { allowed: boolean; headers: Record<string,string>; violated: string[] };
}
```

**修改 `src/main.ts:472`**: 现有 `rateLimitCheck(req)` 改为 `MultiDimensionLimiter`。默认:
- `/chat`: perIp 10/min, perUser 30/min
- `/web-search`: perIp 30/min
- 其他: 全局 100/min

限流触发时 `auditLogger.log({ event: "rate_limit.exceeded", ... })`。

#### Task 4.3 — 沙箱加固

**修改**: `src/sandbox/process-sandbox.ts`

**Windows**（当前完全无资源限制）:
- 监控 `proc.stdout` 字节数，超 `maxOutputBytes`（默认 10MB）kill
- 用 `process.resourceUsage?.()` 在 proc 退出后采集，回填 `resourceUsage.memoryBytes`

**Linux 增强**:
- 当前 `ulimit -v`（line 35）+ `ulimit -t`（line 38）
- 新增 `ulimit -m`（resident）+ `ulimit -f`（文件大小）
- 检测 `unshare` 可用性，可用则 `unshare -n` 包裹命令（网络隔离）

**CPU 限制**: 区分"超时"与"CPU 超限"两种 exitCode 语义。

接入 `auditLogger.log({ event: "sandbox.execute", resource: command, outcome: ... })`。

#### Task 4.4 — 安全监控

**新建**: `src/utils/security-monitor.ts`

```typescript
export interface SecurityAlert {
  type: "auth_failure_burst" | "rate_limit_burst" | "sandbox_failure_burst" | "ws_flood";
  severity: "low" | "medium" | "high";
  actor: string; count: number; windowMs: number; triggeredAt: number;
}

export class SecurityMonitor {
  constructor(thresholds = {
    authFailureBurst: { count: 5, windowMs: 60_000 },
    rateLimitBurst: { count: 10, windowMs: 60_000 },
    sandboxFailureBurst: { count: 3, windowMs: 60_000 },
  }) {}
  record(event: AuditEvent, actor: string): SecurityAlert | null;
  getActiveAlerts(): SecurityAlert[];
}
```

**接入点**:
- `route-auth.ts`（Phase 1）: 每次 auth failure 调 `securityMonitor.record()`
- `audit-logger.ts`（Phase 1）: 所有事件旁路到 securityMonitor
- `src/core/health-checker.ts`: 新增 `checkSecurity()` 项，读 `securityMonitor.getActiveAlerts()` 加入 `SystemReport`

#### Task 4.5 — WebSocket maxClients 配置化

**修改**: `src/utils/websocket.ts`（1 行）

```typescript
// 原: const MAX_WS_CLIENTS = 100;
const MAX_WS_CLIENTS = parseInt(readString("WS_MAX_CLIENTS", "100"), 10);
```

`onOpen` 拒绝时 `auditLogger.log({ event: "ws_flood", ... })`。

### 资源依赖
| 依赖 | 路径 | 用途 |
|------|------|------|
| `crypto` (Bun 内置) | — | AES-256-GCM |
| `RateLimiter` | `src/utils/rate-limiter.ts:15` | 多维限流复用 |
| `auditLogger` | Phase 1 新建 | 接入所有安全事件 |
| `HealthChecker` | `src/core/health-checker.ts` | 注册新检查项 |
| `wsManager` | `src/utils/websocket.ts` | 告警广播 |

### 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | `api-key-persistence.ts` 加密 + migration + 单测 |
| Day 2 | `rate-limiter.ts` MultiDimensionLimiter + `main.ts` 接入 + 单测 |
| Day 3 | `process-sandbox.ts` Windows 加固 + resourceUsage + 单测 |
| Day 4 | `security-monitor.ts` + HealthChecker 接入 + WebSocket 配置化 |
| Day 5 | `tests/security-hardening.test.ts` 全套 + 全量回归 + commit |

### 评估机制
**新增**: `tests/security-hardening.test.ts`

| Case | 期望 |
|------|------|
| 配 `AXIOM_ENCRYPTION_KEY` 后 saveApiKeyOverride | DB `api_key` 字段以 `enc:v1:` 开头 |
| 无 `AXIOM_ENCRYPTION_KEY` 时 saveApiKeyOverride | 抛错，不写入 |
| 旧明文 + 配 key 后 loadApiKeyOverrides | 返回正确明文（自动 decrypt） |
| `/chat` 同 IP 第 11 次请求 | 429 |
| 同 user 第 31 次请求 | 429 |
| sandbox 超时 | exitCode 非 0，error 含 "timeout" |
| sandbox stdout 超 10MB | proc 被 kill |
| 5 次 auth.failure 同 IP | securityMonitor 返回 high severity alert |
| `WS_MAX_CLIENTS=2` 时第 3 个连接 | close(1013) |

**Gate**: 加密后 DB grep 不到明文 key；HealthChecker `/health` 响应含 `security` 检查项；全量 `bun test` 不退化

---

## 全局评估仪表板

| 维度 | 指标 | 基线 | 目标 | 测量方法 |
|------|------|------|------|---------|
| 安全 | P0 漏洞 | 1（Host 头绕过） | 0 | `tests/security-islocal.test.ts` |
| 安全 | 审计覆盖率 | 0% 敏感操作 | 100%（vault/sandbox/plugin/auth） | grep `auditLogger.log` 调用点 |
| 安全 | 日志密钥泄漏 | 可能含 token | 0 处明文 | `tests/logger-redact.test.ts` |
| 安全 | API Key 静态加密 | 0% | 100%（配 key 后） | `tests/security-hardening.test.ts` |
| 安全 | 限流维度 | 1（全局） | 3（全局+IP+User） | MultiDimensionLimiter 接入 |
| 检索 | 多维度打分 | 0 维度 | 4 维度 | `tests/crawl-filter-score-extract.test.ts` |
| 检索 | 结构化抽取 | 无统一 schema | zod schema 强制 | DataExtractor 接入 |
| 知识 | 模型就绪 schema | 无 | 3 个 | `src/knowledge/types.ts` |
| 知识 | 预处理流程 | 无 | 5 步 | `tests/knowledge-preprocess-quality.test.ts` |
| 知识 | 质量评估 | 单一 score | 3 维度 + issues | QualityAssessor |
| 知识 | process.env 违规 | 7 处 | 0 处（knowledge 模块） | `architecture-integrity.test.ts` |
| 架构 | 测试通过率 | 现状 | 不退化 | `bun test` 全量 |
| 合规 | AGENTS.md 合规 | — | 100% 提交有 log + 备份 + push | `docs/operations-log.md` 条目数 = 提交数 |

## 风险与缓解

| 风险 | 等级 | 缓解 |
|------|------|------|
| `server.requestIP(req)` 反代后返回代理 IP | 中 | 文档化：`AXIOM_TRUST_PROXY=true` 时信任 `x-real-ip`，nginx 需配 `proxy_set_header x-real-ip $remote_addr` |
| Phase 2 LLM 抽取失败率高阻塞 pipeline | 中 | `data-extractor.ts` 强制降级路径，默认 `extract: false` 显式开启 |
| Phase 4 加密 migration 改坏旧明文记录 | 高 | migration 在事务中；先 dry-run 输出待迁移数；备份 DB 到 `.tmp/backups/data/agent.db.bak` |
| 沙箱 Windows 加固不彻底（无原生 ulimit） | 中 | 文档化限制；推荐生产用 Docker 沙箱；Windows 仅 timeout + output size |
| 改动后 `architecture-integrity.test.ts` 退化 | 高 | 每 Phase 结束前必跑；新文件遵循 4 层架构 |
| 并行子 agent 同时改 main.ts 冲突 | 中 | Phase 1 的 4 Task 严格串行；Phase 2-4 可适度并行 |

## 验证（端到端）

每阶段完成后执行:

```bash
# 1. 类型检查
bunx tsc --noEmit

# 2. 架构约束测试（不退化）
bun test tests/architecture-integrity.test.ts

# 3. 本阶段新增测试
bun test tests/security-islocal.test.ts         # Phase 1
bun test tests/crawl-filter-score-extract.test.ts  # Phase 2
bun test tests/knowledge-preprocess-quality.test.ts # Phase 3
bun test tests/security-hardening.test.ts       # Phase 4

# 4. 全量回归
bun test tests/

# 5. AGENTS.md 合规检查
# - 备份已删：ls .tmp/backups/ 应为空
# - operations-log 已更新：tail docs/operations-log.md
# - 已 push internal211：git log --oneline internal211/main..HEAD 应为空
```

**手工验证 Phase 1 P0 修复**:
```bash
# 启动服务后，从另一台机器（非 localhost）攻击：
curl -H "Host: localhost" http://<lan-ip>:18789/chat -X POST -d '{"messages":[]}'
# 期望: 401 Unauthorized（修复前会返回 200）
```

## 关键文件清单

| 文件 | 阶段 | 改动类型 |
|------|------|---------|
| `src/main.ts` | P1+P4 | 修改（P0 修复 + 限流接入） |
| `src/utils/audit-logger.ts` | P1 | 新建 |
| `src/utils/logger.ts` | P1 | 修改（脱敏） |
| `src/utils/route-auth.ts` | P1 | 新建 |
| `src/routes/vault.ts`, `sandbox.ts`, `plugin-routes.ts`, `api-keys.ts` | P1 | 修改（加守卫） |
| `src/crawl/result-filter.ts` | P2 | 新建 |
| `src/crawl/result-scorer.ts` | P2 | 新建 |
| `src/crawl/data-extractor.ts` | P2 | 新建 |
| `src/crawl/data-pipeline.ts` | P2 | 修改（接入 + 扩展 calculateQualityScore） |
| `src/knowledge/types.ts` | P3 | 修改（追加 schema） |
| `src/knowledge/preprocessor.ts` | P3 | 新建 |
| `src/knowledge/quality-assessor.ts` | P3 | 新建 |
| `src/knowledge/pipeline.ts` | P3 | 修改（接入 + process.env 迁移） |
| `src/utils/api-key-persistence.ts` | P4 | 修改（加密） |
| `src/utils/rate-limiter.ts` | P4 | 修改（多维限流） |
| `src/sandbox/process-sandbox.ts` | P4 | 修改（Windows 加固） |
| `src/utils/security-monitor.ts` | P4 | 新建 |
| `src/utils/websocket.ts` | P4 | 修改（1 行配置化） |
| `src/core/health-checker.ts` | P4 |