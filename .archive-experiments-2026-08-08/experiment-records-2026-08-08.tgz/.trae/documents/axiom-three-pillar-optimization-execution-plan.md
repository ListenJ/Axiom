# Axiom Runtime v4.0 — 三支柱系统化优化执行计划（v2，落地版）

> 本计划在 v1（`axiom-systematic-optimization-plan.md`）基础上，经 Phase 1 全量直接读码校准后产出。
> v1 已批准但**未执行**（`docs/operations-log.md` 仅有 1 条记录，所有交付文件均缺失）。
> 本 v2 修正了 v1 中 5 处与代码不符的事实，并给出可被 executor 无决策执行的精确步骤。

## 摘要（Summary）

用户要求对项目进行系统性优化，聚焦三大支柱：(1) 网络检索优化（过滤/评分/抽取），(2) 知识整理准备（格式/预处理/质量评估），(3) 安全措施完善（审计/加密/访问控制/监控/策略）。

本计划将三大支柱映射为 **4 个串行阶段**（Phase 1+4 = 安全，Phase 2 = 检索，Phase 3 = 知识），每阶段独立可发布，全程遵守 `AGENTS.md` 五条强约束。

**直接读码确认的关键事实**:
- 🔴 **P0 认证绕过漏洞**确认存在：[src/main.ts:414](file:///d:/openclaw-fusion/src/main.ts#L414) `if (url.hostname === "localhost" || url.hostname === "127.0.0.1") return true;` —— `url.hostname` 取自 HTTP `Host` 头，可伪造。同处 [src/main.ts:460](file:///d:/openclaw-fusion/src/main.ts#L460) WebSocket upgrade 有同样漏洞。`fetch(req, server)` 签名已含 `server`，可直接用 `server.requestIP(req)`。
- ✅ [src/utils/security.ts:49](file:///d:/openclaw-fusion/src/utils/security.ts#L49) `sanitizeRequestBody` 已存在，可复用做 logger 脱敏。
- ✅ [src/utils/security.ts:23](file:///d:/openclaw-fusion/src/utils/security.ts#L23) `createSecurityHeaders` 已支持 HSTS/CSP。
- ✅ [src/routes/api-keys.ts:36](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L36) `requireAuth(ctx)` 模式可抽取为通用 helper。
- ✅ [src/crawl/data-pipeline.ts:814](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L814) `calculateQualityScore` 已存在（private，0-100 分），应**扩展**不重建。
- ✅ [src/memory/hallucination-detector.ts:290](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L290) `ConformalHallucinationDetector` 已导出，可复用。
- ✅ `zod ^3.22.0` 已在 [package.json:75](file:///d:/openclaw-fusion/package.json#L75)。
- ✅ Bun 内置 `node:crypto`，AES-256-GCM 可直接用，无需新依赖。

**v1 → v2 的 5 处修正**:
1. `knowledge/pipeline.ts` 实际只有 **1 处** `process.env`（[line 39](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L39) `ZHIPU_API_KEY`），v1 误称"7 处"。7 处分布在 knowledge/* 其他文件 + routes/models.ts，需扫描定位。
2. `metrics.increment()` 要求先 `metrics.register()`（[metrics.ts:31-35](file:///d:/openclaw-fusion/src/utils/metrics.ts#L31) 否则 warn 丢弃）。v1 漏了注册步骤。
3. `searchMulti` 是 `DataPipeline` 的**方法**，非 interface。
4. `knowledge/pipeline.ts` 集成点是 `structureWithGLM()` 返回后（[line 164](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L164)），不是泛化"数据源采集循环"。
5. `ConformalHallucinationDetector` 的公开校验方法名、`LLMClient` 导入路径、vault/sandbox/plugin 路由函数名需在实施时读全文确认（v1 假设了名字）。

**约束**（[AGENTS.md](file:///d:/openclaw-fusion/AGENTS.md)）:
1. 最小化施工，禁止过度施工
2. 改代码前：备份到 `.tmp/backups/` → 读全文 → 修改 → 验证 → 删备份
3. 提交到 `internal211` 远端（`ssh://data@192.168.2.11/home/data/openclaw-fusion.git`）
4. 删除 = 归档到 `archive/` + 写 `archive/ARCHIVE-LOG.md`
5. 操作留痕 `docs/operations-log.md`（提交一次记录一次）

---

## 现状分析（Current State Analysis）

### 安全现状
| 项 | 现状 | 文件:行 | 风险 |
|----|------|---------|------|
| 本地认证 | `url.hostname` 判断 isLocal（可伪造 Host 头） | [main.ts:414](file:///d:/openclaw-fusion/src/main.ts#L414), [:460](file:///d:/openclaw-fusion/src/main.ts#L460) | 🔴 P0 认证绕过 |
| 审计日志 | 无 | — | 敏感操作无留痕 |
| Logger 脱敏 | 无（[logger.ts:212](file:///d:/openclaw-fusion/src/utils/logger.ts#L212) `serialize()` 原样输出 context） | [logger.ts](file:///d:/openclaw-fusion/src/utils/logger.ts) | 日志可能泄漏 token |
| 敏感端点二次认证 | 仅 `/api-keys` 有 `requireAuth` | [api-keys.ts:36](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L36) | vault/sandbox/plugin 裸奔 |
| API Key 存储 | **明文** `api_key TEXT NOT NULL` | [api-key-persistence.ts:21](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts#L21) | DB 泄漏即 key 泄漏 |
| 限流 | 单维（全局 100/min + 路径规则），已用 `x-real-ip` | [rate-limiter.ts:117](file:///d:/openclaw-fusion/src/utils/rate-limiter.ts#L117) | 无 per-user 维度 |
| 沙箱 Windows | **无资源限制**（仅 timeout） | [process-sandbox.ts:28](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L28) | 内存/CPU/输出无界 |
| 沙箱 Linux | `ulimit -v` + `ulimit -t`，无网络隔离 | [process-sandbox.ts:35-38](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L35) | 无文件大小/网络限制 |
| WebSocket 上限 | 硬编码 `MAX_WS_CLIENTS = 100` | [websocket.ts:29](file:///d:/openclaw-fusion/src/utils/websocket.ts#L29) | 不可配置 |
| 健康检查 | 8 项，无 security 项 | [health-checker.ts:58](file:///d:/openclaw-fusion/src/core/health-checker.ts#L58) | 安全事件不可观测 |

### 检索现状
| 项 | 现状 | 文件:行 |
|----|------|---------|
| 结果过滤 | 无（直接抓取 top-N） | [data-pipeline.ts:853](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L853) `crawlSearchResults` |
| 质量评分 | 单一 0-100 分（private `calculateQualityScore`） | [data-pipeline.ts:814](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L814) |
| 多维打分 | 无 | — |
| 结构化抽取 | 无统一 schema（pipeline.ts 有 GLM 结构化但非 zod 强制） | [knowledge/pipeline.ts:38](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L38) |
| HTML 噪声清理 | `DEFAULT_NOISE_RE`（9 个 pattern） | [data-pipeline.ts:24-35](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L24) |
| 内容分块 | `chunkByHeadings`（private 方法） | [data-pipeline.ts:717](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L717) |

### 知识现状
| 项 | 现状 | 文件:行 |
|----|------|---------|
| 类型定义 | 4 个接口（KnowledgeSource/DictionaryEntry/CollectOptions/CollectResult），无 zod schema | [types.ts](file:///d:/openclaw-fusion/src/knowledge/types.ts) |
| 预处理 | 无独立模块（GLM 直接吃 rawMarkdown） | [pipeline.ts:52](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L52) |
| 质量评估 | 无（GLM 返回 `quality_score` 单值） | [pipeline.ts:33](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L33) |
| process.env 违规 | pipeline.ts 内 1 处（`ZHIPU_API_KEY` line 39） | [pipeline.ts:39](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L39) |

---

## Phase 1（Week 1）— 安全 P0 修复 + 安全基础

### 目标
1. 修复 isLocal Host-header 认证绕过（P0）
2. 新增审计日志
3. Logger 密钥脱敏
4. 敏感端点 per-route 二次认证

### Task 1.1 — 修复 isLocal 漏洞（P0）

**修改文件**: [src/main.ts](file:///d:/openclaw-fusion/src/main.ts)（2 处手术式编辑）

**AGENTS Rule 2 流程**:
1. 备份: `Copy-Item src\main.ts .tmp\backups\src\main.ts.bak`（先 `mkdir -p .tmp/backups/src`）
2. 读全文: Read `src/main.ts`（已读 line 1-494，需补读 1-395 与 494+ 确认无其他 isLocal 点）
3. 修改: 在 `checkApiKey`（[line 409](file:///d:/openclaw-fusion/src/main.ts#L409)）之前新增 `isLocalRequest` 辅助函数:

```typescript
import type { Server } from "bun";  // 顶部已有 ServerWebSocket，需补 Server 类型

function isLocalRequest(server: Server, req: Request): boolean {
  const ip = server.requestIP(req);  // Bun 原生，不可伪造
  if (ip) {
    return ip.address === "127.0.0.1" || ip.address === "::1" || ip.address === "::ffff:127.0.0.1";
  }
  if (readString("AXIOM_TRUST_PROXY") === "true") {
    const real = req.headers.get("x-real-ip");
    if (real) return real === "127.0.0.1" || real === "::1";
  }
  return false; // fail-closed
}
```

4. 编辑点 1（[line 409](file:///d:/openclaw-fusion/src/main.ts#L409)）: `checkApiKey(req: Request)` → `checkApiKey(server: Server, req: Request)`，把 [line 414](file:///d:/openclaw-fusion/src/main.ts#L414) `if (url.hostname === "localhost" || url.hostname === "127.0.0.1") return true;` 替换为 `if (isLocalRequest(server, req)) return true;`
5. 编辑点 2（[line 454](file:///d:/openclaw-fusion/src/main.ts#L454)）: `if (!checkApiKey(req))` → `if (!checkApiKey(server, req))`
6. 编辑点 3（[line 460](file:///d:/openclaw-fusion/src/main.ts#L460)）: `const isLocal = url.hostname === "localhost" || url.hostname === "127.0.0.1";` → `const isLocal = isLocalRequest(server, req);`
7. 验证: `bunx tsc --noEmit` + `bun test tests/security-islocal.test.ts tests/architecture-integrity.test.ts`
8. 删备份

**新增测试**: `tests/security-islocal.test.ts`
- 由于 `isLocalRequest` 依赖真实 `Server` 对象（`requestIP` 无法 mock 纯 Request），测试策略：
  - 单元测试 `isLocalRequest` 逻辑：若模块导出该函数，构造 mock `{ requestIP: () => ({address:"192.168.1.5", family:"IPv4", port:12345}) }` → 期望 false；`address:"127.0.0.1"` → 期望 true
  - `AXIOM_TRUST_PROXY` 未设时 `x-real-ip: 127.0.0.1` → 期望 false（fail-closed）
  - `AXIOM_TRUST_PROXY=true` 时 `x-real-ip: 127.0.0.1` → 期望 true
- 若 `isLocalRequest` 不便导出（main.ts 非模块），则改为导出到 `src/utils/is-local.ts` 独立小模块，main.ts 引用之（符合 Rule 1，可测性提升是必要的最小改动）

**决策**: 将 `isLocalRequest` 放到独立模块 `src/utils/is-local.ts`，导出 `isLocalRequest(server: Server, req: Request): boolean`，main.ts import。理由：可测试性 + 不污染 main.ts。这是符合 Rule 1 的最小必要改动。

### Task 1.2 — 审计日志模块

**新建**: `src/utils/audit-logger.ts`

```typescript
export type AuditEvent =
  | "auth.success" | "auth.failure"
  | "vault.write" | "sandbox.execute" | "plugin.install" | "plugin.uninstall"
  | "apikey.set" | "apikey.delete" | "rate_limit.exceeded" | "config.change" | "ws_flood";

export interface AuditEntry {
  timestamp: string; event: AuditEvent; actor: string;
  resource?: string; outcome: "success" | "failure" | "denied";
  reason?: string; metadata?: Record<string, unknown>;
}

export class AuditLogger {
  constructor(opts?: { filePath?: string; maxSize?: number; maxFiles?: number }) {}
  log(entry: Omit<AuditEntry, "timestamp">): void;  // 同步追加 JSON Lines
}
export const auditLogger: AuditLogger;  // 默认单例，写 data/logs/audit.log
```

**关键修正（v2）**: 必须先在 `metrics` 注册 `audit_event_total` 计数器，否则 `metrics.increment` 被 warn 丢弃。在 audit-logger.ts 模块初始化段:
```typescript
import { metrics } from "./metrics.js";
metrics.register({ name: "audit_event_total", help: "Audit events by type and outcome", type: "counter" });
```
`log()` 内部 `metrics.increment("audit_event_total", 1, { event, outcome })`。

**复用**: 文件轮转逻辑参考 [logger.ts:89](file:///d:/openclaw-fusion/src/utils/logger.ts#L89) `rotateIfNeeded()` 模式（简化版：超 maxSize rename 加时间戳，保留 maxFiles 个）。

**新增测试**: `tests/audit-logger.test.ts` — 写入格式（JSON Lines 可 parse）、字段完整、轮转触发（设 maxSize=1KB 写 2KB 触发）。

### Task 1.3 — Logger 密钥脱敏

**修改**: [src/utils/logger.ts](file:///d:/openclaw-fusion/src/utils/logger.ts)

**AGENTS Rule 2 流程**: 备份 → 读全文（已读 251 行）→ 修改 `serialize()`（[line 212](file:///d:/openclaw-fusion/src/utils/logger.ts#L212)）→ 验证 → 删备份。

**改动**: 在 `serialize()` 返回前对 `obj.context` 调用 `redactContext()`:
```typescript
import { sanitizeRequestBody } from "./security.js";

const SECRET_VALUE_RE = /(sk-[A-Za-z0-9]{8,}|Bearer\s+\S+|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{36})/g;

function redactContext(ctx: Record<string, unknown>): Record<string, unknown> {
  const cleaned = sanitizeRequestBody(ctx) as Record<string, unknown>;
  for (const [k, v] of Object.entries(cleaned)) {
    if (typeof v === "string" && SECRET_VALUE_RE.test(v)) {
      cleaned[k] = "[REDACTED]";
    }
  }
  return cleaned;
}
```
在 `serialize()` 内 `if (entry.context...)` 后改为 `obj.context = redactContext(entry.context);`。

**新增测试**: `tests/logger-redact.test.ts`:
- `logger.info("x", { api_key: "sk-xxx" })` → 输出含 `[REDACTED]`，不含 `sk-xxx`
- `logger.info("x", { token: "Bearer abc123" })` → `[REDACTED]`
- `logger.info("x", { normal: "hello" })` → `hello` 保留
- `logger.info("x", { nested: { password: "pw" } })` → 递归脱敏

### Task 1.4 — 敏感端点 per-route 二次认证

**新建**: `src/utils/route-auth.ts`
```typescript
import type { RouteContext } from "../routes/types.js";
import { readString } from "./env.js";
import { auditLogger } from "./audit-logger.js";

export function requireAuthToken(ctx: RouteContext): Response | null {
  const token = readString("AXIOM_AUTH_TOKEN");
  if (!token) {
    return ctx.jsonResponse({ error: "Server auth not configured (AXIOM_AUTH_TOKEN missing)" }, 503, ctx.baseHeaders);
  }
  const provided = ctx.req.headers.get("x-api-key") ||
    ctx.req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (provided !== token) {
    auditLogger.log({
      event: "auth.failure", actor: ctx.req.headers.get("x-real-ip") || "unknown",
      outcome: "denied", reason: "invalid or missing token", resource: ctx.url.pathname,
    });
    return ctx.jsonResponse({ error: "Unauthorized" }, 401, ctx.baseHeaders);
  }
  return null;
}
```

**修改文件**（每个仅加 2-3 行守卫；**实施前必须 Read 全文确认函数名**）:
- [src/routes/api-keys.ts](file:///d:/openclaw-fusion/src/routes/api-keys.ts): 删除本地 `requireAuth`（[line 36-55](file:///d:/openclaw-fusion/src/routes/api-keys.ts#L36)），改为 `import { requireAuthToken } from "../utils/route-auth.js";`，调用点 `requireAuth(ctx)` → `requireAuthToken(ctx)`
- [src/routes/vault.ts](file:///d:/openclaw-fusion/src/routes/vault.ts): **先 Read 确认** `handleVaultWrite` / `handleVaultAtomic` / `handleVaultDistill` 函数名与位置，函数体首行加 `const authErr = requireAuthToken(ctx); if (authErr) return authErr;` + 成功时 `auditLogger.log({ event: "vault.write", actor: ..., outcome: "success", resource: ... })`
- [src/routes/sandbox.ts](file:///d:/openclaw-fusion/src/routes/sandbox.ts): **先 Read 确认** `handleSandboxExecute` 函数名，首行加守卫 + `auditLogger.log({ event: "sandbox.execute", ... })`
- [src/routes/plugin-routes.ts](file:///d:/openclaw-fusion/src/routes/plugin-routes.ts): **先 Read 确认** install/uninstall handler 名，加守卫 + `auditLogger.log({ event: "plugin.install"/"plugin.uninstall", ... })`

**新增测试**: `tests/route-auth.test.ts`:
- 无 token 配置 → 503
- 错误 token → 401 + audit log 写入 `auth.failure`
- 正确 token → null（放行）

### Phase 1 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | Task 1.1: is-local.ts + main.ts 改造 + security-islocal.test.ts |
| Day 2 | Task 1.2: audit-logger.ts + metrics 注册 + audit-logger.test.ts |
| Day 3 | Task 1.3: logger.ts 脱敏 + logger-redact.test.ts |
| Day 4 | Task 1.4: route-auth.ts + 4 路由接入（先读确认函数名）+ route-auth.test.ts |
| Day 5 | 全量回归 `bun test` + `tsc --noEmit` + commit + push internal211 + operations-log |

### Phase 1 评估 Gate
- `tests/security-islocal.test.ts` 通过
- `tests/audit-logger.test.ts` 通过
- `tests/logger-redact.test.ts` 通过
- `tests/route-auth.test.ts` 通过
- `tests/architecture-integrity.test.ts` 不退化
- 手工: `curl -H "Host: localhost" http://<lan-ip>:18789/chat` → 401（修复前会 200）

---

## Phase 2（Week 2）— Web 检索优化

### 目标
1. 结果过滤器：剔除低质/重复/标题党
2. 多维度打分器：来源可信度 / 内容相关度 / 时效性 / 事实准确度
3. LLM 结构化抽取器：zod schema 强制
4. 手术式接入 `data-pipeline.ts`，**扩展** `calculateQualityScore`，不破坏 `searchMulti` 方法

### Task 2.1 — 结果过滤器

**新建**: `src/crawl/result-filter.ts`

```typescript
import type { SearchEngineResult } from "./search-engines.js";  // 已确认 line 12

export interface FilterOptions {
  minContentLength?: number;      // 默认 50
  maxDuplicateRatio?: number;     // 默认 0.8（Jaccard > 此值判重复）
  blockListDomains?: string[];
  blockClickbait?: boolean;
}
export interface FilterDecision {
  result: SearchEngineResult; kept: boolean; reasons: string[];
}
export function filterResults(
  query: string,
  results: SearchEngineResult[],
  opts?: FilterOptions
): { kept: SearchEngineResult[]; dropped: FilterDecision[] };
```

**启发式规则**（< 5ms/100 条）:
- 长度过短（snippet < minContentLength）
- 标题党（全大写、`!!!`、`震惊|不转不是人|看了吓一跳`）
- URL SimHash + Jaccard 去重（保留首个）
- 域名黑名单（SEO 农场硬编码常量，如 `pinterest.*`、内容农场列表）
- snippet 与 query 字符重合度 < 0.1（跑题）

### Task 2.2 — 多维度打分器

**新建**: `src/crawl/result-scorer.ts`

```typescript
import type { SearchEngineResult } from "./search-engines.js";
import type { FactEntry } from "../memory/hallucination-detector.js";  // 已确认 line 65 导出

export interface ScoreDimensions {
  sourceCredibility: number;  // 0-1
  contentRelevance: number;   // 0-1
  timeliness: number;         // 0-1
  factualAccuracy: number;    // 0-1
}
export interface ScoredResult {
  result: SearchEngineResult;
  dimensions: ScoreDimensions;
  overall: number;
  conformalPValue?: number;
}
export class ResultScorer {
  constructor(opts: { factBase?: FactEntry[]; weights?: Partial<ScoreDimensions> }) {}
  async score(query: string, results: SearchEngineResult[]): Promise<ScoredResult[]>;
}
```

**复用**（不破坏现有模块）:
- [hallucination-detector.ts:290](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L290) `ConformalHallucinationDetector` → `factualAccuracy`
  - **实施前必须 Read hallucination-detector.ts line 340-450 确认公开校验方法名**（可能是 `verify()` / `check()` / `detect()`，返回 `HallucinationVerdict`，[line 79](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L79) 已确认 `HallucinationVerdict` 含 `isHallucination/pValue/confidence/evidence`）
- [hallucination-detector.ts:149](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L149) `IDFCache` 是**私有类**（不导出）→ 在 result-scorer.ts 内复制等价接口（不导出原私有类，符合 Rule 1）；同理 `tokenize`（[line 192](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L192)）、`jaccardSimilarity`（[line 230](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L230)）、`bm25WeightedSimilarity`（[line 244](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L244)）均为模块级非导出函数，需复制
- `ConformalRetriever`（`src/memory/conformal-retriever.ts`）→ `conformalPValue`（**实施前 Read 确认其公开 API**）

**域名可信度表**（硬编码常量 + env 扩展 `AXIOM_CREDIBLE_DOMAINS`）:
- `.edu/.gov/.mil` → 0.9
- `github.com/arxiv.org/ieee.org/doi.org` → 0.85
- `wikipedia.org/stackoverflow.com` → 0.75
- 其他 → 0.5

**加权**: `overall = 0.3*credibility + 0.35*relevance + 0.15*timeliness + 0.2*factualAccuracy`

**timeliness**: 从 `result.date`（[search-engines.ts:17](file:///d:/openclaw-fusion/src/crawl/search-engines.ts#L17) 可选字段）解析，`exp(-Δdays/365)`；无 date → 0.5

### Task 2.3 — LLM 结构化抽取器

**新建**: `src/crawl/data-extractor.ts`

```typescript
import { z } from "zod";
// 实施前必须确认 LLMClient 路径：可能是 ../dre/llm/client.js 或其他
// 用 grep "export class LLMClient" 定位

export const StructuredExtractionSchema = z.object({
  summary: z.string().max(500),
  facts: z.array(z.object({
    subject: z.string(), predicate: z.string(), object: z.string(),
    confidence: z.number().min(0).max(1), source_span: z.string().optional(),
  })),
  entities: z.array(z.object({ name: z.string(), type: z.string() })),
  claims: z.array(z.object({ text: z.string(), verifiable: z.boolean() })),
  keywords: z.array(z.string()),
});
export type StructuredExtraction = z.infer<typeof StructuredExtractionSchema>;

export class DataExtractor {
  constructor(opts: { llm?: LLMClient; model?: string }) {}
  async extract(result: SearchEngineResult | { snippet: string; title: string; link?: string }): Promise<StructuredExtraction>;
}
```

**降级策略**（关键）: LLM 不可用 / 超时 / schema 校验失败时返回降级结构，**不抛异常、不阻塞 pipeline**:
```typescript
{ summary: result.snippet?.slice(0,500) ?? "", facts: [], entities: [], claims: [], keywords: [] }
```

**实施前验证**: `grep -rn "export class LLMClient" src/` 确认导入路径与构造参数。

### Task 2.4 — 接入 data-pipeline.ts

**修改**: [src/crawl/data-pipeline.ts](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts)（手术式，新增 1 方法 + 1 调用点）

新增公共方法（不改动现有 `searchMulti` / `crawlSearchResults` 签名）:
```typescript
async searchScored(
  query: string,
  opts?: { num?: number; engines?: string[]; score?: boolean; extract?: boolean; factBase?: FactEntry[] }
): Promise<{
  results: SearchEngineResult[];
  scored?: ScoredResult[];
  extracted?: StructuredExtraction[];
}>
```

实现: 调现有 `searchMulti` 拿 results → 若 `score` 调 `filterResults` + `ResultScorer.score` → 若 `extract` 对 top-K 调 `DataExtractor.extract`。

**扩展** [calculateQualityScore](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L814)（不重建）: 增加可选回调参数 `scoreHook?: (result, wordCount) => Partial<ScoreDimensions>`，若提供则把多维分融入最终 0-100 分；不提供时行为不变（向后兼容）。

**新增测试**: `tests/crawl-filter-score-extract.test.ts`
| Case | 期望 |
|------|------|
| 5 条含 1 标题党 + 1 重复 URL | filter 返回 3 条，dropped reasons 正确 |
| `github.com` 结果 | `sourceCredibility ≥ 0.85` |
| 1 年前 date 的结果 | `timeliness ≤ 0.4` |
| snippet 与 factBase 事实冲突 | `factualAccuracy ≤ 0.4` |
| LLM 不可用（不传 llm） | `extract()` 返回降级结构，不抛异常 |
| 端到端 `pipeline.searchScored("rust async", { score: true, extract: true })` | `scored.length > 0`，`extracted.length ≤ 5` |
| 旧 `searchMulti` 调用 | 行为不变（回归保护） |

**Gate**: 100 条 filter < 10ms；100 条 score < 500ms（LLM 除外）

### Phase 2 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | result-filter.ts + 单测 |
| Day 2 | result-scorer.ts 三维（credibility/relevance/timeliness）+ 单测 |
| Day 3 | 读 hallucination-detector 全文确认 verify API + 集成 factualAccuracy 维度 |
| Day 4 | data-extractor.ts + zod schema + LLM 降级 + 单测 |
| Day 5 | 接入 data-pipeline.ts + 集成测试 + commit（分 2 次：新文件 / 接入）+ push + log |

---

## Phase 3（Week 3）— 知识组织

### 目标
1. 定义模型就绪输入 schema（KnowledgeInput / ProcessedKnowledge / QualityReport）
2. 预处理器：清洗 / 标准化 / 实体抽取 / 分词 / chunk
3. 质量评估器：accuracy / completeness / consistency 三维
4. 手术式接入 `knowledge/pipeline.ts`，迁移 process.env 违规

### Task 3.1 — Schema 定义

**修改**: [src/knowledge/types.ts](file:///d:/openclaw-fusion/src/knowledge/types.ts)（追加，不动现有 4 个接口）

```typescript
import { z } from "zod";

export const KnowledgeInputSchema = z.object({
  source: z.object({
    url: z.string().url().optional(),
    domain: z.string().optional(),
    fetchedAt: z.number(),
    rawFormat: z.enum(["html", "markdown", "text", "pdf"]),
  }),
  content: z.object({
    title: z.string(),
    rawText: z.string(),
    markdown: z.string().optional(),
    language: z.string().default("unknown"),
  }),
  metadata: z.object({
    author: z.string().optional(),
    publishDate: z.string().optional(),
    tags: z.array(z.string()).default([]),
  }).partial(),
});
export type KnowledgeInput = z.infer<typeof KnowledgeInputSchema>;

export const ProcessedKnowledgeSchema = KnowledgeInputSchema.extend({
  cleanedText: z.string(),
  normalizedMarkdown: z.string(),
  entities: z.array(z.object({ name: z.string(), type: z.string() })),
  tokens: z.array(z.string()),
  chunks: z.array(z.object({ heading: z.string(), level: z.number(), content: z.string(), wordCount: z.number() })),
  processedAt: z.number(),
});
export type ProcessedKnowledge = z.infer<typeof ProcessedKnowledgeSchema>;

export const QualityReportSchema = z.object({
  overall: z.number().min(0).max(1),
  dimensions: z.object({
    accuracy: z.number().min(0).max(1),
    completeness: z.number().min(0).max(1),
    consistency: z.number().min(0).max(1),
  }),
  issues: z.array(z.object({ severity: z.enum(["low","medium","high"]), message: z.string() })),
  verificationVerdict: z.enum(["pass", "fail", "uncertain"]),
  conformalPValue: z.number().optional(),
  assessedAt: z.number(),
});
export type QualityReport = z.infer<typeof QualityReportSchema>;
```

### Task 3.2 — 预处理器

**新建**: `src/knowledge/preprocessor.ts`

```typescript
export class KnowledgePreprocessor {
  constructor(opts?: { extractEntities?: boolean; chunkSize?: number; language?: string }) {}
  async process(input: KnowledgeInput): Promise<ProcessedKnowledge>;
}
```

功能:
- `cleanText`: 去 HTML 残留、零宽字符（`\u200b-\u200f`）、控制字符
- `htmlToMarkdown`: 复用 [data-pipeline.ts:24-35](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L24) `DEFAULT_NOISE_PATTERNS` 模式（**复制正则数组为独立常量**，因原 `DEFAULT_NOISE_RE` 是模块私有非导出）
- `normalizeMarkdown`: 标题层级归一化（连续 `#` 去重）、列表符号统一（`-`/`*`/`+` → `-`）
- `extractEntities`: 规则 + 词表（人名/组织/技术名正则），不引入 NLP 库
- `tokenize`: 中英文混合分词（**自行实现**，复制 [hallucination-detector.ts:192](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L192) `tokenize` 的正则与停用词表，因原函数非导出）
- `chunk`: 复制 [data-pipeline.ts:717](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L717) `chunkByHeadings` 逻辑为独立工具（原方法 private）

### Task 3.3 — 质量评估器

**新建**: `src/knowledge/quality-assessor.ts`

```typescript
import type { FactEntry, CalibrationPair } from "../memory/hallucination-detector.js";

export class QualityAssessor {
  constructor(opts?: { factBase?: FactEntry[]; calibrationSet?: CalibrationPair[]; strictMode?: boolean }) {}
  async assess(processed: ProcessedKnowledge): Promise<QualityReport>;
}
```

| 维度 | 计算 |
|------|------|
| `accuracy` | 每个 chunk 调 `ConformalHallucinationDetector` 校验（**实施前 Read 确认 verify 方法名**），取最小 confidence；`isHallucination=true` 记 issue(high) |
| `completeness` | 字段填充率：`(有author + 有publishDate + tags.length>0 + chunks.length>=3) / 4` |
| `consistency` | chunks 两两 Jaccard 相似度，> 0.7 但检测到否定矛盾（规则：一个 chunk 含"是/正确/true"、对应 chunk 含"不是/错误/false"且其余词重叠）则降分 |

`verificationVerdict`: `accuracy < 0.4 → "fail"`；`0.4-0.7 → "uncertain"`；`> 0.7 → "pass"`。`strictMode` 时任何 high issue → `"fail"`。

`conformalPValue`: 取 detector 返回的 `HallucinationVerdict.pValue`（[line 83](file:///d:/openclaw-fusion/src/memory/hallucination-detector.ts#L83)）。

### Task 3.4 — 接入 knowledge/pipeline.ts

**修改**: [src/knowledge/pipeline.ts](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts)（手术式）

**集成点**（已读全文确认）: 在 [line 164](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L164) `structureWithGLM()` 返回 `structured` 后、写 JSONL（[line 171](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L171)）前，插入:
```typescript
import { KnowledgePreprocessor } from "./preprocessor.js";
import { QualityAssessor } from "./quality-assessor.js";

const preprocessor = new KnowledgePreprocessor({ extractEntities: true });
const assessor = new QualityAssessor({ strictMode: false });
const input: KnowledgeInput = {
  source: { url: pdfUrl, domain: "books", fetchedAt: Date.now(), rawFormat: "pdf" },
  content: { title: structured.title, rawText: final.result.markdown, markdown: final.result.markdown, language: "unknown" },
  metadata: { tags: structured.keywords },
};
const processed = await preprocessor.process(input);
const report = await assessor.assess(processed);
if (report.verificationVerdict === "fail") {
  logger.warn(`[Pipeline] Quality check failed for ${book.title}, skipping vault write`);
  continue;  // 不写入 vault
}
appendFileSync(jsonlPath, JSON.stringify({ processed, report }) + "\n");
```

**process.env 迁移**（v2 修正: pipeline.ts 内仅 1 处）:
- [line 39](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L39) `process.env.ZHIPU_API_KEY` → `readString("ZHIPU_API_KEY")`（顶部 import `readString` from `../utils/env.js`）
- **额外扫描** knowledge/* 其他文件（collector.ts / searcher.ts / store.ts / auto-updater.ts）与 routes/models.ts 的 process.env 直接读取，在本任务范围内一并迁移（用 `grep -n "process\.env" src/knowledge/ src/routes/models.ts` 定位全部）

### Phase 3 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | types.ts 追加 3 schema + 单测 |
| Day 2 | preprocessor.ts cleanText + normalizeMarkdown + 单测 |
| Day 3 | preprocessor.ts entity/tokens/chunks + 单测 |
| Day 4 | quality-assessor.ts 三维评分 + 集成（先读 detector verify API） |
| Day 5 | 接入 pipeline.ts + process.env 迁移 + 集成测试 + commit + push + log |

### Phase 3 评估
**新增测试**: `tests/knowledge-preprocess-quality.test.ts`
| Case | 期望 |
|------|------|
| 输入含 `<script>` 的 rawText | `cleanedText` 不含 `<script>` |
| 中英文混合 | `tokens.length > 0`，含中文词与英文词 |
| chunk 与 factBase 矛盾 | `accuracy < 0.4`，issues 含 high |
| 缺 author/publishDate/tags | `completeness < 0.5` |
| 两 chunk 互相矛盾 | `consistency < 0.6` |
| `verificationVerdict === "fail"` | 不写入 vault |

**Gate**: 10KB markdown 处理 < 200ms；`grep -rn "process\.env" src/knowledge/ src/routes/models.ts` 违规降为 0；`architecture-integrity.test.ts` 不退化

---

## Phase 4（Week 4）— 安全加固完成

### 目标
1. API Key 静态加密（AES-256-GCM）
2. per-user / per-IP 多维限流
3. 沙箱加固（Windows 资源限制）
4. 安全监控（接 HealthChecker + metrics）
5. WebSocket maxClients 配置化

### Task 4.1 — API Key 静态加密

**修改**: [src/utils/api-key-persistence.ts](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts)

```typescript
import { createCipheriv, createDecipheriv, randomBytes, createHash } from "crypto";
import { readString } from "./env.js";

function getMasterKey(): Buffer {
  const raw = readString("AXIOM_ENCRYPTION_KEY");
  if (!raw) throw new Error("AXIOM_ENCRYPTION_KEY not set; refusing to persist plaintext keys");
  return createHash("sha256").update(raw).digest();  // 32 字节
}

function encrypt(plaintext: string): string {
  const key = getMasterKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

function decrypt(payload: string): string {
  if (!payload.startsWith("enc:v1:")) return payload;  // 向后兼容旧明文
  const [, , ivB64, tagB64, encB64] = payload.split(":");
  const key = getMasterKey();
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(encB64, "base64")), decipher.final()]).toString("utf8");
}
```

改动点:
- [saveApiKeyOverride](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts#L58)（line 58）: 写 DB 前 `encrypt(apiKey)`
- [loadApiKeyOverrides](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts#L37)（line 37）: 读后 `decrypt(r.api_key)`
- `initApiKeyOverridesTable`: 若 DB 有旧明文 + `AXIOM_ENCRYPTION_KEY` 已配，**事务中**自动迁移（先 dry-run 输出待迁移数，备份 DB 到 `.tmp/backups/data/agent.db.bak`）
- **降级**: 未配 `AXIOM_ENCRYPTION_KEY` 时 `saveApiKeyOverride` 抛错（fail-closed），`loadApiKeyOverrides` 仍能读旧明文保运行

### Task 4.2 — 多维度限流

**修改**: [src/utils/rate-limiter.ts](file:///d:/openclaw-fusion/src/utils/rate-limiter.ts)（追加 class，不删现有 `RateLimiter` / `apiLimiter`）

```typescript
export interface RateLimitConfig {
  global?: RateLimitRule;
  perIp?: RateLimitRule;
  perUser?: RateLimitRule;  // 基于 x-api-key 哈希
  perPath?: Map<string, RateLimitRule>;
}

export class MultiDimensionLimiter {
  constructor(config: RateLimitConfig) {}
  check(req: Request): { allowed: boolean; headers: Record<string,string>; violated: string[] };
}
```

**修改** [main.ts:472](file:///d:/openclaw-fusion/src/main.ts#L472): 现有 `rateLimitCheck(req)` 改为 `MultiDimensionLimiter`。默认:
- `/chat`: perIp 10/min, perUser 30/min
- `/web-search`: perIp 30/min
- 其他: 全局 100/min

限流触发时 `auditLogger.log({ event: "rate_limit.exceeded", ... })`。

### Task 4.3 — 沙箱加固

**修改**: [src/sandbox/process-sandbox.ts](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts)

**Windows**（当前 [line 28-30](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L28) 完全无资源限制）:
- 监控 `proc.stdout` 累积字节数，超 `maxOutputBytes`（默认 10MB，从 `opts.maxOutputBytes` 或 env `SANDBOX_MAX_OUTPUT_BYTES`）kill
- proc 退出后用 `proc.resourceUsage?.()`（若可用）回填 `resourceUsage.memoryBytes`

**Linux 增强**（当前 [line 35-38](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts#L35) `ulimit -v` + `-t`）:
- 新增 `ulimit -m`（resident）+ `ulimit -f`（文件大小）
- 检测 `unshare` 可用性，可用则 `unshare -n` 包裹命令（网络隔离）

**CPU 限制**: 区分"超时"与"CPU 超限"两种 exitCode 语义（超时 exitCode = 124，CPU exitCode = 137）。

接入 `auditLogger.log({ event: "sandbox.execute", resource: command, outcome: ... })`。

### Task 4.4 — 安全监控

**新建**: `src/utils/security-monitor.ts`

```typescript
import type { AuditEvent } from "./audit-logger.js";

export interface SecurityAlert {
  type: "auth_failure_burst" | "rate_limit_burst" | "sandbox_failure_burst" | "ws_flood";
  severity: "low" | "medium" | "high";
  actor: string; count: number; windowMs: number; triggeredAt: number;
}

export class SecurityMonitor {
  constructor(thresholds = {
    authFailureBurst: { count: 5, windowMs: 60_000 },
    rateLimitBurst: { count: 10, windowMs: 60_000 },
    sandboxFailureBurst: { count: 3, windowMs: 60_000 },
  }) {}
  record(event: AuditEvent, actor: string): SecurityAlert | null;
  getActiveAlerts(): SecurityAlert[];
}
export const securityMonitor: SecurityMonitor;
```

**注册 metrics**（v2 修正）: `metrics.register({ name: "security_alert_total", help: "Security alerts by type and severity", type: "counter" })`。

**接入点**:
- `route-auth.ts`（Phase 1）: 每次 auth failure 调 `securityMonitor.record("auth.failure", actor)`
- `audit-logger.ts`（Phase 1）: 所有事件旁路到 securityMonitor
- [health-checker.ts](file:///d:/openclaw-fusion/src/core/health-checker.ts): 新增 `checkSecurity()` 项，加入 [line 58](file:///d:/openclaw-fusion/src/core/health-checker.ts#L58) `Promise.all` 数组，读 `securityMonitor.getActiveAlerts()` 加入 `SystemReport`；[line 309](file:///d:/openclaw-fusion/src/core/health-checker.ts#L309) 已有 "安全" recommendation stub 可接

### Task 4.5 — WebSocket maxClients 配置化

**修改**: [src/utils/websocket.ts](file:///d:/openclaw-fusion/src/utils/websocket.ts)（1 行）

```typescript
import { readString } from "./env.js";
// 原 [line 29]: const MAX_WS_CLIENTS = 100;
const MAX_WS_CLIENTS = parseInt(readString("WS_MAX_CLIENTS", "100"), 10);
```

`onOpen`（[line 37](file:///d:/openclaw-fusion/src/utils/websocket.ts#L37)）拒绝时 `auditLogger.log({ event: "ws_flood", ... })`。

### Phase 4 评估
**新增测试**: `tests/security-hardening.test.ts`
| Case | 期望 |
|------|------|
| 配 `AXIOM_ENCRYPTION_KEY` 后 saveApiKeyOverride | DB `api_key` 字段以 `enc:v1:` 开头 |
| 无 `AXIOM_ENCRYPTION_KEY` 时 saveApiKeyOverride | 抛错，不写入 |
| 旧明文 + 配 key 后 loadApiKeyOverrides | 返回正确明文（自动 decrypt） |
| `/chat` 同 IP 第 11 次请求 | 429 |
| 同 user 第 31 次请求 | 429 |
| sandbox 超时 | exitCode 非 0，error 含 "timeout" |
| sandbox stdout 超 10MB | proc 被 kill |
| 5 次 auth.failure 同 IP | securityMonitor 返回 high severity alert |
| `WS_MAX_CLIENTS=2` 时第 3 个连接 | close(1013) |

**Gate**: 加密后 DB grep 不到明文 key；HealthChecker `/health` 响应含 `security` 检查项；全量 `bun test` 不退化

### Phase 4 时间节点
| 时间 | 任务 |
|------|------|
| Day 1 | api-key-persistence.ts 加密 + migration + 单测 |
| Day 2 | rate-limiter.ts MultiDimensionLimiter + main.ts 接入 + 单测 |
| Day 3 | process-sandbox.ts Windows 加固 + resourceUsage + 单测 |
| Day 4 | security-monitor.ts + HealthChecker 接入 + WebSocket 配置化 |
| Day 5 | security-hardening.test.ts 全套 + 全量回归 + commit + push + log |

---

## 全局评估仪表板

| 维度 | 指标 | 基线 | 目标 | 测量方法 |
|------|------|------|------|---------|
| 安全 | P0 漏洞 | 1（Host 头绕过） | 0 | `tests/security-islocal.test.ts` |
| 安全 | 审计覆盖率 | 0% | 100%（vault/sandbox/plugin/auth） | grep `auditLogger.log` |
| 安全 | 日志密钥泄漏 | 可能含 token | 0 处明文 | `tests/logger-redact.test.ts` |
| 安全 | API Key 静态加密 | 0% | 100%（配 key 后） | `tests/security-hardening.test.ts` |
| 安全 | 限流维度 | 1（全局） | 3（全局+IP+User） | MultiDimensionLimiter |
| 检索 | 多维度打分 | 0 维度 | 4 维度 | `tests/crawl-filter-score-extract.test.ts` |
| 检索 | 结构化抽取 | 无统一 schema | zod 强制 | DataExtractor |
| 知识 | 模型就绪 schema | 0 | 3 个 | `src/knowledge/types.ts` |
| 知识 | 预处理流程 | 无 | 5 步 | `tests/knowledge-preprocess-quality.test.ts` |
| 知识 | 质量评估 | 单一 score | 3 维度 + issues | QualityAssessor |
| 知识 | process.env 违规 | ≥1 | 0（knowledge + models.ts） | grep |
| 架构 | 测试通过率 | 现状 | 不退化 | `bun test` 全量 |
| 合规 | AGENTS.md | — | 100% 提交有 log+备份+push | operations-log 条目数 = 提交数 |

## 风险与缓解

| 风险 | 等级 | 缓解 |
|------|------|------|
| `server.requestIP(req)` 反代后返回代理 IP | 中 | 文档化：`AXIOM_TRUST_PROXY=true` 时信任 `x-real-ip`，nginx 需配 `proxy_set_header x-real-ip $remote_addr` |
| Phase 2 `ConformalHallucinationDetector` verify 方法名不确定 | 中 | 实施前 Read hallucination-detector.ts line 340-450 确认；若 API 不匹配则用 `computeMaxEvidenceScore` + 自算 p-value |
| Phase 2 LLM 抽取失败阻塞 pipeline | 中 | data-extractor.ts 强制降级路径，默认 `extract: false` 显式开启 |
| Phase 3 `tokenize`/`IDFCache` 是私有 | 低 | 复制等价实现到新文件（符合 Rule 1，不导出原私有） |
| Phase 4 加密 migration 改坏旧明文 | 高 | migration 在事务中；先 dry-run 输出待迁移数；备份 DB 到 `.tmp/backups/` |
| 沙箱 Windows 加固不彻底（无原生 ulimit） | 中 | 文档化限制；推荐生产用 Docker 沙箱；Windows 仅 timeout + output size |
| 改动后 architecture-integrity 退化 | 高 | 每 Phase 结束前必跑；新文件遵循 4 层架构 |
| Phase 1 改 main.ts 与其他 Task 冲突 | 中 | Phase 1 的 4 Task 严格串行；Phase 2-4 可适度并行 |

## 验证（端到端）

每阶段完成后执行:
```bash
# 1. 类型检查
bunx tsc --noEmit

# 2. 架构约束测试（不退化）
bun test tests/architecture-integrity.test.ts

# 3. 本阶段新增测试
bun test tests/security-islocal.test.ts              # Phase 1
bun test tests/crawl-filter-score-extract.test.ts    # Phase 2
bun test tests/knowledge-preprocess-quality.test.ts  # Phase 3
bun test tests/security-hardening.test.ts            # Phase 4

# 4. 全量回归
bun test tests/

# 5. AGENTS.md 合规检查
# - 备份已删：ls .tmp/backups/ 应为空
# - operations-log 已更新：tail docs/operations-log.md
# - 已 push internal211：git log --oneline internal211/main..HEAD 应为空
```

**手工验证 Phase 1 P0 修复**:
```bash
# 启动服务后，从另一台机器（非 localhost）攻击：
curl -H "Host: localhost" http://<lan-ip>:18789/chat -X POST -d '{"messages":[]}'
# 期望: 401 Unauthorized（修复前会返回 200）
```

## 假设与决策（Assumptions & Decisions）

1. **`isLocalRequest` 独立模块化**：放到 `src/utils/is-local.ts` 而非内联 main.ts，理由是可测试性。这是符合 Rule 1 的最小必要改动。
2. **`tokenize`/`IDFCache`/`chunkByHeadings` 复制不导出**：原模块这些是 private/非导出，复制等价实现到新文件比修改原模块公开范围更小，符合 Rule 1。
3. **`calculateQualityScore` 扩展不重建**：增加可选 `scoreHook` 回调参数，不提供时行为不变。
4. **`searchScored` 默认不 score/extract**：保持 `searchMulti`/`crawlSearchResults` 向后兼容，新能力显式开启。
5. **`AXIOM_ENCRYPTION_KEY` 未配时 fail-closed（写）但容错（读）**：写入抛错防止明文落盘；读取兼容旧明文保证服务可启动。
6. **Phase 严格串行**：Phase 1 内 4 Task 串行（都涉及 main.ts 或共享新模块）；Phase 2/3/4 之间也串行（Phase 4 依赖 Phase 1 的 auditLogger）。
7. **实施前必读清单**（避免假设函数名/路径）：
   - Phase 1 Task 1.4: Read `vault.ts` / `sandbox.ts` / `plugin-routes.ts` 全文确认 handler 函数名
   - Phase 2 Task 2.2: Read `hallucination-detector.ts` line 340-450 确认 verify 公开方法名
   - Phase 2 Task 2.2: Read `conformal-retriever.ts` 确认 ConformalRetriever 公开 API
   - Phase 2 Task 2.3: `grep -rn "export class LLMClient" src/` 确认导入路径
   - Phase 3 Task 3.4: `grep -rn "process\.env" src/knowledge/ src/routes/models.ts` 定位全部违规

## 关键文件清单

| 文件 | 阶段 | 改动类型 |
|------|------|---------|
| `src/utils/is-local.ts` | P1 | 新建 |
| `src/main.ts` | P1+P4 | 修改（P0 修复 + 限流接入） |
| `src/utils/audit-logger.ts` | P1 | 新建 |
| `src/utils/logger.ts` | P1 | 修改（脱敏） |
| `src/utils/route-auth.ts` | P1 | 新建 |
| `src/routes/api-keys.ts` | P1 | 修改（复用 requireAuthToken） |
| `src/routes/vault.ts` | P1 | 修改（加守卫） |
| `src/routes/sandbox.ts` | P1 | 修改（加守卫） |
| `src/routes/plugin-routes.ts` | P1 | 修改（加守卫） |
| `src/crawl/result-filter.ts` | P2 | 新建 |
| `src/crawl/result-scorer.ts` | P2 | 新建 |
| `src/crawl/data-extractor.ts` | P2 | 新建 |
| `src/crawl/data-pipeline.ts` | P2 | 修改（searchScored + 扩展 calculateQualityScore） |
| `src/knowledge/types.ts` | P3 | 修改（追加 3 schema） |
| `src/knowledge/preprocessor.ts` | P3 | 新建 |
| `src/knowledge/quality-assessor.ts` | P3 | 新建 |
| `src/knowledge/pipeline.ts` | P3 | 修改（接入 + process.env 迁移） |
| `src/utils/api-key-persistence.ts` | P4 | 修改（加密） |
| `src/utils/rate-limiter.ts` | P4 | 修改（MultiDimensionLimiter） |
| `src/sandbox/process-sandbox.ts` | P4 | 修改（Windows 加固） |
| `src/utils/security-monitor.ts` | P4 | 新建 |
| `src/utils/websocket.ts` | P4 | 修改（1 行配置化） |
| `src/core/health-checker.ts` | P4 | 修改（checkSecurity） |
| `tests/security-islocal.test.ts` | P1 | 新建 |
| `tests/audit-logger.test.ts` | P1 | 新建 |
| `tests/logger-redact.test.ts` | P1 | 新建 |
| `tests/route-auth.test.ts` | P1 | 新建 |
| `tests/crawl-filter-score-extract.test.ts` | P2 | 新建 |
| `tests/knowledge-preprocess-quality.test.ts` | P3 | 新建 |
| `tests/security-hardening.test.ts` | P4 |