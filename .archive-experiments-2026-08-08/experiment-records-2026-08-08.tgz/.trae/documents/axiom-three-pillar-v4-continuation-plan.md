# Axiom Runtime v4.0 — 三支柱优化续接执行计划（v4）

> **本计划是 v3 计划的续接版**。v3 计划文件 `.trae/documents/axiom-three-pillar-v3-execution-plan.md`（69199 bytes, 1488 行）仍存在且包含完整的 4 阶段 17 Task 设计、代码片段与 file:line 引用。本 v4 文件仅记录：
>
> 1. 当前实际状态（哪些已完成、哪些待办）
> 2. 剩余 Task 的精确执行顺序与验证标准
> 3. 对 v3 计划的偏差修正
>
> **执行时遇到具体技术细节，查阅 v3 计划对应 Task 段落**。

***

## 约束（AGENTS.md 五条强约束）

1. **最小化施工**：只做任务要求的最小改动；不顺手重构、不清理无关代码
2. **改代码前先备份**：`.tmp/backups/<相对路径>` → 读全文 → 修改 → 验证 → 删备份
3. **提交到** **`internal211`** **远端**：`ssh://data@192.168.2.11/home/data/openclaw-fusion.git`，只暂存本任务相关文件
4. **删除 = 归档**：移到 `archive/` + 写 `archive/ARCHIVE-LOG.md`
5. **操作留痕**：`docs/operations-log.md` 每提交一次记录一次

***

## 当前实际状态（2026-07-17 经直接读码校准）

### ✅ 已完成

| 项                   | 状态                             | 证据                                                                                                                                                                                                   |
| ------------------- | ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| P0 认证绕过修复           | ✅ commit `b26821b` + `ad17ea6` | [auth-check.ts](file:///d:/openclaw-fusion/src/utils/auth-check.ts) 60 行，含 `isLocalAddress()` 使用 socket 对端地址                                                                                         |
| P0 回归测试             | ✅                              | [tests/auth-check.test.ts](file:///d:/openclaw-fusion/tests/auth-check.test.ts)                                                                                                                      |
| process.env 迁移      | ✅                              | `rg "process\.env" src/knowledge/ src/routes/models.ts` = 0 匹配；[pipeline.ts:40](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts#L40) 已用 `readString("ZHIPU_API_KEY")`                           |
| Task 1.0 清理备份       | ✅                              | `.tmp/backups/src/main.ts.bak` 已删除                                                                                                                                                                   |
| Task 1.2 审计日志模块文件创建 | ✅ **未提交**                      | [src/utils/audit-logger.ts](file:///d:/openclaw-fusion/src/utils/audit-logger.ts) 218 行；[tests/audit-logger.test.ts](file:///d:/openclaw-fusion/tests/audit-logger.test.ts) 11 个测试用例；git status `??` |

### ⬜ 待办（按执行顺序）

**Phase 1 收尾（3 项）**:

* Task 1.2-verify: 运行 `bun test tests/audit-logger.test.ts` + `bunx tsc --noEmit` 验证

* Task 1.3: logger.ts serialize() 密钥脱敏 + `tests/logger-redact.test.ts`

* Task 1.4: 新建 `src/utils/route-auth.ts` + 接入 4 路由 + `tests/route-auth.test.ts`

* Phase 1 收尾: commit + push internal211 + operations-log

**Phase 2（检索优化，4 个 Task）**:

* Task 2.1: `src/crawl/result-filter.ts`

* Task 2.2: `src/crawl/result-scorer.ts` + 集成 ConformalHallucinationDetector

* Task 2.3: `src/crawl/data-extractor.ts` + zod schema

* Task 2.4: 接入 `src/crawl/data-pipeline.ts`

**Phase 3（知识整理，4 个 Task）**:

* Task 3.1: `src/knowledge/types.ts` 追加 3 个 zod schema

* Task 3.2: `src/knowledge/preprocessor.ts`

* Task 3.3: `src/knowledge/quality-assessor.ts`

* Task 3.4: 接入 `src/knowledge/pipeline.ts`

**Phase 4（安全加固，5 个 Task）**:

* Task 4.1: `src/utils/api-key-persistence.ts` AES-256-GCM 加密

* Task 4.2: `src/utils/rate-limiter.ts` MultiDimensionLimiter

* Task 4.3: `src/sandbox/process-sandbox.ts` Windows 加固

* Task 4.4: `src/utils/security-monitor.ts` + health-checker checkSecurity

* Task 4.5: `src/utils/websocket.ts` 配置化

***

## v3 计划偏差修正（基于本次读码）

1. **v3 Task 1.3 描述了 logger.ts 已有** **`redactContext`** **方法**：实际**没有**。当前 [logger.ts:212-227](file:///d:/openclaw-fusion/src/utils/logger.ts#L212) `serialize()` 仍然原样输出 context：`obj.context = entry.context`。需新增 `redactContext` 私有方法并修改 `serialize()` 调用它。
2. **v3 Task 1.4 中** **`route-auth.ts`** **的** **`auditSuccess`** **第二参数类型**：v3 列出 10 种 event，与 audit-logger.ts 实际 `AuditEvent` 类型一致，无需修改。
3. **v3 Task 4.4 描述了** **`security_alert_total`** **在 security-monitor 中注册**：实际已由 [audit-logger.ts:28-32](file:///d:/openclaw-fusion/src/utils/audit-logger.ts#L28) 提前注册，security-monitor.ts 直接 `metrics.increment("security_alert_total", ...)` 即可。
4. **vault.ts 实际有 5 个 POST 写入端点**：handleVaultWrite(L91), handleVaultAtomic(L103), handleVaultCodeIndex(L115), handleVaultReload(L124), handleVaultDistill(L143)。v3 计划已正确列出。
5. **plugin-adapter.ts 实际有 5 个敏感操作**：install(L48), uninstall(L70), enable(L75), disable(L80), configure(L85)。v3 计划已正确列出。

***

## Phase 1 — 收尾执行（Week 1）

### Task 1.2-verify — 验证审计日志模块

**操作**:

1. `cd D:\openclaw-fusion; bun test tests/audit-logger.test.ts` — 期望 11 个测试全部 pass
2. `cd D:\openclaw-fusion; bunx tsc --noEmit` — 期望无新增类型错误
3. 如有失败：按 AGENTS Rule 2 修复（备份 → 读 → 改 → 验 → 删备份）

**验证标准**:

* 11 个测试全部 pass

* tsc 无新增错误（基线：4 错误，参见 commit `b00e98f`）

* 不引入新 regression

### Task 1.3 — Logger 密钥脱敏

**目标**: 防止日志文件泄漏 API Key、Bearer Token 等敏感值。

**修改文件**: [src/utils/logger.ts](file:///d:/openclaw-fusion/src/utils/logger.ts)（251 行）

**AGENTS Rule 2 流程**:

1. 备份：`cp src/utils/logger.ts .tmp/backups/src/utils/logger.ts.bak`
2. 读全文（已读 251 行）
3. 修改 3 处：

   * **改动 1**（顶部 import 段，line 6 后）：

     ```typescript
     import { sanitizeRequestBody } from "./security.js";
     ```

   * **改动 2**（class Logger 内，紧邻 `serialize` 之前新增私有方法）：

     ```typescript
     /** 敏感值正则：捕获常见密钥格式（key-based 脱敏由 sanitizeRequestBody 处理，此处补 value-based） */
     private static readonly SECRET_VALUE_RE =
       /(sk-[A-Za-z0-9]{8,}|Bearer\s+[A-Za-z0-9._-]+|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{36}|glpat-[A-Za-z0-9_-]{20}|xoxb-[0-9A-Za-z-]+)/g;

     private redactContext(ctx: Record<string, unknown>): Record<string, unknown> {
       const cleaned = sanitizeRequestBody(ctx) as Record<string, unknown>;
       for (const [k, v] of Object.entries(cleaned)) {
         if (typeof v === "string") {
           cleaned[k] = v.replace(Logger.SECRET_VALUE_RE, "[REDACTED]");
         }
       }
       return cleaned;
     }
     ```

   * **改动 3**（`serialize()` 方法，[line 212-227](file:///d:/openclaw-fusion/src/utils/logger.ts#L212)）：

     ```typescript
     private serialize(entry: LogEntry): Record<string, unknown> {
       const obj: Record<string, unknown> = {
         timestamp: entry.timestamp,
         level: entry.level,
         message: entry.message,
       };
       if (entry.context && Object.keys(entry.context).length) {
         obj.context = this.redactContext(entry.context);  // ← 改动
       }
       if (entry.error) {
         const msg = entry.error.message?.replace(Logger.SECRET_VALUE_RE, "[REDACTED]") ?? "";
         const stack = entry.error.stack?.replace(Logger.SECRET_VALUE_RE, "[REDACTED]");
         obj.error = { name: entry.error.name, message: msg, stack };
       }
       return obj;
     }
     ```
4. 验证：运行 `bun test tests/logger-redact.test.ts`
5. 删备份：`rm .tmp/backups/src/utils/logger.ts.bak`

**新增测试**: `tests/logger-redact.test.ts`

* 用例 1: `logger.info("x", { api_key: "sk-abcd1234efgh5678" })` → 文件输出含 `[REDACTED]`，不含原始 key

* 用例 2: `logger.info("x", { token: "Bearer abc123" })` → `[REDACTED]`

* 用例 3: `logger.info("x", { normal: "hello", nested: { password: "pw" } })` → `hello` 保留，`nested.password` 为 `[REDACTED]`

* 用例 4: `logger.info("x", { url: "https://api.com?token=sk-abcd1234efgh5678" })` → URL 中密钥被替换为 `[REDACTED]`

* 用例 5: `logger.info("x", { count: 42, list: [1, 2] })` → 非字符串值不受影响

* 测试策略：构造临时 `new Logger({ outputs: [{type:"file", path: tmpPath}], format: "json" })`，写后读文件验证

### Task 1.4 — per-route 二次认证守卫

**目标**: vault/sandbox/plugin 三个路由模块的敏感 POST 端点要求二次认证 + 审计留痕；api-keys.ts 改用通用守卫。

**新建文件**: `src/utils/route-auth.ts`

**完整代码**（v3 计划已给出，照搬）：

```typescript
import type { RouteContext } from "../routes/types.js";
import { readString } from "./env.js";
import { auditLogger } from "./audit-logger.js";

/**
 * 敏感端点二次认证守卫。
 * - 未配置 AXIOM_AUTH_TOKEN → 503（fail-closed，与 api-keys.ts:38 一致）
 * - token 不匹配 → 401 + 审计日志
 * - 通过 → 返回 null，调用方继续
 */
export function requireAuthToken(ctx: RouteContext): Response | null {
  const token = readString("AXIOM_AUTH_TOKEN");
  const actor = ctx.req.headers.get("x-real-ip") || "unknown";
  if (!token) {
    auditLogger.log({
      event: "auth.failure", actor, outcome: "denied",
      reason: "AXIOM_AUTH_TOKEN not configured", resource: ctx.url.pathname,
    });
    return ctx.jsonResponse({ error: "Server auth not configured (AXIOM_AUTH_TOKEN missing)" }, 503, ctx.baseHeaders);
  }
  const provided = ctx.req.headers.get("x-api-key") ||
    ctx.req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (provided !== token) {
    auditLogger.log({
      event: "auth.failure", actor, outcome: "denied",
      reason: "invalid or missing token", resource: ctx.url.pathname,
    });
    return ctx.jsonResponse({ error: "Unauthorized" }, 401, ctx.baseHeaders);
  }
  return null;
}

/** 成功审计辅助：敏感操作完成后调用 */
export function auditSuccess(
  ctx: RouteContext,
  event: "vault.write" | "sandbox.execute" | "plugin.install" | "plugin.uninstall" |
        "plugin.enable" | "plugin.disable" | "plugin.configure" | "apikey.set" | "apikey.delete" | "apikey.test",
  resource?: string,
  metadata?: Record<string, unknown>,
): void {
  auditLogger.log({
    event, actor: ctx.req.headers.get("x-real-ip") || "unknown",
    outcome: "success", resource: resource ?? ctx.url.pathname, metadata,
  });
}
```

**修改文件 1**: [src/routes/api-keys.ts](file:///d:/openclaw-fusion/src/routes/api-keys.ts)

* 删除本地 `requireAuth` 函数（line 36-55）

* 顶部新增 import: `import { requireAuthToken, auditSuccess } from "../utils/route-auth.js";`

* line 72: `requireAuth(ctx)` → `requireAuthToken(ctx)`

* POST 成功后（line 122 后）加 `auditSuccess(ctx, "apikey.set", provider)`

* DELETE 成功后（line 159 后）加 `auditSuccess(ctx, "apikey.delete", provider)`

* test 成功后（line 195 后）加 `auditSuccess(ctx, "apikey.test", provider, { ok: result.ok })`

**修改文件 2**: [src/routes/vault.ts](file:///d:/openclaw-fusion/src/routes/vault.ts) — 5 个 POST handler 加守卫
每个 handler 在路径匹配后、业务逻辑前加：

```typescript
const authErr = requireAuthToken(ctx);
if (authErr) return authErr;
```

位置（精确行号）:

* `handleVaultWrite` line 91 后

* `handleVaultAtomic` line 103 后

* `handleVaultCodeIndex` line 115 后

* `handleVaultReload` line 124 后

* `handleVaultDistill` line 143 后

* 各 handler 写入成功后调用 `auditSuccess(ctx, "vault.write", notePath)` 等

**修改文件 3**: [src/routes/sandbox.ts](file:///d:/openclaw-fusion/src/routes/sandbox.ts)

* `handleSandboxExecute` line 5 后（路径匹配后）加 `requireAuthToken` 守卫

* 执行成功后加 `auditSuccess(ctx, "sandbox.execute", body.command)`

**修改文件 4**: [src/routes/plugin-adapter.ts](file:///d:/openclaw-fusion/src/routes/plugin-adapter.ts)

* 在 `handlePluginRoutes` 内 5 个敏感分支（install L48, uninstall L70, enable L75, disable L80, configure L85）匹配后、调 `pluginRoutes.xxx` 前加 `requireAuthToken(ctx)` 守卫

* 各分支成功后加对应 `auditSuccess(ctx, "plugin.install"/..., id)`

**新增测试**: `tests/route-auth.test.ts`

* 用例 1: 未配置 AXIOM\_AUTH\_TOKEN → 503 + auditLogger 含 `auth.failure`

* 用例 2: 错误 token → 401 + auditLogger 含 `auth.failure`

* 用例 3: 正确 token → 返回 null（无 Response）

* 用例 4: auditSuccess 写入审计日志 event 字段正确

* 测试策略：mock RouteContext（最小化 mock：url, req, jsonResponse, baseHeaders）+ 临时设/还原 `process.env.AXIOM_AUTH_TOKEN`

### Phase 1 收尾

1. 运行全量回归：`cd D:\openclaw-fusion; bun test`

   * 期望：基线 1042 pass，新增 ≥14 个测试（11 audit-logger + 5 logger-redact + 4 route-auth），无新增 regression
2. 运行 `bunx tsc --noEmit`（期望无新增类型错误）
3. `docs/operations-log.md` 追加 Phase 1 完成记录
4. `git add` 仅 Phase 1 相关文件（**不**包含既有 16 个未提交 modified 文件）:

   * `src/utils/audit-logger.ts`

   * `src/utils/route-auth.ts`

   * `src/utils/logger.ts`

   * `src/routes/api-keys.ts`（守卫接入）

   * `src/routes/vault.ts`

   * `src/routes/sandbox.ts`

   * `src/routes/plugin-adapter.ts`

   * `tests/audit-logger.test.ts`

   * `tests/logger-redact.test.ts`

   * `tests/route-auth.test.ts`

   * `docs/operations-log.md`
5. `git commit -m "feat(security): Phase 1 — 审计日志 + Logger 脱敏 + per-route 二次认证"`
6. `git push internal211 <当前分支>`

**注意**：api-keys.ts 已在 git status `M`（modified）状态，是因为前序会话可能已动过；本次 Task 1.4 修改会叠加。提交时只 add 该文件。

***

## Phase 2 — Web 检索优化（Week 2）

详细设计见 v3 计划对应段落。摘要：

### Task 2.1 — 结果过滤器 `src/crawl/result-filter.ts`

* 黑名单：垃圾站点（赌博/色情/恶意软件）、低质 SEO 内容农场

* 启发式过滤：标题过短（<10 字符）、纯广告 snippet、重复结果（按 link 去重）

* API: `filterResults(results: SearchEngineResult[]): SearchEngineResult[]`

* 单测：`tests/crawl-filter-score-extract.test.ts` 第一部分

### Task 2.2 — 多维度打分器 `src/crawl/result-scorer.ts`

* 4 维度评分（各 0-1，加权 0-100）：

  * sourceCredibility（TLD 加权：.edu/.gov 高，.xyz/.top 低）

  * contentRelevance（与 query 的 Jaccard/BM25 相似度，复用 hallucination-detector 的 tokenize 思路）

  * timeliness（publishDate 距今天数，越近分越高）

  * factualAccuracy（调 `ConformalHallucinationDetector.verify(statement=snippet, context=query)` 取 `1 - pValue`）

* API: `scoreResult(result, query, factBase?): ScoreBreakdown`

* 集成点：data-pipeline.ts `crawlSearchResults`（line 857-868）调 `searchMulti` 后、`crawlStructured` 前过滤+打分

* 单测：`tests/crawl-filter-score-extract.test.ts` 第二部分

### Task 2.3 — 结构化数据抽取器 `src/crawl/data-extractor.ts`

* zod schema 定义：`ExtractedFactSchema`（subject/predicate/object/source/confidence）

* 从 markdown 内容抽取三元组（基于正则 + 启发式，无 LLM 依赖）

* 降级策略：抽取失败返回空数组，不阻塞流程

* API: `extractFacts(markdown: string, source: string): ExtractedFact[]`

* 单测：`tests/crawl-filter-score-extract.test.ts` 第三部分

### Task 2.4 — 接入 data-pipeline.ts

* 修改 `crawlSearchResults`（[line 853](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L853)）：

  ```typescript
  const results = await this.searchMulti(query, {...});
  const filtered = filterResults(results);              // Task 2.1
  const scored = filtered.map(r => ({ ...r, score: scoreResult(r, query) }))  // Task 2.2
                       .sort((a, b) => b.score.total - a.score.total);
  const targets = scored.slice(0, max);
  // ... crawlStructured ...
  ```

* 扩展 `calculateQualityScore`（[line 814](file:///d:/openclaw-fusion/src/crawl/data-pipeline.ts#L814)）：增加可选 `scoreHook?: (result, wordCount) => number` 参数，默认走原逻辑

* `saveCrawlResult` 中追加 `extractFacts(result.markdown, result.url)` 写入结构化数据字段

### Phase 2 Gate

* 3 个新模块文件存在 + tsc 通过

* `bun test tests/crawl-filter-score-extract.test.ts` 全部 pass

* 全量回归无新增 regression

* commit + push + operations-log

***

## Phase 3 — 知识整理（Week 3）

详细设计见 v3 计划对应段落。摘要：

### Task 3.1 — types.ts 追加 zod schema

* 修改 [src/knowledge/types.ts](file:///d:/openclaw-fusion/src/knowledge/types.ts)（41 行）

* 新增 3 个 zod schema（package.json 已有 zod ^3.22.0）：

  * `KnowledgeSourceSchema` — 验证 KnowledgeSource interface

  * `DictionaryEntrySchema` — 验证 DictionaryEntry

  * `StructuredKnowledgeSchema` — 验证 GLM `structureWithGLM` 返回值（pipeline.ts:29-37 的 StructureResult）

* 保留原有 interface 不变（schema 是验证层，不替换类型）

### Task 3.2 — 预处理器 `src/knowledge/preprocessor.ts`

* 输入：rawMarkdown string

* 输出：`{ cleanedMarkdown, extractedMetadata, tokenCount }`

* 流程：

  1. 清洗：去除 HTML 残留、规范化空白、去除超长行
  2. 标准化：统一标题层级（# → ##）、统一代码块标记
  3. 特征提取：抽出 metadata（title/author/date，复用 crawlStructured 已有逻辑思路）
  4. tokenCount：估算 token 数（粗略 4 字符/token）

* API: `preprocessKnowledge(rawMarkdown: string): PreprocessedKnowledge`

* 单测：`tests/knowledge-preprocess-quality.test.ts` 第一部分

### Task 3.3 — 质量评估器 `src/knowledge/quality-assessor.ts`

* 三维评分（各 0-1，加权 0-1 综合）：

  * accuracy：与既有事实库一致性（调 ConformalHallucinationDetector.verify 取 `1 - pValue` 均值）

  * completeness：必填字段覆盖率（title/summary/keywords/sections/entities 各占权重）

  * consistency：内部一致性（keywords 出现在 sections 中、entities 在 sections 中被提及）

* API: `assessQuality(structured: StructureResult, factBase?: FactEntry[]): QualityReport`

* 单测：`tests/knowledge-preprocess-quality.test.ts` 第二部分

### Task 3.4 — 接入 knowledge/pipeline.ts

* 修改 [src/knowledge/pipeline.ts](file:///d:/openclaw-fusion/src/knowledge/pipeline.ts) line 165-172（GLM 集成点）：

  ```typescript
  const structured = await structureWithGLM(final.result.markdown);
  if (structured) {
    // 新增：zod 校验
    const parsed = StructuredKnowledgeSchema.safeParse(structured);
    if (!parsed.success) {
      logger.warn("[Pipeline] GLM output schema validation failed", parsed.error);
      continue;
    }
    // 新增：预处理 + 质量评估
    const preprocessed = preprocessKnowledge(final.result.markdown);
    const quality = assessQuality(parsed.data);
    if (quality.overall < 0.4) {
      logger.warn(`[Pipeline] Quality too low: ${quality.overall}`, quality);
      continue;
    }
    // 写 JSONL（原有逻辑）
    const { join } = await import("path");
    const { mkdirSync, appendFileSync } = await import("fs");
    const datasetDir = join("data", "dataset");
    mkdirSync(datasetDir, { recursive: true });
    const jsonlPath = join(datasetDir, `${safeTopic}.jsonl`);
    appendFileSync(jsonlPath, JSON.stringify({ ...parsed.data, quality, preprocessed: { tokenCount: preprocessed.tokenCount } }) + "\n");
  }
  ```

### Phase 3 Gate

* 2 个新模块文件存在 + types.ts 修改 + tsc 通过

* `bun test tests/knowledge-preprocess-quality.test.ts` 全部 pass

* 全量回归无新增 regression

* commit + push + operations-log

***

## Phase 4 — 安全加固完成（Week 4）

详细设计见 v3 计划对应段落。摘要：

### Task 4.1 — API Key 静态加密

* 修改 [src/utils/api-key-persistence.ts](file:///d:/openclaw-fusion/src/utils/api-key-persistence.ts)（83 行）

* 新增模块级 `encrypt(plain)` / `decrypt(cipher)` 使用 AES-256-GCM（Bun 内置 `node:crypto`）

* 密钥来源：`readString("AXIOM_ENCRYPTION_KEY")`（base64 编码 32 字节）

* fail-closed 策略：

  * 写时未配密钥 → throw（防止明文写入）

  * 读时未配密钥或解密失败 → 跳过该条记录 + warn（容错历史数据）

* 修改 `saveApiKeyOverride`（line 58）：写前 `encrypt(apiKey)`，DB 列名保持 `api_key`（存密文 hex）

* 修改 `loadApiKeyOverrides`（line 37）：读后 `decrypt(r.api_key)`，失败跳过

* 新增 `migratePlaintextKeys(db)`：检测明文（hex 长度异常）并加密重写

* 测试加入 `tests/security-hardening.test.ts` 第一部分

### Task 4.2 — 多维度限流

* 修改 [src/utils/rate-limiter.ts](file:///d:/openclaw-fusion/src/utils/rate-limiter.ts)（122 行）

* 新增 `MultiDimensionLimiter` class：

  * 维度：IP（既有）+ per-user（x-api-key header hash）+ global

  * 每维度独立配额（默认 IP 100/min, user 200/min, global 1000/min）

  * 任一维度超限即拒绝

* 新增 `multiDimLimiter` 单例 + `createMultiDimensionMiddleware(limiter)` 中间件

* 在 main.ts 路由分发处接入（替换或并存既有 `apiLimiter`）— **需读 main.ts 确认接入点**

* 测试加入 `tests/security-hardening.test.ts` 第二部分

### Task 4.3 — 沙箱 Windows 加固

* 修改 [src/sandbox/process-sandbox.ts](file:///d:/openclaw-fusion/src/sandbox/process-sandbox.ts)（82 行）

* Windows 分支（line 28-30）增加资源限制：

  * 使用 `Bun.spawn` 的 `cwd` 限制 + 预生成 `JobObject`（如可行）

  * 退而求其次：通过 `wmic process` 在 spawn 后立即设置内存/CPU 上限（Windows API SetInformationJobObject）

  * 最低保障：限制 stdout/stderr 大小（已有 `slice(0, 10000)` 但在 `await` 后才切片，应改为流式截断）

* 文件大小限制：spawn 前 `ulimit -f` 等价物（Windows 用 `fs.statSync` 监控写入目录大小）

* 测试加入 `tests/security-hardening.test.ts` 第三部分（仅验证限制参数传递，不验证 OS 级强制）

### Task 4.4 — 安全监控 + 健康检查

* 新建 `src/utils/security-monitor.ts`：

  * `SecurityMonitor` class：聚合 auditLogger + metrics + 阈值告警

  * `checkRateLimitAnomaly()`：检查 `audit_event_total{event="rate_limit.exceeded"}` 计数，超阈值触发 `auditLogger.log({event: "security.alert", ...})`

  * `checkAuthFailureBurst()`：5 分钟内 `auth.failure` > 10 次 → 安全告警

  * `getSecurityReport()`：返回 { healthy, alerts, lastIncident }

* 修改 [src/core/health-checker.ts](file:///d:/openclaw-fusion/src/core/health-checker.ts)：

  * `runFullCheck` 的 `Promise.all` 数组（line 58-67）追加 `this.checkSecurity()`

  * 新增 `private async checkSecurity()`：

    ```typescript
    const { getSecurityMonitor } = await import("../utils/security-monitor.js");
    const monitor = getSecurityMonitor();
    const report = monitor.getSecurityReport();
    this.results.push({
      component: "安全",
      status: report.healthy ? "ok" : "warning",
      message: report.healthy ? "无活跃安全告警" : `${report.alerts.length} 个活跃告警`,
      fix: report.healthy ? undefined : "查看 audit.log 了解详情",
    });
    ```

* `generateRecommendations` 中已有"安全" stub（line 309）保持不变

* 测试加入 `tests/security-hardening.test.ts` 第四部分

### Task 4.5 — WebSocket 配置化

* 修改 [src/utils/websocket.ts](file:///d:/openclaw-fusion/src/utils/websocket.ts)（123 行）

* line 29: `const MAX_WS_CLIENTS = 100;` → `const MAX_WS_CLIENTS = readInt("WS_MAX_CLIENTS", 100);`

* 顶部新增 import: `import { readInt } from "./env.js";`

* 在 `env.ts` 的 `REQUIRED_ENV_VARS` 追加（可选）：

  ```typescript
  { name: "WS_MAX_CLIENTS", required: false, default: "100",
    validate: (v) => { const n = parseInt(v, 10); return n > 0 && n <= 10000; },
    description: "Max WebSocket concurrent clients" },
  ```

* 测试加入 `tests/security-hardening.test.ts` 第五部分

### Phase 4 Gate

* 5 个修改/新建文件 + tsc 通过

* `bun test tests/security-hardening.test.ts` 全部 pass

* 全量回归无新增 regression

* commit + push + operations-log

* 最终全量评估：`bun test` 期望 ≥1056 pass（1042 基线 + 14 Phase1 + 多个 Phase2-4）

***

## 评估机制

### 每阶段 Gate（强制）

1. **类型检查**: `bunx tsc --noEmit` — 不引入新增错误（基线 4 错误）
2. **单元测试**: 阶段对应测试文件全部 pass
3. **回归测试**: `bun test` 全量通过率不低于上一阶段
4. **代码审查**: 自查 AGENTS Rule 1（最小化施工）— 无投机性重构
5. **提交规范**: 仅 add 本阶段相关文件，不含既有未提交 modified 文件

### 最终评估（Phase 4 完成后）

1. **安全维度**:

   * 7 个新安全文件存在（audit-logger, route-auth, security-monitor, result-filter/score/extract 跳过, preprocessor, quality-assessor）

   * 4 个路由模块全部接入二次认证

   * API Key 加密存储（明文检测 = 0）

   * 健康检查含 security 项
2. **检索维度**:

   * `crawlSearchResults` 输出结果质量提升（过滤垃圾 + 多维评分排序）

   * 结构化数据抽取可用（zod schema 校验通过率 > 80%）
3. **知识维度**:

   * GLM 输出经 zod 校验

   * 预处理 + 质量评估接入 pipeline

   * 低质量数据被拒绝（quality.overall < 0.4 不入库）
4. **可观测性**:

   * `audit_event_total` / `security_alert_total` metrics 可查询

   * `data/logs/audit.log` 有审计记录

   * 健康检查报告含安全状态

***

## 资源需求

* **人力**: 单 agent 串行执行（依赖顺序强）

* **测试基础设施**: Bun test runner（已有）+ tsc（已有）

* **外部依赖**: 无新增 npm 包（zod ^3.22.0 已存在；AES-256-GCM 用 node:crypto 内置）

* **环境变量**（新增，可选）:

  * `AXIOM_ENCRYPTION_KEY`（base64 32 字节，Phase 4.1 用）

  * `WS_MAX_CLIENTS`（默认 100，Phase 4.5 用）

## 时间节点

* **Phase 1 收尾**: 1 天（Task 1.2-verify + 1.3 + 1.4 + commit）

* **Phase 2**: 2 天（4 个 Task 串行）

* **Phase 3**: 2 天（4 个 Task 串行）

* **Phase 4**: 2 天（5 个 Task 串行）

* **总计**: 7 个工作日

***

## 执行规则

1. **严格串行**: Phase 1 → 2 → 3 → 4，不跳阶段
2. **每 Task 必验证**: 单元测试 pass + tsc 通过才能进入下一 Task
3. **每 Phase 必提交**: commit + push internal211 + operations-log
4. **遇异常先停下**: 不擅自扩大改动范围，遇 v3 计划与实际代码不符时，以实际代码为准并记录到本文件"偏差修正"段
5. **TodoWrite 跟踪**: 每 Task 一个 todo，in\_progress → completed

