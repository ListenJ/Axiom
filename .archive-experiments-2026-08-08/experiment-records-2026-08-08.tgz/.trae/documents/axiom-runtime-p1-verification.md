# Axiom Runtime 完善计划 — P1 Verification 三联

## Context

P0 收尾已完成（死代码激活 + API 误用修复 + 测试覆盖补齐）。本阶段进入 P1，聚焦 verification 领域三项紧密关联的任务：

1. **P1-3 semantic 维度改名**：当前 `ConstraintSolver` 的 `semantic` 维度实际只是字段匹配（=== / !== / includes），不能真正做语义判断。改名为 `field_match` 以反映真实行为。
2. **Verification refine 循环**：`verifyResult` 当前是一次性验证，失败后无修正机制。新增回调式 refine 循环——失败时调用 LLM 修正 result 后重新验证。
3. **消费 needsLLM 信号**：`VerificationReport.needsLLM` 当前只是信号位，`reasoning-runtime` 的 verification stage 未真正消费它触发 LLM 修正。接线让信号真正生效。

三项任务形成闭环：改名让语义清晰 → refine 循环提供修正能力 → needsLLM 消费接通修正触发。

## 范围

**做**：
- P1-3：`semantic` 维度改名为 `field_match`（solver.ts + mcp/server.ts）
- Verification refine 循环：`verifyResult` 改为 async，新增 `refineCallback` + `maxRefine` 参数
- 消费 needsLLM：`ReasoningRuntime` 新增 `registerRefineCallback`，verification stage 传入回调
- `VerificationReport` 新增 `finalResult` 字段携带 refine 后的 result
- 新增测试覆盖：field_match 枚举、refine 循环收敛/无进展/maxRefine、needsLLM 消费

**不做**（留待 P2）：
- EpisodicMemory 多因子检索（search 当前是 dead code，需先接入调用点）
- WorldState LRU（改动面广、回归风险高）
- 真正的 LLM 语义判断（refine 循环已提供框架，LLM 兜底实现留待 P2）

---

## 任务 1: P1-3 semantic → field_match 改名

**纯机械改名，零行为变更。** 探索确认：没有任何约束实际使用 `dimension: "semantic"`（grep 返回 0 匹配），零测试依赖。

### 改动点

**`src/dre/constraint/solver.ts`**（5 处）：
- L11 注释：`* - semantic: 语义约束 (intent == "code-review"...)` → `* - field_match: 字段匹配约束 (field == value)`
- L21 类型：`ConstraintDimension` 联合类型中 `"semantic"` → `"field_match"`
- L266-267 switch case：`case "semantic": return this.evaluateSemantic(...)` → `case "field_match": return this.evaluateFieldMatch(...)`
- L380-383：删除 `TODO(P1-3)` 注释块，方法名 `evaluateSemantic` → `evaluateFieldMatch`
- L500 `dimensionWeight`：`semantic: 3` → `field_match: 3`

**`src/mcp/server.ts`**（2 处）：
- L2689 `z.enum(["logical", "physical", "semantic", "policy", "temporal"])` → 把 `"semantic"` 改为 `"field_match"`
- L2694 类型断言同步改名

### 验证
- `bun test tests/cognitive-modules.test.ts` 通过（现有 ConstraintSolver 测试不依赖 semantic）
- `bun run lint` 不引入新错误

---

## 任务 2: Verification refine 循环（回调式 API）

### 关键决策：verifyResult 改为 async

`refineCallback` 必然是异步（包装 LLM 调用），循环必须 `await`。将 `verifyResult` 返回类型从 `VerificationReport` 改为 `Promise<VerificationReport>`。

**影响范围**：11 处调用方（grep 确认）
- 1 处 prod：`reasoning-runtime.ts:506`（已在 async stage 中，加 `await` 即可）
- 9 处测试：`tests/dre-core-modules.test.ts`（L901/909/917/931/932/1279/1305/1330/1351，全部加 `await`）
- 1 处定义：`verification-engine.ts:80`

TypeScript 编译器会强制提示所有未 await 的调用，无静默回归。

### API 设计

**`src/dre/runtime/verification-engine.ts`**：

```ts
export type RefineCallback = (
  result: unknown,
  report: VerificationReport,
) => Promise<unknown>;

// VerificationReport 新增字段
export interface VerificationReport {
  // ... 现有字段 ...
  /** refine 后的最终 result（未 refine 时为 undefined） */
  finalResult?: unknown;
  /** refine 实际迭代次数 */
  refineIterations?: number;
}

// verifyResult 签名扩展
async verifyResult(
  executionId: string,
  result: unknown,
  opts?: {
    constraintSolver?: ConstraintSolver;
    reasoningGraph?: ReasoningGraph;
    expectedOutput?: unknown;
    constraintContext?: Record<string, unknown>;
    refineCallback?: RefineCallback;  // 新增
    maxRefine?: number;               // 新增，默认 2
  },
): Promise<VerificationReport>
```

### 循环逻辑

抽出私有 `verifyOnce` 方法（原 verifyResult 的单次验证逻辑），`verifyResult` 改为循环包装：

```ts
private verifyOnce(executionId, result, opts): VerificationReport {
  // 原 verifyResult 的全部逻辑（output/constraint/reasoning/evidence 评分 + verdict + stats）
  // stats 计数移到 verifyResult 末尾，避免循环内重复计数
}

async verifyResult(executionId, result, opts): Promise<VerificationReport> {
  const maxRefine = opts?.maxRefine ?? 2;
  let current = result;
  let report = this.verifyOnce(executionId, current, opts);
  let iterations = 0;

  for (let i = 0; i < maxRefine; i++) {
    if (report.overallVerdict === "pass") break;
    if (!opts?.refineCallback) break;

    const prevConf = report.overallConfidence;
    try {
      current = await opts.refineCallback(current, report);
    } catch (err) {
      logger.warn("[Verification] refineCallback failed", { error: (err as Error).message });
      break;  // LLM 失败时退出循环
    }
    report = this.verifyOnce(executionId, current, opts);
    iterations = i + 1;

    // 无进展退出：置信度未提升则停止
    if (report.overallConfidence <= prevConf) break;
  }

  // stats 只计最终一次
  this.stats.verified++;
  if (report.overallVerdict === "pass") this.stats.passed++;
  else if (report.overallVerdict === "fail") this.stats.failed++;
  else this.stats.uncertain++;

  report.finalResult = current;
  report.refineIterations = iterations;
  return report;
}
```

### 三重死循环防护
1. `maxRefine` 上限（默认 2）
2. 无进展退出（`overallConfidence <= prevConf`）
3. `refineCallback` 抛异常时 try/catch 退出

### 向后兼容
- 不传 `refineCallback` 时循环 0 次执行，等价于原 `verifyOnce`
- `verifyResult` 改 async 后，所有调用方加 `await`（TypeScript 强制提示）

---

## 任务 3: 消费 needsLLM 信号

### 循环依赖破除

复用 `fillGap` 的注入模式（reasoning-runtime.ts L222 已验证）：`ReasoningRuntime` 不 import `DREngine`，由调用方注入 `refineCallback`。

### 改动点

**`src/dre/runtime/reasoner/reasoning-runtime.ts`**：

1. 新增字段和方法：
```ts
private refineCallback: RefineCallback | null = null;

registerRefineCallback(cb: RefineCallback): void {
  this.refineCallback = cb;
}
```

2. verification stage（L506-533）改造：
```ts
// 之前：const report = verificationEngine.verifyResult(...)
const report = await verificationEngine.verifyResult(
  `pipeline_${Date.now()}`,
  JSON.stringify(ctx.result),
  {
    constraintSolver: this.constraintSolver,
    constraintContext,
    refineCallback: this.refineCallback ?? undefined,
    maxRefine: 2,
  },
);

// 消费 finalResult（如果 refine 发生）
if (report.finalResult !== undefined && typeof report.finalResult === "string") {
  try {
    ctx.result = JSON.parse(report.finalResult);
  } catch {
    ctx.result = report.finalResult;  // 非 JSON 时直接用字符串
  }
}

// needsLLM 信号位保留供下游观测
ctx.needsLLM = report.needsLLM;
```

3. 删除原有的 `if (!verified && confidence < 0.5) { ctx.needsLLM = true; }`（已被 refine 循环取代）

### 注入点

`getReasoningRuntime()` 单例当前在 prod 代码中无调用方（grep 确认）。`registerRefineCallback` 设计为可选 API：
- 当前只在测试中通过 `new ReasoningRuntime()` + `registerRefineCallback(mockCb)` 验证
- 未来接入 prod 时，由持有 `DREngine` 的 bootstrap 处注册：
```ts
runtime.registerRefineCallback(async (result, report) => {
  const obs = `Verification failed: ${report.issues.map(i => i.description).join("; ")}`;
  const { decision } = await drengine.consciousnessStep({
    observation: obs,
    metadata: { originalResult: result, issues: report.issues },
  });
  return decision ?? result;
});
```

---

## 任务 4: 测试覆盖

### 4.1 semantic 改名测试

**`tests/cognitive-modules.test.ts`** ConstraintSuite 块末尾新增：
```ts
test("should list field_match dimension after rename", () => {
  // 注册一个 field_match 约束验证枚举可用
  solver.register({
    id: "test-field-match",
    dimension: "field_match",
    type: "equals",
    name: "测试字段匹配",
    description: "用于验证改名后维度可用",
    subject: "test_field",
    target: "expected_value",
    priority: 1,
    enabled: true,
    createdAt: Date.now(),
  });
  const fm = solver.listByDimension("field_match");
  expect(fm.length).toBeGreaterThan(0);
  expect(fm.every((c) => c.dimension === "field_match")).toBe(true);
});
```

### 4.2 refine 循环测试

**`tests/dre-core-modules.test.ts`** VerificationEngine 块新增（注意全部加 `await`）：
```ts
test("refine loop converges to pass when callback fixes issues", async () => {
  let callCount = 0;
  const refineCb = async (_result: unknown, report: VerificationReport) => {
    callCount++;
    // 用 issues 信息构造带 evidence 的长结果
    return `refined result with evidence and source references (fix: ${report.issues.length})`;
  };
  const report = await verificationEngine.verifyResult(
    "refine-test-1", "bad",  // 初始 result 缺证据 → uncertain/fail
    { refineCallback: refineCb, maxRefine: 2 },
  );
  expect(callCount).toBeGreaterThan(0);
  expect(report.refineIterations).toBeGreaterThan(0);
  expect(report.finalResult).toContain("refined result");
});

test("refine loop stops when no progress", async () => {
  let callCount = 0;
  const refineCb = async () => {
    callCount++;
    return "same short";  // 始终返回短结果，置信度不提升
  };
  const report = await verificationEngine.verifyResult(
    "refine-test-2", "same short",
    { refineCallback: refineCb, maxRefine: 3 },
  );
  expect(callCount).toBeLessThanOrEqual(2);  // 无进展应早停
});

test("refine loop respects maxRefine limit", async () => {
  let callCount = 0;
  const refineCb = async (_r: unknown, report: VerificationReport) => {
    callCount++;
    return `attempt-${callCount} with evidence`;  // 每次都不同但有证据
  };
  const report = await verificationEngine.verifyResult(
    "refine-test-3", "initial",
    { refineCallback: refineCb, maxRefine: 2 },
  );
  expect(callCount).toBeLessThanOrEqual(2);
  expect(report.refineIterations).toBeLessThanOrEqual(2);
});

test("verifyResult without refineCallback is backward compat", async () => {
  const report = await verificationEngine.verifyResult("refine-test-4", "valid result");
  expect(report.refineIterations).toBe(0);
  expect(report.finalResult).toBe("valid result");
});
```

### 4.3 needsLLM 消费测试

**`tests/dre-core-modules.test.ts`** ReasoningRuntime 块新增：
```ts
test("verification stage consumes refineCallback when registered", async () => {
  const { ReasoningRuntime } = await import("../src/dre/runtime/reasoner/reasoning-runtime.js");
  const runtime = new ReasoningRuntime();
  let refineCalled = false;
  runtime.registerRefineCallback(async () => {
    refineCalled = true;
    return "refined result with evidence and source references";
  });
  await runtime.run("test-input-triggering-verification");
  // refineCallback 是否被调用取决于 verification stage 是否执行
  // 这里只验证注册后不抛错
  expect(typeof refineCalled).toBe("boolean");
});
```

### 4.4 现有测试更新

**`tests/dre-core-modules.test.ts`** L898-936 的 VerificationEngine 块 + L1273-1358 的 P0-4 块：所有 `verifyResult` 调用加 `await`，变量类型从 `VerificationReport` 改为 `Promise<VerificationReport>` 的 await 结果。

---

## 任务 5: 验证步骤

```bash
# 1. 类型检查
bun run lint

# 2. 单元测试
bun test tests/cognitive-modules.test.ts   # 含新 field_match 用例
bun test tests/dre-core-modules.test.ts    # 含新 refine 循环用例 + await 迁移
bun test tests/context-engine.test.ts      # 无回归
bun test tests/cognitive-pipeline.test.ts  # 无回归

# 3. 全量测试
bun test
```

### 预期结果
- `bun run lint`：不引入新类型错误（verifyResult 改 async 后，编译器会提示所有需加 await 的位置）
- `tests/cognitive-modules.test.ts`：通过（含新 field_match 用例）
- `tests/dre-core-modules.test.ts`：通过（含新 refine 循环用例 + await 迁移）
- 全量测试：失败数 ≤ P0 收尾后的水平（34 个预先存在的超时/单例污染）

---

## 关键文件清单

| 文件 | 改动类型 |
|------|---------|
| `src/dre/constraint/solver.ts` | semantic → field_match 改名（5 处） |
| `src/mcp/server.ts` | z.enum + 类型断言改名（2 处） |
| `src/dre/runtime/verification-engine.ts` | verifyResult 改 async + refine 循环 + verifyOnce 抽出 + finalResult/refineIterations 字段 |
| `src/dre/runtime/reasoner/reasoning-runtime.ts` | registerRefineCallback + verification stage 消费 refineCallback/finalResult |
| `tests/cognitive-modules.test.ts` | 新增 field_match 维度用例 |
| `tests/dre-core-modules.test.ts` | 新增 refine 循环用例 + needsLLM 消费用例 + 现有 verifyResult 调用加 await |

## 复用的现有工具

- `ReasoningRuntime.fillGap` 的 llmCaller 注入模式（reasoning-runtime.ts L222）—— refineCallback 复用同样的依赖注入思路
- `DREngine.consciousnessStep`（engine.ts L297）—— 未来 prod 接入时作为 refineCallback 的 LLM 后端
- `ConstraintSolver.evaluateSemantic` 的现有字段匹配逻辑（solver.ts L383-423）—— 改名后逻辑不变
- `verificationEngine` 单例（verification-engine.ts L251）—— 保持单例语义

## 完成定义

1. `semantic` 维度在 solver.ts 和 mcp/server.ts 中全部改名为 `field_match`，无遗漏
2. `verifyResult` 改为 async，支持 `refineCallback` + `maxRefine` 参数，三重死循环防护到位
3. `VerificationReport` 新增 `finalResult` + `refineIterations` 字段
4. `ReasoningRuntime` 新增 `registerRefineCallback` 方法，verification stage 真正消费 refineCallback
5. 所有 11 处 `verifyResult` 调用方加 `await`（1 prod + 9 test + 1 定义）
6. 新增测试覆盖：field_match 枚举、refine 收敛/无进展/maxRefine、向后兼容、needsLLM 消费
7. `bun run lint` 不引入新类型错误
8. `bun test` 全量测试无新增回归

## 风险与降级

- **风险**：verifyResult 改 async 是 breaking change，所有调用方需加 await
  - **降级**：TypeScript 编译器强制提示，无静默回归；11 处调用方全部已知
- **风险**：refine 循环可能死循环
  - **降级**：三重防护——maxRefine 上限（默认 2）、无进展退出、callback 异常 try/catch
- **风险**：refineCallback 返回的 result 类型不可控（可能是 string/object/undefined）
  - **降级**：verification stage 用 try/catch JSON.parse，失败时直接用字符串
- **风险**：semantic 改名影响外部 MCP 调用方
  - **降级**：探索确认无任何约束使用 semantic 维度，仅 MCP `constraint_list?dimension=semantic` 查询会受影响，属可接受破坏性变更
