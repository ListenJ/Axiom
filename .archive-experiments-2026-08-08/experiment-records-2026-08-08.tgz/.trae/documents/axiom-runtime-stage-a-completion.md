# Axiom Runtime 完善计划 — 阶段 A（P0 修复）

## Context

Axiom Runtime（位于 `src/dre/`）是一套把 LLM 当受控组件的确定性认知管道。架构评审发现四项 P0 级问题——死代码与 API 误用——它们让架构承诺（精度控制、行为塑形、状态感知）在代码层面未真正生效。本阶段只修复这四项，不做新机制引入，为后续 P1（refine 循环、软/硬约束）和 P2（检索质量、状态膨胀）打基础。

迁移策略：所有改动用 feature flag `DRE_RUNTIME_V2` 包裹，默认关闭，旧路径完整保留，灰度验证后再切换。

## 范围

**做**：P0-1 激活 ContextEngine、P0-2 激活 Gap 精细填补、P0-3 实现 ReasoningRuntime.detectGaps/fillGap、P0-4 修复 VerificationEngine 误用 ConstraintSolver。

**不做**（留待后续阶段）：Verification refine 循环、ConstraintSolver 软/硬约束、semantic 维度改名、EpisodicMemory 多因子检索、WorldState LRU。

---

## P0-1 激活 ContextEngineImpl（双轨过渡）

### 问题
`src/dre/runtime/context-engine.ts` 的 `ContextEngineImpl.build()` 在 `src/` 下零外部调用。实际上下文构建散落在 `src/dre/runtime/reasoner/reasoning-runtime.ts:185-215` 的 observation stage，直接调 `atomStore.search / memoryEngine.search / knowledgeNetwork.search`，绕过了 ContextEngine 中已有的筛选逻辑。

### 改动点

**`src/dre/runtime/context-engine.ts`**
- 扩展 `build()` 签名：`build(input: string, history?: MemoryItem[], opts?: { atomBudget?: number; entityBudget?: number }): RuntimeContext`
- 在现有 atoms/entities 检索基础上，新增 `memories`（来自 memoryEngine.search，top N）和 `knowledgeNodes`（来自 knowledgeNetwork.search，top N）字段到 RuntimeContext
- 暴露 `buildRaw(input, history)`（不走 5s 缓存的版本），供 reasoning-runtime 在需要新鲜数据时调用
- 新增 `invalidateCache()` 方法，供调用方在状态变更后主动失效

**`src/dre/runtime/reasoner/reasoning-runtime.ts`**
- observation stage（约 185-215 行）：在 `DRE_RUNTIME_V2 === "1"` 分支下，改为 `const ctx = contextEngine.build(ctx.input, history)`，把 atoms/entities/memories/knowledgeNodes 写入 `ctx.metadata`
- 保留旧路径作为 else 分支，原样不动
- 添加 import：`import { contextEngine } from "../context-engine.js"`

**`src/dre/index.ts`**
- 确认 `contextEngine` 单例已导出（行 47 附近），若无则补导出

### 风险与降级
- ContextEngine 当前 5s 缓存可能返回过期 atoms → observation stage 调用前先 `invalidateCache()`，或直接用 `buildRaw`
- 双轨期间两套上下文构建逻辑并存 → 1 周观察期，跑 e2e 无回归后删除旧分支

### 验证
- `tests/context-engine.test.ts` 新增用例：`build()` 返回的 atoms/entities 数量与直接调 `atomStore.search` 一致；`buildRaw` 不命中缓存
- `tests/cognitive-pipeline.test.ts` 全量回归
- e2e：`e2e/chat.spec.ts` 跑通，对比 V2 开关下 LLM 调用次数与上下文长度

---

## P0-2 激活 Gap 精细填补（粗粒度作 fallback）

### 问题
`src/dre/reasoning/graph.ts:278-353` 的 `generateGapFillingPrompt()` / `fillGapFromObject()` / `fillGap()` 设计完整但 `src/dre/` 内零外部调用。实际 Gap 填补由 `src/dre/pipeline/cognitive-pipeline.ts:362-364` 走粗粒度 LLM 调用（`consciousnessStep` 把整个上下文丢给 LLM），未使用 per-gap 精准提示。

### 改动点

**`src/dre/reasoning/graph.ts`**
- 新增 `fillGapsBatch(gaps: ReasoningGap[], fillers: { gapId: string; node: Partial<ReasoningNode> }[]): void`
  - 避免循环调用 `fillGap()` 时每次重算 `detectGaps()`（O(n²) 风险）
  - 直接按 gapId 匹配并回填节点，更新 confidence 与 edges

**`src/dre/pipeline/cognitive-pipeline.ts`**
- `runWithLLM`（约 330-409 行）改造：
  - 当 `DRE_GAP_FILL_FINE === "1"`（默认开）且 `deterministic.hasGaps === true` 且 `gaps.length <= 5` 时：
    - 遍历 `gaps`，对每个 gap 调 `graph.generateGapFillingPrompt(gap)`
    - 逐个调 `engine.consciousnessStep({ observation: prompt })`
    - 收集结果用 `graph.fillGapsBatch(gaps, fillers)` 回填
    - 重新调 `graph.detectGaps()` 验证，若 `hasGaps === false` 或整体 confidence > 0.5 → 返回
  - 否则（gap 数量 > 5，或精细填补后 confidence 仍 < 0.5）：走当前粗粒度路径作为 L3 降级
- 新增 `stats.gapsFilled` / `stats.gapFallbackCoarse` 指标

### 风险与降级
- 每个 gap 一次 LLM 调用，token 成本上升 → 硬上限 `gaps.length > 5` 时直接走粗粒度
- 精细填补失败（LLM 返回非法 JSON / confidence < 0.3）→ 自动回退粗粒度路径
- flag `DRE_GAP_FILL_FINE` 默认开，可关闭回到原行为

### 验证
- `tests/cognitive-pipeline.test.ts` 新增用例：
  - "gap 填补后 hasGaps=false"
  - "gap 数量 > 5 时走粗粒度 fallback"
  - "精细填补失败时回退粗粒度"
- e2e：`e2e/chat.spec.ts` 观察 LLM 调用次数与结果质量

---

## P0-3 实现 ReasoningRuntime.detectGaps / fillGap

### 问题
`src/dre/runtime/reasoner/reasoning-runtime.ts` 注释（行 11）声明负责"差距检测"，但未实现 `detectGaps` / `fillGap` 方法，也未 import `ReasoningGap`。8 阶段管道与 ReasoningGraph 的 Gap 机制完全脱节。

### 改动点

**`src/dre/runtime/reasoner/reasoning-runtime.ts`**
- 添加 import：`import { ReasoningGraph, ReasoningGap, ReasoningNode } from "../../reasoning/graph.js"`
- 新增私有字段：`private workingGraph: ReasoningGraph`（工作图，每次任务新建）
- graph-reasoning stage（约 308-335 行）改造：
  - 把当前 ctx 的 entities/atoms 喂入 `workingGraph`（addPremise / addInference / addConclusion）
  - 调 `workingGraph.detectGaps()` 写入 `ctx.metadata.gaps`
- 新增方法 `detectGaps(ctx): ReasoningGap[]`：委托给 `workingGraph.detectGaps()`
- 新增方法 `fillGap(gap: ReasoningGap): Promise<ReasoningNode>`：
  - 调 `workingGraph.generateGapFillingPrompt(gap)`
  - 调 `engine.consciousnessStep({ observation: prompt })`
  - 调 `workingGraph.fillGapFromObject(gap, response, confidence)` 回填
  - 返回新创建的 ReasoningNode

### 与 cognitive-pipeline 的边界约定
- reasoning-runtime 的 `workingGraph` 是"工作图"（任务级临时）
- cognitive-pipeline 用的 `engine.reasoning` 是"持久图"（engine 单例）
- 两者不共享，避免互相污染

### 风险与降级
- workingGraph 在长任务中可能膨胀 → 任务结束后 `workingGraph.clear()`（若 graph.ts 无 clear 方法，则 `this.workingGraph = new ReasoningGraph()`）
- graph-reasoning stage 现有逻辑不能破坏 → 新增的 graph 喂入与 detectGaps 调用放在 stage 末尾，原逻辑保留

### 验证
- `tests/dre-core-modules.test.ts` 新增用例：
  - "detectGaps 返回的 gap 数量与 graph.detectGaps() 一致"
  - "fillGap 后该 gap 不再出现在 detectGaps 结果中"
- 单元测试 reasoning-runtime 时 mock engine.consciousnessStep

---

## P0-4 修复 VerificationEngine 误用 ConstraintSolver

### 问题
`src/dre/runtime/verification-engine.ts:113-115` 调用 `constraintSolver.check([JSON.stringify(result)], { dimension: "logical" })`：
1. 传入**数组**作为 action（签名期望 string）
2. `dimension` 只是 ctx 字段不会被过滤（solver 遍历所有 enabled 约束）

### 改动点

**`src/dre/runtime/verification-engine.ts`**
- 行 113-115 改为：
  ```ts
  const action = typeof result === "string" ? result : JSON.stringify(result);
  const ctx = opts?.constraintContext ?? {};
  const constraintResult = constraintSolver.check(action, ctx);
  ```
- `verifyResult` 签名扩展：`opts.constraintContext?: Record<string, unknown>`
- 把 `constraintResult.violations` 真正写入 `VerificationReport.issues`（当前 issues 来自 constraint 维度的部分丢失）
- 把 `constraintResult.satisfied` 影响 `scores.constraint` 与 `overallVerdict`

**`src/dre/runtime/reasoner/reasoning-runtime.ts`**
- verification stage（约 379-418 行）：调用 `verifyResult` 时传入 `constraintContext`
  - 从 ctx.metadata 取 `intent` / `domain` / `action` 等字段（observation stage 已有 classification 结果）
  - 构造 `{ intent, domain, action, environment: process.env.NODE_ENV }` 传入

**`src/dre/constraint/solver.ts`**（仅注释，不改逻辑）
- 在 `check()` 方法上方加注释说明：`ctx` 字段会被各 dimension evaluator 读取（如 `ctx.intent` / `ctx.domain`），调用方应传入完整上下文而非 `{ dimension }` 这种过滤条件

### 关于 semantic 维度
本阶段不改名（用户选择"只改名"留待后续）。仅在 `solver.ts:380-420` 的 evaluateSemantic 上方加 TODO 注释：
```ts
// TODO(P1-3): 当前 semantic 维度实际为字段匹配（=== / !== / includes），
// 不能真正判 "违反 Belief" 或 "意图对齐"。计划在 P1 阶段改名为 field_match，
// 并把真正的语义判断归到 VerificationEngine 的 LLM 兜底路径。
```

### 风险与降级
- 修复后 constraint 检查会真正生效，可能暴露之前被掩盖的违反 → 这是预期行为，但需观察 e2e 是否出新失败
- 现有约束集主要针对 action/资源，对 JSON.stringify(result) 检查不会触发违反 → 预期行为，result-shape 类约束在 P1 补充

### 验证
- `tests/dre-core-modules.test.ts` 新增用例：
  - "verification 调用 constraintSolver 时 action 为 string"
  - "constraintContext.intent 被正确传入并被 semantic evaluator 读取"
  - "constraint 违反被写入 VerificationReport.issues"
- `tests/cognitive-pipeline.test.ts` 全量回归

---

## Feature Flag 策略

| Flag | 默认 | 作用 | 失效回退 |
|------|------|------|---------|
| `DRE_RUNTIME_V2` | `0` | 启用 ContextEngine 激活路径 | 走旧 observation stage 逻辑 |
| `DRE_GAP_FILL_FINE` | `1` | 启用 Gap 精细填补 | 走粗粒度 LLM 调用 |

P0-3 和 P0-4 不需要 flag——它们是修复未实现/误用的代码，本身就应是正确行为。若需保守，可加 `DRE_REASONING_GRAPH_V2` 包裹 P0-3 的 workingGraph 喂入逻辑。

`.env.example` 添加这两个 flag 的说明。

---

## 端到端验证

### 单元测试
```bash
# 假设项目用 bun（package.json 显示 bun.lock）
bun test tests/context-engine.test.ts
bun test tests/dre-core-modules.test.ts
bun test tests/cognitive-pipeline.test.ts
bun test tests/consciousness.test.ts
```

### 集成测试
- 跑 `tests/` 全量，确认无回归
- 重点观察：cognitive-pipeline 在 V2 开关下的 LLM 调用次数、verification 的 issues 字段

### e2e
- `e2e/chat.spec.ts` 在 `DRE_RUNTIME_V2=0` 和 `=1` 两种环境下各跑一次
- 对比 LLM 调用次数、上下文长度、结果质量

### 灰度上线
1. 默认关闭所有 flag，提交代码
2. 本地 `DRE_RUNTIME_V2=1 bun dev` 跑 1 天观察
3. 确认无回归后默认开启

---

## 关键文件清单

| 文件 | 改动类型 |
|------|---------|
| `src/dre/runtime/context-engine.ts` | 扩展 build、新增 buildRaw/invalidateCache |
| `src/dre/runtime/reasoner/reasoning-runtime.ts` | observation stage 双轨、新增 detectGaps/fillGap、verification stage 传 ctx |
| `src/dre/pipeline/cognitive-pipeline.ts` | runWithLLM 加 Gap 精细填补分支 |
| `src/dre/reasoning/graph.ts` | 新增 fillGapsBatch |
| `src/dre/runtime/verification-engine.ts` | 修复 check 调用、扩展签名、issues 写入 |
| `src/dre/constraint/solver.ts` | 仅注释（evaluateSemantic 加 TODO） |
| `src/dre/index.ts` | 确认 contextEngine 导出 |
| `.env.example` | 添加 DRE_RUNTIME_V2 / DRE_GAP_FILL_FINE 说明 |
| `tests/context-engine.test.ts` | 新增 build/buildRaw 用例 |
| `tests/dre-core-modules.test.ts` | 新增 detectGaps/fillGap/verification 修复用例 |
| `tests/cognitive-pipeline.test.ts` | 新增 Gap 精细填补与 fallback 用例 |

## 复用的现有工具

- `contextEngine` 单例（`src/dre/runtime/context-engine.ts`，已存在 5s 缓存逻辑）
- `atomStore.search` / `memoryEngine.search` / `knowledgeNetwork.search`（reasoning-runtime 已用，迁移到 ContextEngine 内部调用）
- `ReasoningGraph.detectGaps` / `generateGapFillingPrompt` / `fillGapFromObject`（graph.ts 已实现，本次激活调用）
- `engine.consciousnessStep`（cognitive-pipeline 已用，Gap 精细填补复用）
- `constraintSolver.check` / `registerAll`（solver.ts 已实现，本次修复调用方式）

## 完成定义

1. 四个 P0 问题的代码修复全部落地
2. 所有新增/修改有对应单元测试覆盖
3. `tests/` 全量通过，`e2e/chat.spec.ts` 在 V2 开关下均通过
4. Feature flag 默认关闭，旧路径完整保留
5. `.env.example` 更新 flag 说明
6. 提交 commit（用户确认后）
