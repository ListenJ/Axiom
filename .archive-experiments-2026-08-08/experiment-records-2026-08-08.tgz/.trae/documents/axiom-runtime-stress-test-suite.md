# Axiom Runtime — 5 维度严苛测试套件

## Summary

为 Axiom Runtime 创建 5 个维度的严苛测试套件，覆盖并发压力、混沌工程、属性不变量、状态机完整性和确定性回放。测试文件位于 `tests/stress/` 目录下，每个维度一个文件，共 5 个文件、约 15 个测试用例。

## Current State Analysis

### 已有测试
- `tests/merge-stress.test.ts` — 已有 EventBus/WorldState/MentalModelPool 基础压力测试（10K 事件吞吐、1K 订阅者、100 仿真）
- `tests/task-graph.test.ts` — TaskGraph 基础测试
- `tests/cognitive-pipeline.test.ts` — CognitivePipeline 基础测试
- `tests/dre-core-modules.test.ts` — DRE 核心模块测试（含 VerificationEngine refine 循环）

### 用户伪代码与真实 API 的差异（关键发现）

| 用户伪代码 | 真实 API | 适配方案 |
|---|---|---|
| `knowledgeActor.write()` | `KnowledgeActorBehavior` 只处理 `query`/`validate`，无 `write` | 用 `atomStore.create()` 直接写入，或自定义 ActorBehavior |
| `worldState.restore()` | `WorldStateImpl` 无 `restore()` 方法 | 用 `snapshot()` 保存 + 手动 `set()` 恢复 |
| `bus.subscribe("*", ...)` | `subscribe()` 精确匹配，无通配符 | 订阅具体事件类型，或用 `EventEmitter` 的 `on("*")` |
| `new EventBusImpl()` | `EventBusImpl` 未导出，只有单例 `eventBus` | 用单例 + 唯一事件类型隔离 |
| `new WorldStateImpl()` | `WorldStateImpl` 未导出，只有单例 `worldState` | 用单例 + 唯一路径隔离 |
| `engine1.worldState` / `engine1.eventBus` | `DREngine` 不暴露这些属性 | 直接导入单例 `worldState` / `eventBus` |
| `bus.publish({type, data})` | `publish()` 需 `source` + `priority` 字段 | 补全必填字段 |
| ConstraintSolver 幂等 | `temporal` 维度用 `new Date()` 非幂等 | 用不含 temporal 的 solver，或 mock Date |

### 单例隔离策略
`eventBus`、`worldState`、`atomStore`、`dataUnifier` 均为全局单例，无 `reset()` API。隔离策略：
- **EventBus**: 每个测试用 `const EVENT_TYPE = \`stress.xxx.${Date.now()}\`` 唯一前缀，`afterEach` 中 `unsubscribe`
- **WorldState**: 每个测试用唯一路径前缀 `stress.test.${testId}.`，测试后不清理（单例状态累积是已知限制）
- **atomStore**: 测试前记录 `getStats().total`，测试后验证增量符合预期
- **dataUnifier**: 每个测试用 `init(db, knowledgeStore)` 重新绑定，但 `atomStore` 内部状态会累积

## Proposed Changes

### 文件结构
```
tests/stress/
├── concurrency-stress.test.ts       # 维度一：并发与竞态
├── chaos-failure-injection.test.ts   # 维度二：混沌工程
├── property-invariants.test.ts       # 维度三：属性测试
├── state-machine-integrity.test.ts   # 维度四：状态机完整性
└── determinism-replay.test.ts        # 维度五：确定性回放
```

---

### 文件 1: `tests/stress/concurrency-stress.test.ts`

**目标**: 验证 EventBus、WorldState、ActorSystem 在高并发下的线程安全性和顺序保证。

#### 测试用例 1.1: EventBus 洪水测试（10,000 事件）
- **API 适配**: `publish()` 需 `source` + `priority`；handler 同步执行，async handler 不阻塞 `publish()`
- **实现**:
  ```typescript
  const EVENT_TYPE = `stress.flood.${Date.now()}`;
  let processedCount = 0;
  const subId = eventBus.subscribe(EVENT_TYPE, () => { processedCount++; });
  
  // 同步发布 10K 事件（publish 是同步的，handler 也是同步的）
  for (let i = 0; i < 10000; i++) {
    eventBus.publish({ type: EVENT_TYPE, source: "stress", data: { id: i }, priority: "normal" });
  }
  // 同步 handler 已全部执行
  expect(processedCount).toBe(10000);
  // 环形缓冲区：maxLogSize=1000，getRecentEvents(100) 返回最后 100 条
  expect(eventBus.getRecentEvents(100).length).toBe(100);
  expect(eventBus.getRecentEvents(100)[99].type).toBe(EVENT_TYPE);
  eventBus.unsubscribe(subId);
  ```
- **断言**: `processedCount === 10000`；`getRecentEvents(100).length === 100`；日志不超过 `maxLogSize=1000`

#### 测试用例 1.2: WorldState 并发写入版本一致性（100 协程）
- **API 适配**: `set()` 同步，`Promise.all` 中的同步调用实际顺序执行
- **实现**:
  ```typescript
  const path = `stress.concurrent.${Date.now()}`;
  const initialVersion = worldState.getVersion();
  // 模拟 "并发" —— 实际 JS 单线程，set() 同步
  const tasks = Array.from({ length: 100 }, (_, i) => 
    Promise.resolve(worldState.set(path, i))
  );
  await Promise.all(tasks);
  // 版本号必须精确增加 100
  expect(worldState.getVersion()).toBe(initialVersion + 100);
  // 最终值必须是 100 个中的某一个（实际是最后一个 set 的值 = 99）
  const finalVal = worldState.get(path);
  expect(finalVal).toBe(99); // 同步顺序执行，最后一个是 i=99
  ```
- **断言**: `version` 精确 `+100`；最终值有效（非 undefined）

#### 测试用例 1.3: Actor 消息顺序保证（100 消息）
- **API 适配**: `KnowledgeActorBehavior` 无 `write` topic；用自定义 behavior 写入 `atomStore`
- **实现**:
  ```typescript
  const system = new ActorSystem();
  const writeOrder: number[] = [];
  const writeActor: ActorBehavior = {
    id: "write-actor",
    type: "writer",
    async handle(message, ctx) {
      if (message.topic === "write") {
        const { index, content } = message.payload as { index: number; content: string };
        atomStore.create("fact", content, { metadata: { index } });
        writeOrder.push(index);
      }
      return null;
    },
  };
  await system.register(writeActor);
  
  // 发送 100 条消息（顺序发送，actor 顺序处理）
  for (let i = 0; i < 100; i++) {
    await system.send("test", "write-actor", "request", "write", { index: i, content: `fact-${i}` });
  }
  // 等待微任务清空
  await new Promise(r => setTimeout(r, 50));
  
  // 验证：所有消息按顺序处理
  expect(writeOrder.length).toBe(100);
  expect(writeOrder).toEqual(Array.from({ length: 100 }, (_, i) => i));
  // 验证：atomStore 中有 100 条记录
  const atoms = atomStore.search("fact-", 200);
  expect(atoms.length).toBe(100);
  await system.shutdown();
  ```
- **断言**: 100 条消息全部处理；顺序严格保持；atomStore 中全部持久化

---

### 文件 2: `tests/stress/chaos-failure-injection.test.ts`

**目标**: 验证降级能力、回滚机制和错误隔离。

#### 测试用例 2.1: 数据库崩溃模拟（persist 中途失败）
- **API 适配**: `atomStore.persist(db)` 使用事务；注入 mock db 在第 N 条语句抛异常
- **实现**:
  ```typescript
  const realDb = new Database(":memory:");
  atomStore.initPersist(realDb);
  // 预先创建 50 个 atom
  for (let i = 0; i < 50; i++) atomStore.create("fact", `pre-fail-${i}`);
  
  // 创建 mock db，在第 10 次 run 时抛异常
  let runCount = 0;
  const crashingDb = {
    prepare: () => ({
      run: () => {
        runCount++;
        if (runCount === 10) throw new Error("DB connection lost");
      },
    }),
    transaction: (fn: () => void) => fn, // 不真正用事务，直接执行
  } as unknown as Database;
  
  // persist 应抛异常（因为 db.run 抛了）
  expect(() => atomStore.persist(crashingDb)).toThrow("DB connection lost");
  
  // 内存中的 atom 仍然完整
  expect(atomStore.getStats().total).toBe(50); // 内存未丢失
  
  // 真实 DB 仍可用（系统继续运行）
  atomStore.persist(realDb); // 不抛异常
  ```
- **断言**: persist 抛异常后内存数据完整；真实 DB 可继续工作

#### 测试用例 2.2: LLM 熔断测试（降级链触发）
- **API 适配**: `LLMClient({ baseUrl: "http://invalid" })` 必失败；`CognitivePipeline.runWithLLM()` 4 级降级
- **实现**:
  ```typescript
  // 用临时 DB 创建 DREngine（构造函数执行真实 I/O）
  const dbPath = join(tmpdir(), `chaos-llm-${Date.now()}.db`);
  const engine = new DREngine({ dbPath, mainLLM: new LLMClient({ baseUrl: "http://invalid", model: "test" }), cloudFallback: null });
  const pipeline = new CognitivePipeline(engine);
  
  const result = await pipeline.runWithLLM("complex query requiring LLM");
  
  // 验证：即使 LLM 挂了，系统仍返回结果
  expect(result).toBeDefined();
  expect(result.fallbackLevel).toBe("rule"); // 最终走规则兜底
  // 清理
  engine.close?.();
  unlinkSync(dbPath);
  ```
- **断言**: `result.fallbackLevel === "rule"`；系统不崩溃

#### 测试用例 2.3: Actor 死锁隔离（sleep 不阻塞其他 Actor）
- **API 适配**: 自定义两个 actor，一个慢（sleep 10s→缩短到 200ms 测试用），一个快
- **实现**:
  ```typescript
  const system = new ActorSystem();
  let fastActorProcessed = false;
  
  const slowActor: ActorBehavior = {
    id: "slow-actor", type: "slow",
    async handle() { await new Promise(r => setTimeout(r, 200)); return null; },
  };
  const fastActor: ActorBehavior = {
    id: "fast-actor", type: "fast",
    async handle() { fastActorProcessed = true; return null; },
  };
  await system.register(slowActor);
  await system.register(fastActor);
  
  // 同时给两个 actor 发消息
  await system.send("test", "slow-actor", "request", "work", {});
  await system.send("test", "fast-actor", "request", "work", {});
  
  // fast actor 应该立即处理完，不等 slow actor
  await new Promise(r => setTimeout(r, 50));
  expect(fastActorProcessed).toBe(true);
  
  await system.shutdown();
  ```
- **断言**: `fastActorProcessed === true`（不阻塞）

#### 测试用例 2.4: TaskGraph 回滚验证
- **API 适配**: `executeAll()` 不抛异常，标记失败 + 调用 `rollbackAll()`
- **实现**:
  ```typescript
  const graph = new TaskGraph();
  let step1Executed = false, step1RolledBack = false;
  
  graph.addTask("step1", "ok", async () => { step1Executed = true; return "ok"; }, {
    rollback: async () => { step1RolledBack = true; },
  });
  graph.addTask("step2", "fail", async () => { throw new Error("Boom"); }, {
    dependsOn: ["step1"],
    rollback: async () => {},
  });
  
  await graph.executeAll(); // 不抛异常
  
  expect(step1Executed).toBe(true);
  expect(step1RolledBack).toBe(true); // 回滚触发
  expect(graph.getStatus()).toBe("partial"); // step1 完成但 step2 失败
  ```
- **断言**: step1 执行 + 回滚；graph 状态为 `partial`

---

### 文件 3: `tests/stress/property-invariants.test.ts`

**目标**: 随机输入验证系统不变量。

#### 测试用例 3.1: DataUnifier 双射性（1000 随机字符串）
- **API 适配**: `dataUnifier.init(db, knowledgeStore)` 需先初始化；`search()` 返回 `{atoms, knowledgeNodes}`
- **实现**:
  ```typescript
  const db = new Database(":memory:");
  // 创建 knowledge_node + FTS5 表（参考 dre-core-modules.test.ts）
  setupKnowledgeTables(db);
  const store = new KnowledgeStore(db);
  dataUnifier.init(db, store);
  
  // 生成 1000 个随机字符串（含特殊字符、Emoji、超长）
  const generator = (len: number) => {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*🌍🎉中文αβγ";
    let s = "";
    for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
    return s;
  };
  
  for (let i = 0; i < 1000; i++) {
    const content = generator(Math.floor(Math.random() * 200) + 10);
    dataUnifier.write({ kind: "fact", content });
    
    const result = dataUnifier.search(content);
    // 不变量：写入的内容必须能被搜索到（substring match）
    expect(result.atoms.some(a => a.content === content)).toBe(true);
  }
  ```
- **断言**: 每次 write 后 search 必须包含原始内容

#### 测试用例 3.2: ConstraintSolver 幂等性（1000 次调用）
- **API 适配**: 用不含 `temporal` 维度的 solver（避免 `new Date()` 非幂等）
- **实现**:
  ```typescript
  const solver = new ConstraintSolver();
  // 只注册 logical + physical + field_match + policy 约束（排除 temporal）
  solver.registerAll([
    { id: "test-req", dimension: "logical", type: "requires", name: "test", description: "d", subject: "actionA", target: "resourceB", priority: 5, enabled: true, createdAt: Date.now() },
    { id: "test-mem", dimension: "physical", type: "min_value", name: "mem", description: "d", subject: "available_memory_mb", params: { min: 500 }, priority: 3, enabled: true, createdAt: Date.now() },
  ]);
  
  const action = "deploy-app";
  const ctx = { has_resourceB: true, available_memory_mb: 1024 };
  
  const first = solver.check(action, ctx);
  for (let i = 0; i < 1000; i++) {
    const result = solver.check(action, ctx);
    // 不变量：结果必须完全一致
    expect(result.satisfied).toBe(first.satisfied);
    expect(result.violations.length).toBe(first.violations.length);
  }
  ```
- **断言**: 1000 次 `check()` 结果完全一致

#### 测试用例 3.3: AtomEngine ID 唯一性（10,000 并发创建）
- **API 适配**: `create()` 同步；ID = `atom_${kind}_${Date.now()}_${crypto.randomUUID().slice(0,8)}`
- **实现**:
  ```typescript
  const ids = new Set<string>();
  // 同步创建 10K atom（JS 单线程，但 Date.now() 可能相同）
  for (let i = 0; i < 10000; i++) {
    const atom = atomStore.create("fact", `unique-test-${i}`);
    ids.add(atom.id);
  }
  // 不变量：所有 ID 严格不重复
  expect(ids.size).toBe(10000);
  ```
- **断言**: `ids.size === 10000`（无重复）

---

### 文件 4: `tests/stress/state-machine-integrity.test.ts`

**目标**: 状态机全路径覆盖和栈溢出检测。

#### 测试用例 4.1: MentalModel GitConflict 全路径 BFS 遍历
- **API 适配**: `MentalModelPool` 非单例，`model.transitions` 可遍历
- **实现**:
  ```typescript
  const pool = new MentalModelPool();
  pool.register(GIT_CONFLICT_MODEL);
  const model = pool.get("git-conflict")!;
  
  // BFS 遍历所有可达状态
  const visited = new Set<string>();
  const queue: string[] = [model.initialState];
  const deadEnds: string[] = [];
  
  while (queue.length > 0) {
    const state = queue.shift()!;
    if (visited.has(state)) continue;
    visited.add(state);
    
    // 找出从当前状态出发的所有转换
    const outgoing = model.transitions.filter(t => t.fromState === state);
    if (outgoing.length === 0) {
      deadEnds.push(state); // 终态
    }
    for (const t of outgoing) {
      if (!visited.has(t.toState)) queue.push(t.toState);
    }
  }
  
  // 断言：所有定义的状态都被访问到（无不可达状态）
  const allStates = new Set(model.transitions.flatMap(t => [t.fromState, t.toState]));
  allStates.add(model.initialState);
  for (const state of allStates) {
    expect(visited.has(state)).toBe(true);
  }
  // 断言：终态（dead end）是预期的（如 "clean" 是 GitConflict 的终态）
  expect(deadEnds).toContain("clean");
  ```
- **断言**: 所有状态可达；无意外死状态

#### 测试用例 4.2: Persona 栈溢出检测（10,000 次 switchTo）
- **API 适配**: `PersonaLoader` 非单例；`switchTo()` 压栈，`popToPrevious()` 弹栈
- **实现**:
  ```typescript
  const loader = new PersonaLoader({ defaultPersona: "general" });
  
  // 连续 switchTo 10K 次
  for (let i = 0; i < 10000; i++) {
    loader.switchTo("code", `iteration-${i}`);
  }
  // 验证栈深度
  expect(loader.getContextSummary().stackDepth).toBe(10000);
  
  // 连续 popToPrevious 10K 次
  for (let i = 0; i < 10000; i++) {
    const result = loader.popToPrevious();
    expect(result).not.toBeNull();
  }
  // 验证栈空
  expect(loader.getContextSummary().stackDepth).toBe(0);
  // 再 pop 应返回 null（不崩溃）
  expect(loader.popToPrevious()).toBeNull();
  ```
- **断言**: 栈深度正确；无溢出；pop 到空后不崩溃

---

### 文件 5: `tests/stress/determinism-replay.test.ts`

**目标**: 验证相同输入产生相同事件序列（确定性）。

#### 测试用例 5.1: ReasoningRuntime 回放一致性
- **API 适配**: `ReasoningRuntime` 非单例（可 new）；`eventBus`/`worldState` 是单例，需隔离
- **实现**:
  ```typescript
  const EVENT_TYPE_PREFIX = `stress.replay.${Date.now()}`;
  const input = "deterministic test input";
  
  // 收集事件的辅助函数
  const collectEvents = async (runId: string) => {
    const events: Array<{ type: string; data: unknown }> = [];
    const subIds: string[] = [];
    
    // 订阅所有 pipeline 事件类型
    const eventTypes = [
      "pipeline.completed", "pipeline.llm_needed", "pipeline.constraint_violation",
      "atom.created", "state.changed",
    ];
    for (const type of eventTypes) {
      const id = eventBus.subscribe(type, (e) => {
        events.push({ type: e.type, data: e.data });
      });
      subIds.push(id);
    }
    
    return { events, subIds };
  };
  
  // Run 1
  const runtime1 = new ReasoningRuntime();
  const collector1 = await collectEvents("run1");
  await runtime1.run(input);
  await new Promise(r => setTimeout(r, 50)); // 等微任务清空
  
  // Run 2（相同输入）
  const runtime2 = new ReasoningRuntime();
  const collector2 = await collectEvents("run2");
  await runtime2.run(input);
  await new Promise(r => setTimeout(r, 50));
  
  // 清理订阅
  collector1.subIds.forEach(id => eventBus.unsubscribe(id));
  collector2.subIds.forEach(id => eventBus.unsubscribe(id));
  
  // 断言：两次运行产生相同数量的事件
  expect(collector2.events.length).toBe(collector1.events.length);
  // 断言：事件类型序列一致（确定性）
  const types1 = collector1.events.map(e => e.type);
  const types2 = collector2.events.map(e => e.type);
  expect(types2).toEqual(types1);
  ```
- **断言**: 事件数量一致；事件类型序列一致

#### 测试用例 5.2: ConstraintSolver 确定性（相同输入相同输出）
- **实现**:
  ```typescript
  const solver = new ConstraintSolver();
  solver.registerAll([...RESOURCE_CONSTRAINTS, ...POLICY_CONSTRAINTS]); // 排除 temporal
  
  const action = "test-action";
  const ctx = { environment: "development", available_memory_mb: 2048 };
  
  const results: ConstraintCheckResult[] = [];
  for (let i = 0; i < 100; i++) {
    results.push(solver.check(action, ctx));
  }
  
  // 所有结果必须一致
  const first = results[0];
  for (const r of results) {
    expect(r.satisfied).toBe(first.satisfied);
    expect(r.violations.length).toBe(first.violations.length);
    expect(r.satisfiedConstraints).toEqual(first.satisfiedConstraints);
  }
  ```
- **断言**: 100 次调用结果完全一致

---

## Assumptions & Decisions

### 关键决策
1. **文件组织**: 5 个独立文件放在 `tests/stress/` 目录下，而非合并到 `merge-stress.test.ts`。理由：维度清晰、可独立运行、避免单文件过大。
2. **API 适配**: 用户伪代码中的不存在 API（`knowledgeActor.write()`、`worldState.restore()`、EventBus `*` 通配符）用真实 API 替代，在测试注释中说明。
3. **单例隔离**: 用唯一事件类型 + 唯一路径前缀隔离，不依赖模块重载（bun:test 不支持 `jest.resetModules()`）。
4. **ConstraintSolver 幂等**: 排除 `temporal` 维度（因 `new Date()` 非幂等），只测 logical/physical/field_match/policy。
5. **DREngine 测试**: 用临时 DB 文件（`join(tmpdir(), ...)`）避免单例污染，参考 `task-graph.test.ts` 模式。
6. **Actor 死锁测试**: 用 200ms sleep 代替 10s（测试速度优先），验证隔离性即可。
7. **Persona 栈溢出**: 10K 次 switchTo 在 JS 中不会真正栈溢出（堆内存），但验证栈深度正确性和 pop 回溯能力。

### 已知限制
- **JS 单线程**: "并发"实际是事件循环交替，无法真正测试多线程竞态。WorldState 的 `Promise.all(set())` 实际顺序执行。
- **EventBus 单例**: 无法完全隔离，累积订阅器。用 `unsubscribe` 清理 + 唯一事件类型。
- **WorldState 单例**: `version` 全局递增，测试需记录初始值做差值比较。
- **atomStore 单例**: 累积 atom，测试需用唯一 content 前缀避免 search 干扰。
- **DREngine 构造函数**: 执行真实 I/O（SQLite），LLM 熔断测试需临时 DB。

## Verification Steps

1. **创建 `tests/stress/` 目录**
2. **编写 5 个测试文件**（按上述设计）
3. **运行测试**: `bun test tests/stress/`
4. **运行 lint**: `bun run lint`（确保 0 TS 错误）
5. **验证不破坏现有测试**: `bun test tests/merge-stress.test.ts tests/dre-core-modules.test.ts`
6. **全量测试**: `bun test tests/` 确认无回归

### 预期结果
- 5 个新测试文件，约 15 个测试用例
- 所有新测试通过（允许已知限制的断言放宽）
- 现有测试无回归
- lint 0 错误

### 实现顺序
1. 创建 `tests/stress/` 目录
2. `concurrency-stress.test.ts`（维度一）
3. `chaos-failure-injection.test.ts`（维度二）
4. `property-invariants.test.ts`（维度三）
5. `state-machine-integrity.test.ts`（维度四）
6. `determinism-replay.test.ts`（维度五）
7. 运行测试 + lint 验证
8. 修复发现的问题
