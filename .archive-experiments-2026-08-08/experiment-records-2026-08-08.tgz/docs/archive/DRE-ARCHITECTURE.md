# DRE (Deterministic Reasoning Engine) 架构文档 v3.1

> 权威参考文档 — 涵盖全部模块功能、关键代码、数据流、架构变更

---

## 一、核心设计原则

| 原则 | 说明 |
|------|------|
| **确定性优先** | LLM 是最后的填空者，不是决策者 — 优先走规则/图谱/约束求解 |
| **硬件无关** | Runtime 不关心底层硬件 (N卡/A卡/CPU)，资源预算由外部注入 |
| **统一数据入口** | 所有数据通过 `DataUnifier` 写入查询，AtomEngine 是核心抽象 |
| **状态式交互** | 系统每步发布 eventBus 事件 + 更新 worldState，外部可查询完整推理过程 |
| **Persona 非 Agent** | Persona 是 Runtime 配置上下文 (约束+心智模型+能力)，不是独立的 Agent |
| **极薄 Kernel** | Kernel 只有 init() 和 tick()，业务逻辑在 DREngine 内 |

---

## 二、模块层级总览

```
MCP Server (用户/工具入口)
│
├─ Kernel (极薄内核: init → tick 循环 → shutdown)
│   │
│   └─ DREngine (引擎主入口)
│       │
│       ├─ DataUnifier (统一数据入口) ★ v3.0
│       │    ├─ AtomEngine (内存 + SQLite 持久化)
│       │    └─ KnowledgeStore (SQLite FTS5 知识)
│       │
│       ├─ CognitivePipeline (认知管道)
│       │    ├─ run()               → 纯确定性
│       │    ├─ runWithLLM()         → 4级降级链
│       │    ├─ runFull()            → 确定性 + TaskGraph
│       │    └─ runFullWithLLM()     → 降级链 + TaskGraph ★ v3.1
│       │
│       ├─ ReasoningRuntime (8阶推理)
│       │    └─ verification-engine (4层验证) ★ v3.0
│       │
│       ├─ PersonaLoader (角色加载器) ★ v3.0
│       │    ├─ 8模式 (plan/code/retrieve/reflect/audit/creative/research/general)
│       │    ├─ PromptTemplateStore (7个预设模板)
│       │    └─ CapabilityRegistry (自动选择最优 Provider)
│       │
│       ├─ ConsciousnessStream (意识流)
│       │    ├─ WorkingMemory (FIFO)
│       │    ├─ EpisodicMemory (档案 + 整合) ★ v3.0
│       │    └─ ReflectionQueue (3触发器)
│       │
│       ├─ ConstraintSolver (5维约束)
│       ├─ MentalModelPool (4预注册模型)
│       ├─ ReasoningGraph (图 + 空洞检测)
│       ├─ ActorSystem (4行为)
│       ├─ WorldState (全局状态树)
│       └─ EventBus (发布订阅)
│
└─ ConfigLoader (环境变量 → KernelConfig) ★ v3.1
```

---

## 三、模块功能详解

### 3.1 DataUnifier — 统一数据入口

**文件:** `src/dre/runtime/data-unifier.ts`

**设计目标:** 替代 VFS + KnowledgeStore + AtomEngine 三个独立入口，提供一个统一的 `write/search/query` 接口。

```typescript
// 写入 → 同时创建 Atom + 写入 KnowledgeStore
this.data.write({ content, kind, domain, paradigm, sourceType });

// 搜索 → 同时搜索 Atom + KnowledgeStore
this.data.search(query, { limit, domain, kind });

// 查询 → 按种类/来源查询 Atom
this.data.queryByKind("entity");
this.data.queryBySource("mcp");

// 持久化 → Atom 写入 SQLite
this.data.persist();
```

**关键代码路径:**

```
engine.writeKnowledge(item)
  → DataUnifier.write({ id, content, kind, ... })
    → atomStore.create(...)           // 内存 Atom
    → knowledgeStore.write(...)       // SQLite 知识 (FTS5)
    → atomStore.persist(db)          // SQLite atom 表 (autoPersist)

engine.searchData(query)
  → DataUnifier.search(query)
    → atomStore.search(query)        // 内存搜索
    + knowledgeStore.search(query)   // FTS5 搜索
```

### 3.2 AtomEngine — 原子引擎

**文件:** `src/dre/runtime/atom-engine.ts`

**设计:** 一切运行时数据都是 Atom。代码、知识、文件、任务、记忆全部统一为 Atom 抽象。

```typescript
interface Atom {
  id: string;
  kind: AtomKind;           // 31种 (function, entity, fact, goal, observation...)
  content: string;
  metadata: Record<string, unknown>;
  relations: AtomRelation[]; // is-a, part-of, depends-on, causes...
  confidence: AtomConfidence; // certain | inferred | uncertain | hypothetical
  source: string;
  createdAt: number;
  updatedAt: number;
  version: number;
  parentId?: string;
  children: string[];
}
```

**新增功能 (v3.1):** SQLite 持久化

| 方法 | 作用 |
|------|------|
| `initPersist(db)` | 创建 atom 表 + 索引 |
| `persist(db)` | 全量 upsert 到 SQLite (事务) |
| `load(db)` | 从 SQLite 恢复到内存 |

### 3.3 CognitivePipeline — 认知管道

**文件:** `src/dre/pipeline/cognitive-pipeline.ts`

**设计:** 6 步认知闭环 + 4 级 LLM 降级链 + TaskGraph 执行。

```
runWithLLM(input):
  │
  ├─ L1: run()                   ← 纯确定性 (classify → knowledge → reasoning → constraint → action → reflection)
  │    └─ 有结论 && 无 Gap → 返回
  │
  ├─ L2: consciousnessStep()     ← 本地 LLM (Qwen3)
  │    └─ fallbackLevel === "local" → 返回
  │
  ├─ L3: cloud API               ← DeepSeek / OpenAI
  │    └─ fallbackLevel === "cloud" → 返回
  │
  └─ L4: rule-based              ← 关键词匹配 (error→reflect, todo→act)
       └─ 返回规则推理结果

runFullWithLLM(input):
  └─ runWithLLM(input) + TaskGraph.executeAll()
```

**关键代码路径:**

```
cognitivePipeline.runFullWithLLM("重构用户认证模块")
  → runWithLLM("重构用户认证模块")
    → run("重构用户认证模块")                         // L1 确定性
      → classify() → searchData() → buildReasoning() → constraints.check() → consciousnessStep()
    → 如有 Gap / 低置信度 → consciousnessStep()      // L2/L3/L4
  → TaskGraph.addTask("exec-action")
  → ActorSystem.send("knowledge", "execute", action)
  → TaskGraph.executeAll()
```

**状态发布 (v3.1: 状态式交互):**
每步结束后自动发布 `eventBus` 事件 + 更新 `worldState`:
- `cognitive.step.classify` / `cognitive.step.knowledge` / ...
- `cognitive.pipeline.completed`
- `worldState.set("cognitive.pipeline.step.N", { stage, output, durationMs })`
- `worldState.setGoal(goalId, description, "active")`

### 3.4 PersonaLoader — 角色加载器

**文件:** `src/dre/persona/loader.ts`

**设计:** Persona = Constraints + MentalModels + Capabilities + PromptTemplate。切换 Persona 就是切换 Runtime 配置上下文。

```typescript
// 切换 Persona (替代 new PlannerAgent())
engine.switchPersona("audit", "开始安全审查");
engine.switchPersona("code");
engine.persona.popToPrevious();

// 查询状态
engine.persona.getCurrentMode();           // "audit"
engine.persona.getTemperature();           // 0.0
engine.persona.canWrite();                 // false (audit 只读)
engine.persona.getAvailableModes();        // 8 种模式
```

**8 种内置 Persona:**

| 模式 | 温度 | 写操作 | 能力契约 | 约束规则 |
|------|------|--------|----------|----------|
| `plan` | 0.0 | ✗ | planning.structured, reasoning.deductive | resource-memory |
| `code` | 0.0 | ✓ | code.reasoning, code.generation, code.review | resource-memory |
| `retrieve` | 0.0 | ✗ | knowledge.retrieval | — |
| `reflect` | 0.0 | ✓ | reasoning.causal, verification.factual | — |
| `audit` | 0.0 | ✗ | code.review, verification.factual | **3 条审计约束** (no-write, no-delete, no-exec) |
| `creative` | 0.7 | ✓ | generation.creative | — |
| `research` | 0.1 | ✓ | research.synthesis, reasoning.analogical | — |
| `general` | 0.3 | ✓ | — | — |

**PromptTemplateStore:** 7 个模板，替代原来 AgentHarness 子类的 systemPrompt()。

### 3.5 Kernel — 极薄内核

**文件:** `src/dre/kernel.ts`

**设计:** Kernel 只负责启动和驱动，所有业务逻辑在 DREngine 内。

```typescript
// 启动
const kernel = new Kernel({ dbPath: "./data/dre.db", mainLLM: {...} });
await kernel.init();         // 等待 DREngine 就绪 + 启动 autoTick

// 驱动循环
await kernel.tick("manual"); // 更新心跳 + 驱动 Scheduler + 发布 kernel.tick 事件

// 停止
await kernel.shutdown();     // 停止 tick + 关闭 DREngine

// 查询
kernel.getStatus();          // { state, uptime, tickCount, engineStatus, schedulerStatus }
kernel.getEngine();          // → DREngine
```

### 3.6 ConfigLoader — 配置加载器

**文件:** `src/dre/config.ts`

**设计:** 集中管理配置加载。只从环境变量读取，不依赖配置文件。

```typescript
const config = new ConfigLoader().toKernelConfig();
// 等价于手动构造:
// { dbPath, mainLLM: { baseUrl, model, temperature }, tickInterval, ... }
```

**环境变量映射:**

| 变量 | 配置字段 | 默认值 |
|------|----------|--------|
| `DRE_DB_PATH` | dbPath | `"./data/dre.db"` |
| `DRE_LLM_URL` | llmUrl | `"http://127.0.0.1:8080"` |
| `DRE_LLM_MODEL` | llmModel | `"qwen3-1.7b-instruct"` |
| `DRE_DISCRIMIN_URL` | discriminUrl | — |
| `DEEPSEEK_API_KEY` | cloudApiKey | — |
| `DRE_TICK_INTERVAL` | tickInterval | `10000` |
| `DRE_AUTO_TICK` | autoTick | `true` |
| `DRE_WORKING_MEMORY_CAPACITY` | workingMemoryCapacity | `16` |
| `DRE_EPISODIC_TTL` | episodicTTL | `3600000` |

### 3.7 VerificationEngine — 验证引擎

**文件:** `src/dre/runtime/verification-engine.ts`

**设计:** 4 层验证 + LLM fallback 决策。

```typescript
verificationEngine.verifyResult("task-1", "result string with evidence", {
  constraintSolver: engine.constraints,
  reasoningGraph: engine.reasoning,
});
// → { overallVerdict: "pass"|"fail"|"uncertain",
//     overallConfidence: 0.85,
//     issues: [...],
//     needsLLM: true|false }
```

**4 层评分:**
| 维度 | 检测内容 |
|------|----------|
| output | 输出非空、长度足够 |
| constraint | 不违反约束求解器 |
| reasoning | 推理链无 Gap、无循环 |
| evidence | 包含引用/证据 |

**集成到 ReasoningRuntime Stage 8:**
```
ReasoningRuntime.pipeline[7] = verification
  → verificationEngine.verifyResult(id, result)
    → 如果 fail && confidence < 0.5 → needsLLM = true
    → 发布 pipeline.verification 事件
```

### 3.8 ConsciousnessStream — 记忆整合

**文件:** `src/dre/consciousness/stream.ts`

**新增功能 (v3.1: 记忆档案 + 整合):**

| 方法 | 作用 |
|------|------|
| `episodicMemory.archive()` | 返回过期记忆，供外部存档到 KnowledgeStore |
| `episodicMemory.consolidate(0.7)` | 余弦相似度 > 0.7 的记忆合并为模式 |
| `consciousness.archiveAndConsolidate()` | 三步: 整合 → 归档 → 清理 |

### 3.9 ResourceBudgetManager — 资源预算 (替代 VRAM)

**文件:** `src/dre/system-resource.ts`

**设计:** 纯数字比较，不调用任何硬件检测。硬件检测由外部插件注入。

```typescript
const budget = getResourceBudgetManager();
budget.updateResource({ availableMemory: 8000, source: "nvidia-plugin" });
budget.canRun();  // { canRun, reason, recommendedMaxTokens }
```

---

## 四、MCP 工具集 (DRE 领域)

| 工具 | 模块 | 用途 | 版本 |
|------|------|------|------|
| `dre_status` | engine | 引擎状态 | 2.0 |
| `dre_write_knowledge` | engine | 写入知识 (三段甄别) | 2.0 |
| `dre_search` | engine | 搜索知识库 | 2.0 |
| `dre_subgraph` | engine | 子图检索 | 2.0 |
| `resource_status` | system-resource | 资源预算状态 | 3.0 |
| `persona_switch` | persona | 切换角色模式 | 3.0 |
| `persona_status` | persona | 当前角色详情 | 3.0 |
| `persona_list` | persona | 所有可用模式 | 3.0 |
| `cognitive_state` | engine | 统一认知状态查询 | 3.1 |
| `cognitive_pipeline_run` | pipeline | 认知管道 (LLM 降级) | 3.1 |
| `cognitive_pipeline_run_full` | pipeline | 认知管道 + TaskGraph 执行 | 3.1 |
| `data_write` | data-unifier | 统一写入 (Atom + 知识) | 3.1 |
| `data_search` | data-unifier | 统一搜索 (Atom + 知识) | 3.1 |
| `data_stats` | data-unifier | AtomEngine 统计 | 3.1 |
| `data_persist` | data-unifier | 手动持久化 Atom 到 SQLite | 3.1 |

---

## 五、架构变更历史

### v3.1 — 数据统一 + 状态暴露

```
新增:
  DataUnifier           — 统一 write/search/query 入口
  AtomEngine 持久化      — initPersist/persist/load
  ConfigLoader          — 环境变量 → KernelConfig
  runFullWithLLM()       — 降级链 + TaskGraph
  getCognitiveState()    — 统一认知状态查询
  cognitive_pipeline_run MCP 工具
  data_write / search / stats / persist MCP 工具

废弃:
  searchKnowledge() → 改用 searchData()
  getDREngine()     → 改用 getKernel().getEngine()

修复:
  ConsciousnessState.lastReflectionAt 类型 (number|null → number)
  capability-registry.ts + rule-engine.ts + verification-engine.ts 的 logger 路径
  engine.getStatus() 的未初始化 DB 保护
```

### v3.0 — Persona + Kernel + Verification

```
新增:
  PersonaLoader         — 8模式 + PromptTemplateStore
  Kernel                 — 极薄启动器 (init/tick/shutdown)
  ResourceBudgetManager  — 硬件无关资源预算
  SystemResource         — 通用资源接口
  VerificationEngine     — 4层验证
  archive() + consolidate() — 记忆档案整合

删除:
  vram-budget.ts         — VRAMBudgetManager 移除

废弃:
  AgentHarness           — 改用 PersonaLoader
  GPU_CONSTRAINTS        — 改用 RESOURCE_CONSTRAINTS
  Agent 工厂方法         — 改用 switchPersona()
```

---

## 六、关键数据流图

```
┌─ 用户输入 ─────────────────────────────────────────────────────────┐
│  "帮我分析这个代码"                                                  │
└────────────────────────────┬────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│  Kernel.tick() → worldState.setGoal()                              │
│  → CognitivePipeline.runFullWithLLM(input)                         │
│    ├─ L1: classify → searchData(knowledge) → buildReasoning       │
│    │   → constraintCheck → action → reflection                     │
│    │   → 每步发布 cognitive.step.* 事件                             │
│    ├─ L2: (如有 Gap) → consciousnessStep (本地 LLM)               │
│    ├─ L3: (L2 失败) → cloud API                                    │
│    └─ L4: (L3 失败) → rule-based                                   │
│                                                                     │
│  [每步] → eventBus.publish(type, data)                              │
│         → worldState.set("cognitive.pipeline.step.N", ...)          │
│                                                                     │
│  → TaskGraph (如需要执行操作)                                       │
│    → ActorSystem.send() → execute                                   │
│                                                                     │
│  → 发布 cognitive.pipeline.completed                                 │
│  → worldState.setGoal(..., "completed"|"abandoned")                 │
└─────────────────────────────────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│  DataUnifier (所有读写经过这里)                                      │
│  write(input) → atomStore.create() + knowledgeStore.write()        │
│  search(q)    → atomStore.search() + knowledgeStore.search()       │
│  persist()    → atomStore.persist(db) → SQLite atom 表             │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 七、测试覆盖

**文件:** `tests/dre-core-modules.test.ts` — 88 个测试，全部通过。

| 模块 | 测试数 | 覆盖内容 |
|------|--------|----------|
| WorkingMemory | 4 | push, evict, recent, clear |
| EpisodicMemory | 2 | add, cleanup |
| ReflectionQueue | 2 | short trace, consecutive failures |
| ConsciousnessStream | 5 | step, FIFO, reflection, state, trace |
| KnowledgeGraph | 7 | add, edges, path, community, serialize |
| Pipeline | 4 | create, write, search (FTS5 + domain) |
| VFS | 2 | mount, longest prefix |
| ResourceBudgetManager | 3 | create, check, update |
| AgentHarness (deprecated) | 7 | tool call, system prompts |
| PersonaLoader | 5 | init, switch, pop, prompt, allowWrite |
| PromptTemplateStore | 3 | templates, render, listByMode |
| SqliteBackend | 6 | write, read, stat, list, delete, rollback |
| LLMClient | 5 | create, error, parse, stream, constrained |
| EventBus | 4 | publish, priority, once, stats |
| WorldState | 5 | get/set, watch, mental, query, snapshot |
| VerificationEngine | 5 | pass, fail, short, quickVerify, stats |
| EpisodicMemory (archive) | 3 | archive, consolidate, single |
| Kernel | 3 | init, tick, tickLoop |
